"use strict";

function country_removed() {
    var countries = $("#countries_parent select");
    if (countries.length <= 1) {
        $(".remove_field").hide();
    } else {
        $(".remove_field").show();
    }
}

function gpaActionChanged(element) {
    var addActionButton = $("#add-action-btn");
    if (element.checked) {
        addActionButton.removeClass("disabled");
        $(element).parent().parent().find(".gpa_action_department").show();
    } else {
        $(element).parent().parent().find(".gpa_action_department").hide();
        var i = 0;
        $("input[name=gpa_action]:checked").each(function() {
            i++;
        });
        if (i < 1) {
            addActionButton.addClass("disabled");
        }
    }
}

function addDepartmentModal(select, modal_id) {
    if ($(select).find(":selected").hasClass("add-department")) {
        $(modal_id).modal("show");
        $("#add_department").on("hidden.bs.modal", function(e) {
            $(select).find("option").first().prop("selected", true);
        });
    }
}

"use strict";

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $(".Agency-details__logo__preview").css("background-image", "url(" + e.target.result + ")");
            $(".Agency-details__logo__preview").addClass("Selected");
        };
        reader.readAsDataURL(input.files[0]);
    }
}

function previewLogo(logoImage) {
    readURL(logoImage);
    $("#select-logo").hide();
    $("#replace-logo").show();
    $("#remove-logo").show();
}

function triggerPreviewLogo(e) {
    e.preventDefault();
    $("#imgInp").trigger("click");
}

function removeLogoPreview(e) {
    e.preventDefault();
    $("#replace-logo").hide();
    $("#remove-logo").hide();
    $("#select-logo").show();
    $(".Agency-details__logo__preview").css("background-image", "none");
    $(".Agency-details__logo__preview").removeClass("Selected");
}

"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
    return typeof obj;
} : function(obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};

if ("undefined" == typeof jQuery) throw new Error("Bootstrap's JavaScript requires jQuery. jQuery must be included before Bootstrap's JavaScript.");

+function(t) {
    var e = t.fn.jquery.split(" ")[0].split(".");
    if (e[0] < 2 && e[1] < 9 || 1 == e[0] && 9 == e[1] && e[2] < 1 || e[0] >= 4) throw new Error("Bootstrap's JavaScript requires at least jQuery v1.9.1 but less than v4.0.0");
}(jQuery), +function() {
    function t(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != (typeof e === "undefined" ? "undefined" : _typeof(e)) && "function" != typeof e ? t : e;
    }
    function e(t, e) {
        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + (typeof e === "undefined" ? "undefined" : _typeof(e)));
        t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
    }
    function n(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
    }
    var i = "function" == typeof Symbol && "symbol" == _typeof(Symbol.iterator) ? function(t) {
        return typeof t === "undefined" ? "undefined" : _typeof(t);
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t === "undefined" ? "undefined" : _typeof(t);
    }, o = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var i = e[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
                Object.defineProperty(t, i.key, i);
            }
        }
        return function(e, n, i) {
            return n && t(e.prototype, n), i && t(e, i), e;
        };
    }(), r = function(t) {
        function e(t) {
            return {}.toString.call(t).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
        }
        function n(t) {
            return (t[0] || t).nodeType;
        }
        function i() {
            return {
                bindType: a.end,
                delegateType: a.end,
                handle: function handle(e) {
                    if (t(e.target).is(this)) return e.handleObj.handler.apply(this, arguments);
                }
            };
        }
        function o() {
            if (window.QUnit) return !1;
            var t = document.createElement("bootstrap");
            for (var e in h) {
                if (void 0 !== t.style[e]) return {
                    end: h[e]
                };
            }
            return !1;
        }
        function r(e) {
            var n = this, i = !1;
            return t(this).one(c.TRANSITION_END, function() {
                i = !0;
            }), setTimeout(function() {
                i || c.triggerTransitionEnd(n);
            }, e), this;
        }
        function s() {
            a = o(), t.fn.emulateTransitionEnd = r, c.supportsTransitionEnd() && (t.event.special[c.TRANSITION_END] = i());
        }
        var a = !1, l = 1e6, h = {
            WebkitTransition: "webkitTransitionEnd",
            MozTransition: "transitionend",
            OTransition: "oTransitionEnd otransitionend",
            transition: "transitionend"
        }, c = {
            TRANSITION_END: "bsTransitionEnd",
            getUID: function getUID(t) {
                do {
                    t += ~~(Math.random() * l);
                } while (document.getElementById(t));
                return t;
            },
            getSelectorFromElement: function getSelectorFromElement(t) {
                var e = t.getAttribute("data-target");
                return e || (e = t.getAttribute("href") || "", e = /^#[a-z]/i.test(e) ? e : null), 
                e;
            },
            reflow: function reflow(t) {
                return t.offsetHeight;
            },
            triggerTransitionEnd: function triggerTransitionEnd(e) {
                t(e).trigger(a.end);
            },
            supportsTransitionEnd: function supportsTransitionEnd() {
                return Boolean(a);
            },
            typeCheckConfig: function typeCheckConfig(t, i, o) {
                for (var r in o) {
                    if (o.hasOwnProperty(r)) {
                        var s = o[r], a = i[r], l = a && n(a) ? "element" : e(a);
                        if (!new RegExp(s).test(l)) throw new Error(t.toUpperCase() + ": " + ('Option "' + r + '" provided type "' + l + '" ') + ('but expected type "' + s + '".'));
                    }
                }
            }
        };
        return s(), c;
    }(jQuery), s = (function(t) {
        var e = "alert", i = "4.0.0-alpha.6", s = "bs.alert", a = "." + s, l = ".data-api", h = t.fn[e], c = 150, u = {
            DISMISS: '[data-dismiss="alert"]'
        }, d = {
            CLOSE: "close" + a,
            CLOSED: "closed" + a,
            CLICK_DATA_API: "click" + a + l
        }, f = {
            ALERT: "alert",
            FADE: "fade",
            SHOW: "show"
        }, _ = function() {
            function e(t) {
                n(this, e), this._element = t;
            }
            return e.prototype.close = function(t) {
                t = t || this._element;
                var e = this._getRootElement(t), n = this._triggerCloseEvent(e);
                n.isDefaultPrevented() || this._removeElement(e);
            }, e.prototype.dispose = function() {
                t.removeData(this._element, s), this._element = null;
            }, e.prototype._getRootElement = function(e) {
                var n = r.getSelectorFromElement(e), i = !1;
                return n && (i = t(n)[0]), i || (i = t(e).closest("." + f.ALERT)[0]), i;
            }, e.prototype._triggerCloseEvent = function(e) {
                var n = t.Event(d.CLOSE);
                return t(e).trigger(n), n;
            }, e.prototype._removeElement = function(e) {
                var n = this;
                return t(e).removeClass(f.SHOW), r.supportsTransitionEnd() && t(e).hasClass(f.FADE) ? void t(e).one(r.TRANSITION_END, function(t) {
                    return n._destroyElement(e, t);
                }).emulateTransitionEnd(c) : void this._destroyElement(e);
            }, e.prototype._destroyElement = function(e) {
                t(e).detach().trigger(d.CLOSED).remove();
            }, e._jQueryInterface = function(n) {
                return this.each(function() {
                    var i = t(this), o = i.data(s);
                    o || (o = new e(this), i.data(s, o)), "close" === n && o[n](this);
                });
            }, e._handleDismiss = function(t) {
                return function(e) {
                    e && e.preventDefault(), t.close(this);
                };
            }, o(e, null, [ {
                key: "VERSION",
                get: function get() {
                    return i;
                }
            } ]), e;
        }();
        return t(document).on(d.CLICK_DATA_API, u.DISMISS, _._handleDismiss(new _())), t.fn[e] = _._jQueryInterface, 
        t.fn[e].Constructor = _, t.fn[e].noConflict = function() {
            return t.fn[e] = h, _._jQueryInterface;
        }, _;
    }(jQuery), function(t) {
        var e = "button", i = "4.0.0-alpha.6", r = "bs.button", s = "." + r, a = ".data-api", l = t.fn[e], h = {
            ACTIVE: "active",
            BUTTON: "btn",
            FOCUS: "focus"
        }, c = {
            DATA_TOGGLE_CARROT: '[data-toggle^="button"]',
            DATA_TOGGLE: '[data-toggle="buttons"]',
            INPUT: "input",
            ACTIVE: ".active",
            BUTTON: ".btn"
        }, u = {
            CLICK_DATA_API: "click" + s + a,
            FOCUS_BLUR_DATA_API: "focus" + s + a + " " + ("blur" + s + a)
        }, d = function() {
            function e(t) {
                n(this, e), this._element = t;
            }
            return e.prototype.toggle = function() {
                var e = !0, n = t(this._element).closest(c.DATA_TOGGLE)[0];
                if (n) {
                    var i = t(this._element).find(c.INPUT)[0];
                    if (i) {
                        if ("radio" === i.type) if (i.checked && t(this._element).hasClass(h.ACTIVE)) e = !1; else {
                            var o = t(n).find(c.ACTIVE)[0];
                            o && t(o).removeClass(h.ACTIVE);
                        }
                        e && (i.checked = !t(this._element).hasClass(h.ACTIVE), t(i).trigger("change")), 
                        i.focus();
                    }
                }
                this._element.setAttribute("aria-pressed", !t(this._element).hasClass(h.ACTIVE)), 
                e && t(this._element).toggleClass(h.ACTIVE);
            }, e.prototype.dispose = function() {
                t.removeData(this._element, r), this._element = null;
            }, e._jQueryInterface = function(n) {
                return this.each(function() {
                    var i = t(this).data(r);
                    i || (i = new e(this), t(this).data(r, i)), "toggle" === n && i[n]();
                });
            }, o(e, null, [ {
                key: "VERSION",
                get: function get() {
                    return i;
                }
            } ]), e;
        }();
        return t(document).on(u.CLICK_DATA_API, c.DATA_TOGGLE_CARROT, function(e) {
            e.preventDefault();
            var n = e.target;
            t(n).hasClass(h.BUTTON) || (n = t(n).closest(c.BUTTON)), d._jQueryInterface.call(t(n), "toggle");
        }).on(u.FOCUS_BLUR_DATA_API, c.DATA_TOGGLE_CARROT, function(e) {
            var n = t(e.target).closest(c.BUTTON)[0];
            t(n).toggleClass(h.FOCUS, /^focus(in)?$/.test(e.type));
        }), t.fn[e] = d._jQueryInterface, t.fn[e].Constructor = d, t.fn[e].noConflict = function() {
            return t.fn[e] = l, d._jQueryInterface;
        }, d;
    }(jQuery), function(t) {
        var e = "carousel", s = "4.0.0-alpha.6", a = "bs.carousel", l = "." + a, h = ".data-api", c = t.fn[e], u = 600, d = 37, f = 39, _ = {
            interval: 5e3,
            keyboard: !0,
            slide: !1,
            pause: "hover",
            wrap: !0
        }, g = {
            interval: "(number|boolean)",
            keyboard: "boolean",
            slide: "(boolean|string)",
            pause: "(string|boolean)",
            wrap: "boolean"
        }, p = {
            NEXT: "next",
            PREV: "prev",
            LEFT: "left",
            RIGHT: "right"
        }, m = {
            SLIDE: "slide" + l,
            SLID: "slid" + l,
            KEYDOWN: "keydown" + l,
            MOUSEENTER: "mouseenter" + l,
            MOUSELEAVE: "mouseleave" + l,
            LOAD_DATA_API: "load" + l + h,
            CLICK_DATA_API: "click" + l + h
        }, E = {
            CAROUSEL: "carousel",
            ACTIVE: "active",
            SLIDE: "slide",
            RIGHT: "carousel-item-right",
            LEFT: "carousel-item-left",
            NEXT: "carousel-item-next",
            PREV: "carousel-item-prev",
            ITEM: "carousel-item"
        }, v = {
            ACTIVE: ".active",
            ACTIVE_ITEM: ".active.carousel-item",
            ITEM: ".carousel-item",
            NEXT_PREV: ".carousel-item-next, .carousel-item-prev",
            INDICATORS: ".carousel-indicators",
            DATA_SLIDE: "[data-slide], [data-slide-to]",
            DATA_RIDE: '[data-ride="carousel"]'
        }, T = function() {
            function h(e, i) {
                n(this, h), this._items = null, this._interval = null, this._activeElement = null, 
                this._isPaused = !1, this._isSliding = !1, this._config = this._getConfig(i), this._element = t(e)[0], 
                this._indicatorsElement = t(this._element).find(v.INDICATORS)[0], this._addEventListeners();
            }
            return h.prototype.next = function() {
                if (this._isSliding) throw new Error("Carousel is sliding");
                this._slide(p.NEXT);
            }, h.prototype.nextWhenVisible = function() {
                document.hidden || this.next();
            }, h.prototype.prev = function() {
                if (this._isSliding) throw new Error("Carousel is sliding");
                this._slide(p.PREVIOUS);
            }, h.prototype.pause = function(e) {
                e || (this._isPaused = !0), t(this._element).find(v.NEXT_PREV)[0] && r.supportsTransitionEnd() && (r.triggerTransitionEnd(this._element), 
                this.cycle(!0)), clearInterval(this._interval), this._interval = null;
            }, h.prototype.cycle = function(t) {
                t || (this._isPaused = !1), this._interval && (clearInterval(this._interval), this._interval = null), 
                this._config.interval && !this._isPaused && (this._interval = setInterval((document.visibilityState ? this.nextWhenVisible : this.next).bind(this), this._config.interval));
            }, h.prototype.to = function(e) {
                var n = this;
                this._activeElement = t(this._element).find(v.ACTIVE_ITEM)[0];
                var i = this._getItemIndex(this._activeElement);
                if (!(e > this._items.length - 1 || e < 0)) {
                    if (this._isSliding) return void t(this._element).one(m.SLID, function() {
                        return n.to(e);
                    });
                    if (i === e) return this.pause(), void this.cycle();
                    var o = e > i ? p.NEXT : p.PREVIOUS;
                    this._slide(o, this._items[e]);
                }
            }, h.prototype.dispose = function() {
                t(this._element).off(l), t.removeData(this._element, a), this._items = null, this._config = null, 
                this._element = null, this._interval = null, this._isPaused = null, this._isSliding = null, 
                this._activeElement = null, this._indicatorsElement = null;
            }, h.prototype._getConfig = function(n) {
                return n = t.extend({}, _, n), r.typeCheckConfig(e, n, g), n;
            }, h.prototype._addEventListeners = function() {
                var e = this;
                this._config.keyboard && t(this._element).on(m.KEYDOWN, function(t) {
                    return e._keydown(t);
                }), "hover" !== this._config.pause || "ontouchstart" in document.documentElement || t(this._element).on(m.MOUSEENTER, function(t) {
                    return e.pause(t);
                }).on(m.MOUSELEAVE, function(t) {
                    return e.cycle(t);
                });
            }, h.prototype._keydown = function(t) {
                if (!/input|textarea/i.test(t.target.tagName)) switch (t.which) {
                  case d:
                    t.preventDefault(), this.prev();
                    break;

                  case f:
                    t.preventDefault(), this.next();
                    break;

                  default:
                    return;
                }
            }, h.prototype._getItemIndex = function(e) {
                return this._items = t.makeArray(t(e).parent().find(v.ITEM)), this._items.indexOf(e);
            }, h.prototype._getItemByDirection = function(t, e) {
                var n = t === p.NEXT, i = t === p.PREVIOUS, o = this._getItemIndex(e), r = this._items.length - 1, s = i && 0 === o || n && o === r;
                if (s && !this._config.wrap) return e;
                var a = t === p.PREVIOUS ? -1 : 1, l = (o + a) % this._items.length;
                return l === -1 ? this._items[this._items.length - 1] : this._items[l];
            }, h.prototype._triggerSlideEvent = function(e, n) {
                var i = t.Event(m.SLIDE, {
                    relatedTarget: e,
                    direction: n
                });
                return t(this._element).trigger(i), i;
            }, h.prototype._setActiveIndicatorElement = function(e) {
                if (this._indicatorsElement) {
                    t(this._indicatorsElement).find(v.ACTIVE).removeClass(E.ACTIVE);
                    var n = this._indicatorsElement.children[this._getItemIndex(e)];
                    n && t(n).addClass(E.ACTIVE);
                }
            }, h.prototype._slide = function(e, n) {
                var i = this, o = t(this._element).find(v.ACTIVE_ITEM)[0], s = n || o && this._getItemByDirection(e, o), a = Boolean(this._interval), l = void 0, h = void 0, c = void 0;
                if (e === p.NEXT ? (l = E.LEFT, h = E.NEXT, c = p.LEFT) : (l = E.RIGHT, h = E.PREV, 
                c = p.RIGHT), s && t(s).hasClass(E.ACTIVE)) return void (this._isSliding = !1);
                var d = this._triggerSlideEvent(s, c);
                if (!d.isDefaultPrevented() && o && s) {
                    this._isSliding = !0, a && this.pause(), this._setActiveIndicatorElement(s);
                    var f = t.Event(m.SLID, {
                        relatedTarget: s,
                        direction: c
                    });
                    r.supportsTransitionEnd() && t(this._element).hasClass(E.SLIDE) ? (t(s).addClass(h), 
                    r.reflow(s), t(o).addClass(l), t(s).addClass(l), t(o).one(r.TRANSITION_END, function() {
                        t(s).removeClass(l + " " + h).addClass(E.ACTIVE), t(o).removeClass(E.ACTIVE + " " + h + " " + l), 
                        i._isSliding = !1, setTimeout(function() {
                            return t(i._element).trigger(f);
                        }, 0);
                    }).emulateTransitionEnd(u)) : (t(o).removeClass(E.ACTIVE), t(s).addClass(E.ACTIVE), 
                    this._isSliding = !1, t(this._element).trigger(f)), a && this.cycle();
                }
            }, h._jQueryInterface = function(e) {
                return this.each(function() {
                    var n = t(this).data(a), o = t.extend({}, _, t(this).data());
                    "object" === ("undefined" == typeof e ? "undefined" : i(e)) && t.extend(o, e);
                    var r = "string" == typeof e ? e : o.slide;
                    if (n || (n = new h(this, o), t(this).data(a, n)), "number" == typeof e) n.to(e); else if ("string" == typeof r) {
                        if (void 0 === n[r]) throw new Error('No method named "' + r + '"');
                        n[r]();
                    } else o.interval && (n.pause(), n.cycle());
                });
            }, h._dataApiClickHandler = function(e) {
                var n = r.getSelectorFromElement(this);
                if (n) {
                    var i = t(n)[0];
                    if (i && t(i).hasClass(E.CAROUSEL)) {
                        var o = t.extend({}, t(i).data(), t(this).data()), s = this.getAttribute("data-slide-to");
                        s && (o.interval = !1), h._jQueryInterface.call(t(i), o), s && t(i).data(a).to(s), 
                        e.preventDefault();
                    }
                }
            }, o(h, null, [ {
                key: "VERSION",
                get: function get() {
                    return s;
                }
            }, {
                key: "Default",
                get: function get() {
                    return _;
                }
            } ]), h;
        }();
        return t(document).on(m.CLICK_DATA_API, v.DATA_SLIDE, T._dataApiClickHandler), t(window).on(m.LOAD_DATA_API, function() {
            t(v.DATA_RIDE).each(function() {
                var e = t(this);
                T._jQueryInterface.call(e, e.data());
            });
        }), t.fn[e] = T._jQueryInterface, t.fn[e].Constructor = T, t.fn[e].noConflict = function() {
            return t.fn[e] = c, T._jQueryInterface;
        }, T;
    }(jQuery), function(t) {
        var e = "collapse", s = "4.0.0-alpha.6", a = "bs.collapse", l = "." + a, h = ".data-api", c = t.fn[e], u = 600, d = {
            toggle: !0,
            parent: ""
        }, f = {
            toggle: "boolean",
            parent: "string"
        }, _ = {
            SHOW: "show" + l,
            SHOWN: "shown" + l,
            HIDE: "hide" + l,
            HIDDEN: "hidden" + l,
            CLICK_DATA_API: "click" + l + h
        }, g = {
            SHOW: "show",
            COLLAPSE: "collapse",
            COLLAPSING: "collapsing",
            COLLAPSED: "collapsed"
        }, p = {
            WIDTH: "width",
            HEIGHT: "height"
        }, m = {
            ACTIVES: ".card > .show, .card > .collapsing",
            DATA_TOGGLE: '[data-toggle="collapse"]'
        }, E = function() {
            function l(e, i) {
                n(this, l), this._isTransitioning = !1, this._element = e, this._config = this._getConfig(i), 
                this._triggerArray = t.makeArray(t('[data-toggle="collapse"][href="#' + e.id + '"],' + ('[data-toggle="collapse"][data-target="#' + e.id + '"]'))), 
                this._parent = this._config.parent ? this._getParent() : null, this._config.parent || this._addAriaAndCollapsedClass(this._element, this._triggerArray), 
                this._config.toggle && this.toggle();
            }
            return l.prototype.toggle = function() {
                t(this._element).hasClass(g.SHOW) ? this.hide() : this.show();
            }, l.prototype.show = function() {
                var e = this;
                if (this._isTransitioning) throw new Error("Collapse is transitioning");
                if (!t(this._element).hasClass(g.SHOW)) {
                    var n = void 0, i = void 0;
                    if (this._parent && (n = t.makeArray(t(this._parent).find(m.ACTIVES)), n.length || (n = null)), 
                    !(n && (i = t(n).data(a), i && i._isTransitioning))) {
                        var o = t.Event(_.SHOW);
                        if (t(this._element).trigger(o), !o.isDefaultPrevented()) {
                            n && (l._jQueryInterface.call(t(n), "hide"), i || t(n).data(a, null));
                            var s = this._getDimension();
                            t(this._element).removeClass(g.COLLAPSE).addClass(g.COLLAPSING), this._element.style[s] = 0, 
                            this._element.setAttribute("aria-expanded", !0), this._triggerArray.length && t(this._triggerArray).removeClass(g.COLLAPSED).attr("aria-expanded", !0), 
                            this.setTransitioning(!0);
                            var h = function h() {
                                t(e._element).removeClass(g.COLLAPSING).addClass(g.COLLAPSE).addClass(g.SHOW), e._element.style[s] = "", 
                                e.setTransitioning(!1), t(e._element).trigger(_.SHOWN);
                            };
                            if (!r.supportsTransitionEnd()) return void h();
                            var c = s[0].toUpperCase() + s.slice(1), d = "scroll" + c;
                            t(this._element).one(r.TRANSITION_END, h).emulateTransitionEnd(u), this._element.style[s] = this._element[d] + "px";
                        }
                    }
                }
            }, l.prototype.hide = function() {
                var e = this;
                if (this._isTransitioning) throw new Error("Collapse is transitioning");
                if (t(this._element).hasClass(g.SHOW)) {
                    var n = t.Event(_.HIDE);
                    if (t(this._element).trigger(n), !n.isDefaultPrevented()) {
                        var i = this._getDimension(), o = i === p.WIDTH ? "offsetWidth" : "offsetHeight";
                        this._element.style[i] = this._element[o] + "px", r.reflow(this._element), t(this._element).addClass(g.COLLAPSING).removeClass(g.COLLAPSE).removeClass(g.SHOW), 
                        this._element.setAttribute("aria-expanded", !1), this._triggerArray.length && t(this._triggerArray).addClass(g.COLLAPSED).attr("aria-expanded", !1), 
                        this.setTransitioning(!0);
                        var s = function s() {
                            e.setTransitioning(!1), t(e._element).removeClass(g.COLLAPSING).addClass(g.COLLAPSE).trigger(_.HIDDEN);
                        };
                        return this._element.style[i] = "", r.supportsTransitionEnd() ? void t(this._element).one(r.TRANSITION_END, s).emulateTransitionEnd(u) : void s();
                    }
                }
            }, l.prototype.setTransitioning = function(t) {
                this._isTransitioning = t;
            }, l.prototype.dispose = function() {
                t.removeData(this._element, a), this._config = null, this._parent = null, this._element = null, 
                this._triggerArray = null, this._isTransitioning = null;
            }, l.prototype._getConfig = function(n) {
                return n = t.extend({}, d, n), n.toggle = Boolean(n.toggle), r.typeCheckConfig(e, n, f), 
                n;
            }, l.prototype._getDimension = function() {
                var e = t(this._element).hasClass(p.WIDTH);
                return e ? p.WIDTH : p.HEIGHT;
            }, l.prototype._getParent = function() {
                var e = this, n = t(this._config.parent)[0], i = '[data-toggle="collapse"][data-parent="' + this._config.parent + '"]';
                return t(n).find(i).each(function(t, n) {
                    e._addAriaAndCollapsedClass(l._getTargetFromElement(n), [ n ]);
                }), n;
            }, l.prototype._addAriaAndCollapsedClass = function(e, n) {
                if (e) {
                    var i = t(e).hasClass(g.SHOW);
                    e.setAttribute("aria-expanded", i), n.length && t(n).toggleClass(g.COLLAPSED, !i).attr("aria-expanded", i);
                }
            }, l._getTargetFromElement = function(e) {
                var n = r.getSelectorFromElement(e);
                return n ? t(n)[0] : null;
            }, l._jQueryInterface = function(e) {
                return this.each(function() {
                    var n = t(this), o = n.data(a), r = t.extend({}, d, n.data(), "object" === ("undefined" == typeof e ? "undefined" : i(e)) && e);
                    if (!o && r.toggle && /show|hide/.test(e) && (r.toggle = !1), o || (o = new l(this, r), 
                    n.data(a, o)), "string" == typeof e) {
                        if (void 0 === o[e]) throw new Error('No method named "' + e + '"');
                        o[e]();
                    }
                });
            }, o(l, null, [ {
                key: "VERSION",
                get: function get() {
                    return s;
                }
            }, {
                key: "Default",
                get: function get() {
                    return d;
                }
            } ]), l;
        }();
        return t(document).on(_.CLICK_DATA_API, m.DATA_TOGGLE, function(e) {
            e.preventDefault();
            var n = E._getTargetFromElement(this), i = t(n).data(a), o = i ? "toggle" : t(this).data();
            E._jQueryInterface.call(t(n), o);
        }), t.fn[e] = E._jQueryInterface, t.fn[e].Constructor = E, t.fn[e].noConflict = function() {
            return t.fn[e] = c, E._jQueryInterface;
        }, E;
    }(jQuery), function(t) {
        var e = "dropdown", i = "4.0.0-alpha.6", s = "bs.dropdown", a = "." + s, l = ".data-api", h = t.fn[e], c = 27, u = 38, d = 40, f = 3, _ = {
            HIDE: "hide" + a,
            HIDDEN: "hidden" + a,
            SHOW: "show" + a,
            SHOWN: "shown" + a,
            CLICK: "click" + a,
            CLICK_DATA_API: "click" + a + l,
            FOCUSIN_DATA_API: "focusin" + a + l,
            KEYDOWN_DATA_API: "keydown" + a + l
        }, g = {
            BACKDROP: "dropdown-backdrop",
            DISABLED: "disabled",
            SHOW: "show"
        }, p = {
            BACKDROP: ".dropdown-backdrop",
            DATA_TOGGLE: '[data-toggle="dropdown"]',
            FORM_CHILD: ".dropdown form",
            ROLE_MENU: '[role="menu"]',
            ROLE_LISTBOX: '[role="listbox"]',
            NAVBAR_NAV: ".navbar-nav",
            VISIBLE_ITEMS: '[role="menu"] li:not(.disabled) a, [role="listbox"] li:not(.disabled) a'
        }, m = function() {
            function e(t) {
                n(this, e), this._element = t, this._addEventListeners();
            }
            return e.prototype.toggle = function() {
                if (this.disabled || t(this).hasClass(g.DISABLED)) return !1;
                var n = e._getParentFromElement(this), i = t(n).hasClass(g.SHOW);
                if (e._clearMenus(), i) return !1;
                if ("ontouchstart" in document.documentElement && !t(n).closest(p.NAVBAR_NAV).length) {
                    var o = document.createElement("div");
                    o.className = g.BACKDROP, t(o).insertBefore(this), t(o).on("click", e._clearMenus);
                }
                var r = {
                    relatedTarget: this
                }, s = t.Event(_.SHOW, r);
                return t(n).trigger(s), !s.isDefaultPrevented() && (this.focus(), this.setAttribute("aria-expanded", !0), 
                t(n).toggleClass(g.SHOW), t(n).trigger(t.Event(_.SHOWN, r)), !1);
            }, e.prototype.dispose = function() {
                t.removeData(this._element, s), t(this._element).off(a), this._element = null;
            }, e.prototype._addEventListeners = function() {
                t(this._element).on(_.CLICK, this.toggle);
            }, e._jQueryInterface = function(n) {
                return this.each(function() {
                    var i = t(this).data(s);
                    if (i || (i = new e(this), t(this).data(s, i)), "string" == typeof n) {
                        if (void 0 === i[n]) throw new Error('No method named "' + n + '"');
                        i[n].call(this);
                    }
                });
            }, e._clearMenus = function(n) {
                if (!n || n.which !== f) {
                    var i = t(p.BACKDROP)[0];
                    i && i.parentNode.removeChild(i);
                    for (var o = t.makeArray(t(p.DATA_TOGGLE)), r = 0; r < o.length; r++) {
                        var s = e._getParentFromElement(o[r]), a = {
                            relatedTarget: o[r]
                        };
                        if (t(s).hasClass(g.SHOW) && !(n && ("click" === n.type && /input|textarea/i.test(n.target.tagName) || "focusin" === n.type) && t.contains(s, n.target))) {
                            var l = t.Event(_.HIDE, a);
                            t(s).trigger(l), l.isDefaultPrevented() || (o[r].setAttribute("aria-expanded", "false"), 
                            t(s).removeClass(g.SHOW).trigger(t.Event(_.HIDDEN, a)));
                        }
                    }
                }
            }, e._getParentFromElement = function(e) {
                var n = void 0, i = r.getSelectorFromElement(e);
                return i && (n = t(i)[0]), n || e.parentNode;
            }, e._dataApiKeydownHandler = function(n) {
                if (/(38|40|27|32)/.test(n.which) && !/input|textarea/i.test(n.target.tagName) && (n.preventDefault(), 
                n.stopPropagation(), !this.disabled && !t(this).hasClass(g.DISABLED))) {
                    var i = e._getParentFromElement(this), o = t(i).hasClass(g.SHOW);
                    if (!o && n.which !== c || o && n.which === c) {
                        if (n.which === c) {
                            var r = t(i).find(p.DATA_TOGGLE)[0];
                            t(r).trigger("focus");
                        }
                        return void t(this).trigger("click");
                    }
                    var s = t(i).find(p.VISIBLE_ITEMS).get();
                    if (s.length) {
                        var a = s.indexOf(n.target);
                        n.which === u && a > 0 && a--, n.which === d && a < s.length - 1 && a++, a < 0 && (a = 0), 
                        s[a].focus();
                    }
                }
            }, o(e, null, [ {
                key: "VERSION",
                get: function get() {
                    return i;
                }
            } ]), e;
        }();
        return t(document).on(_.KEYDOWN_DATA_API, p.DATA_TOGGLE, m._dataApiKeydownHandler).on(_.KEYDOWN_DATA_API, p.ROLE_MENU, m._dataApiKeydownHandler).on(_.KEYDOWN_DATA_API, p.ROLE_LISTBOX, m._dataApiKeydownHandler).on(_.CLICK_DATA_API + " " + _.FOCUSIN_DATA_API, m._clearMenus).on(_.CLICK_DATA_API, p.DATA_TOGGLE, m.prototype.toggle).on(_.CLICK_DATA_API, p.FORM_CHILD, function(t) {
            t.stopPropagation();
        }), t.fn[e] = m._jQueryInterface, t.fn[e].Constructor = m, t.fn[e].noConflict = function() {
            return t.fn[e] = h, m._jQueryInterface;
        }, m;
    }(jQuery), function(t) {
        var e = "modal", s = "4.0.0-alpha.6", a = "bs.modal", l = "." + a, h = ".data-api", c = t.fn[e], u = 300, d = 150, f = 27, _ = {
            backdrop: !0,
            keyboard: !0,
            focus: !0,
            show: !0
        }, g = {
            backdrop: "(boolean|string)",
            keyboard: "boolean",
            focus: "boolean",
            show: "boolean"
        }, p = {
            HIDE: "hide" + l,
            HIDDEN: "hidden" + l,
            SHOW: "show" + l,
            SHOWN: "shown" + l,
            FOCUSIN: "focusin" + l,
            RESIZE: "resize" + l,
            CLICK_DISMISS: "click.dismiss" + l,
            KEYDOWN_DISMISS: "keydown.dismiss" + l,
            MOUSEUP_DISMISS: "mouseup.dismiss" + l,
            MOUSEDOWN_DISMISS: "mousedown.dismiss" + l,
            CLICK_DATA_API: "click" + l + h
        }, m = {
            SCROLLBAR_MEASURER: "modal-scrollbar-measure",
            BACKDROP: "modal-backdrop",
            OPEN: "modal-open",
            FADE: "fade",
            SHOW: "show"
        }, E = {
            DIALOG: ".modal-dialog",
            DATA_TOGGLE: '[data-toggle="modal"]',
            DATA_DISMISS: '[data-dismiss="modal"]',
            FIXED_CONTENT: ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top"
        }, v = function() {
            function h(e, i) {
                n(this, h), this._config = this._getConfig(i), this._element = e, this._dialog = t(e).find(E.DIALOG)[0], 
                this._backdrop = null, this._isShown = !1, this._isBodyOverflowing = !1, this._ignoreBackdropClick = !1, 
                this._isTransitioning = !1, this._originalBodyPadding = 0, this._scrollbarWidth = 0;
            }
            return h.prototype.toggle = function(t) {
                return this._isShown ? this.hide() : this.show(t);
            }, h.prototype.show = function(e) {
                var n = this;
                if (this._isTransitioning) throw new Error("Modal is transitioning");
                r.supportsTransitionEnd() && t(this._element).hasClass(m.FADE) && (this._isTransitioning = !0);
                var i = t.Event(p.SHOW, {
                    relatedTarget: e
                });
                t(this._element).trigger(i), this._isShown || i.isDefaultPrevented() || (this._isShown = !0, 
                this._checkScrollbar(), this._setScrollbar(), t(document.body).addClass(m.OPEN), 
                this._setEscapeEvent(), this._setResizeEvent(), t(this._element).on(p.CLICK_DISMISS, E.DATA_DISMISS, function(t) {
                    return n.hide(t);
                }), t(this._dialog).on(p.MOUSEDOWN_DISMISS, function() {
                    t(n._element).one(p.MOUSEUP_DISMISS, function(e) {
                        t(e.target).is(n._element) && (n._ignoreBackdropClick = !0);
                    });
                }), this._showBackdrop(function() {
                    return n._showElement(e);
                }));
            }, h.prototype.hide = function(e) {
                var n = this;
                if (e && e.preventDefault(), this._isTransitioning) throw new Error("Modal is transitioning");
                var i = r.supportsTransitionEnd() && t(this._element).hasClass(m.FADE);
                i && (this._isTransitioning = !0);
                var o = t.Event(p.HIDE);
                t(this._element).trigger(o), this._isShown && !o.isDefaultPrevented() && (this._isShown = !1, 
                this._setEscapeEvent(), this._setResizeEvent(), t(document).off(p.FOCUSIN), t(this._element).removeClass(m.SHOW), 
                t(this._element).off(p.CLICK_DISMISS), t(this._dialog).off(p.MOUSEDOWN_DISMISS), 
                i ? t(this._element).one(r.TRANSITION_END, function(t) {
                    return n._hideModal(t);
                }).emulateTransitionEnd(u) : this._hideModal());
            }, h.prototype.dispose = function() {
                t.removeData(this._element, a), t(window, document, this._element, this._backdrop).off(l), 
                this._config = null, this._element = null, this._dialog = null, this._backdrop = null, 
                this._isShown = null, this._isBodyOverflowing = null, this._ignoreBackdropClick = null, 
                this._originalBodyPadding = null, this._scrollbarWidth = null;
            }, h.prototype._getConfig = function(n) {
                return n = t.extend({}, _, n), r.typeCheckConfig(e, n, g), n;
            }, h.prototype._showElement = function(e) {
                var n = this, i = r.supportsTransitionEnd() && t(this._element).hasClass(m.FADE);
                this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE || document.body.appendChild(this._element), 
                this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), 
                this._element.scrollTop = 0, i && r.reflow(this._element), t(this._element).addClass(m.SHOW), 
                this._config.focus && this._enforceFocus();
                var o = t.Event(p.SHOWN, {
                    relatedTarget: e
                }), s = function s() {
                    n._config.focus && n._element.focus(), n._isTransitioning = !1, t(n._element).trigger(o);
                };
                i ? t(this._dialog).one(r.TRANSITION_END, s).emulateTransitionEnd(u) : s();
            }, h.prototype._enforceFocus = function() {
                var e = this;
                t(document).off(p.FOCUSIN).on(p.FOCUSIN, function(n) {
                    document === n.target || e._element === n.target || t(e._element).has(n.target).length || e._element.focus();
                });
            }, h.prototype._setEscapeEvent = function() {
                var e = this;
                this._isShown && this._config.keyboard ? t(this._element).on(p.KEYDOWN_DISMISS, function(t) {
                    t.which === f && e.hide();
                }) : this._isShown || t(this._element).off(p.KEYDOWN_DISMISS);
            }, h.prototype._setResizeEvent = function() {
                var e = this;
                this._isShown ? t(window).on(p.RESIZE, function(t) {
                    return e._handleUpdate(t);
                }) : t(window).off(p.RESIZE);
            }, h.prototype._hideModal = function() {
                var e = this;
                this._element.style.display = "none", this._element.setAttribute("aria-hidden", "true"), 
                this._isTransitioning = !1, this._showBackdrop(function() {
                    t(document.body).removeClass(m.OPEN), e._resetAdjustments(), e._resetScrollbar(), 
                    t(e._element).trigger(p.HIDDEN);
                });
            }, h.prototype._removeBackdrop = function() {
                this._backdrop && (t(this._backdrop).remove(), this._backdrop = null);
            }, h.prototype._showBackdrop = function(e) {
                var n = this, i = t(this._element).hasClass(m.FADE) ? m.FADE : "";
                if (this._isShown && this._config.backdrop) {
                    var o = r.supportsTransitionEnd() && i;
                    if (this._backdrop = document.createElement("div"), this._backdrop.className = m.BACKDROP, 
                    i && t(this._backdrop).addClass(i), t(this._backdrop).appendTo(document.body), t(this._element).on(p.CLICK_DISMISS, function(t) {
                        return n._ignoreBackdropClick ? void (n._ignoreBackdropClick = !1) : void (t.target === t.currentTarget && ("static" === n._config.backdrop ? n._element.focus() : n.hide()));
                    }), o && r.reflow(this._backdrop), t(this._backdrop).addClass(m.SHOW), !e) return;
                    if (!o) return void e();
                    t(this._backdrop).one(r.TRANSITION_END, e).emulateTransitionEnd(d);
                } else if (!this._isShown && this._backdrop) {
                    t(this._backdrop).removeClass(m.SHOW);
                    var s = function s() {
                        n._removeBackdrop(), e && e();
                    };
                    r.supportsTransitionEnd() && t(this._element).hasClass(m.FADE) ? t(this._backdrop).one(r.TRANSITION_END, s).emulateTransitionEnd(d) : s();
                } else e && e();
            }, h.prototype._handleUpdate = function() {
                this._adjustDialog();
            }, h.prototype._adjustDialog = function() {
                var t = this._element.scrollHeight > document.documentElement.clientHeight;
                !this._isBodyOverflowing && t && (this._element.style.paddingLeft = this._scrollbarWidth + "px"), 
                this._isBodyOverflowing && !t && (this._element.style.paddingRight = this._scrollbarWidth + "px");
            }, h.prototype._resetAdjustments = function() {
                this._element.style.paddingLeft = "", this._element.style.paddingRight = "";
            }, h.prototype._checkScrollbar = function() {
                this._isBodyOverflowing = document.body.clientWidth < window.innerWidth, this._scrollbarWidth = this._getScrollbarWidth();
            }, h.prototype._setScrollbar = function() {
                var e = parseInt(t(E.FIXED_CONTENT).css("padding-right") || 0, 10);
                this._originalBodyPadding = document.body.style.paddingRight || "", this._isBodyOverflowing && (document.body.style.paddingRight = e + this._scrollbarWidth + "px");
            }, h.prototype._resetScrollbar = function() {
                document.body.style.paddingRight = this._originalBodyPadding;
            }, h.prototype._getScrollbarWidth = function() {
                var t = document.createElement("div");
                t.className = m.SCROLLBAR_MEASURER, document.body.appendChild(t);
                var e = t.offsetWidth - t.clientWidth;
                return document.body.removeChild(t), e;
            }, h._jQueryInterface = function(e, n) {
                return this.each(function() {
                    var o = t(this).data(a), r = t.extend({}, h.Default, t(this).data(), "object" === ("undefined" == typeof e ? "undefined" : i(e)) && e);
                    if (o || (o = new h(this, r), t(this).data(a, o)), "string" == typeof e) {
                        if (void 0 === o[e]) throw new Error('No method named "' + e + '"');
                        o[e](n);
                    } else r.show && o.show(n);
                });
            }, o(h, null, [ {
                key: "VERSION",
                get: function get() {
                    return s;
                }
            }, {
                key: "Default",
                get: function get() {
                    return _;
                }
            } ]), h;
        }();
        return t(document).on(p.CLICK_DATA_API, E.DATA_TOGGLE, function(e) {
            var n = this, i = void 0, o = r.getSelectorFromElement(this);
            o && (i = t(o)[0]);
            var s = t(i).data(a) ? "toggle" : t.extend({}, t(i).data(), t(this).data());
            "A" !== this.tagName && "AREA" !== this.tagName || e.preventDefault();
            var l = t(i).one(p.SHOW, function(e) {
                e.isDefaultPrevented() || l.one(p.HIDDEN, function() {
                    t(n).is(":visible") && n.focus();
                });
            });
            v._jQueryInterface.call(t(i), s, this);
        }), t.fn[e] = v._jQueryInterface, t.fn[e].Constructor = v, t.fn[e].noConflict = function() {
            return t.fn[e] = c, v._jQueryInterface;
        }, v;
    }(jQuery), function(t) {
        var e = "scrollspy", s = "4.0.0-alpha.6", a = "bs.scrollspy", l = "." + a, h = ".data-api", c = t.fn[e], u = {
            offset: 10,
            method: "auto",
            target: ""
        }, d = {
            offset: "number",
            method: "string",
            target: "(string|element)"
        }, f = {
            ACTIVATE: "activate" + l,
            SCROLL: "scroll" + l,
            LOAD_DATA_API: "load" + l + h
        }, _ = {
            DROPDOWN_ITEM: "dropdown-item",
            DROPDOWN_MENU: "dropdown-menu",
            NAV_LINK: "nav-link",
            NAV: "nav",
            ACTIVE: "active"
        }, g = {
            DATA_SPY: '[data-spy="scroll"]',
            ACTIVE: ".active",
            LIST_ITEM: ".list-item",
            LI: "li",
            LI_DROPDOWN: "li.dropdown",
            NAV_LINKS: ".nav-link",
            DROPDOWN: ".dropdown",
            DROPDOWN_ITEMS: ".dropdown-item",
            DROPDOWN_TOGGLE: ".dropdown-toggle"
        }, p = {
            OFFSET: "offset",
            POSITION: "position"
        }, m = function() {
            function h(e, i) {
                var o = this;
                n(this, h), this._element = e, this._scrollElement = "BODY" === e.tagName ? window : e, 
                this._config = this._getConfig(i), this._selector = this._config.target + " " + g.NAV_LINKS + "," + (this._config.target + " " + g.DROPDOWN_ITEMS), 
                this._offsets = [], this._targets = [], this._activeTarget = null, this._scrollHeight = 0, 
                t(this._scrollElement).on(f.SCROLL, function(t) {
                    return o._process(t);
                }), this.refresh(), this._process();
            }
            return h.prototype.refresh = function() {
                var e = this, n = this._scrollElement !== this._scrollElement.window ? p.POSITION : p.OFFSET, i = "auto" === this._config.method ? n : this._config.method, o = i === p.POSITION ? this._getScrollTop() : 0;
                this._offsets = [], this._targets = [], this._scrollHeight = this._getScrollHeight();
                var s = t.makeArray(t(this._selector));
                s.map(function(e) {
                    var n = void 0, s = r.getSelectorFromElement(e);
                    return s && (n = t(s)[0]), n && (n.offsetWidth || n.offsetHeight) ? [ t(n)[i]().top + o, s ] : null;
                }).filter(function(t) {
                    return t;
                }).sort(function(t, e) {
                    return t[0] - e[0];
                }).forEach(function(t) {
                    e._offsets.push(t[0]), e._targets.push(t[1]);
                });
            }, h.prototype.dispose = function() {
                t.removeData(this._element, a), t(this._scrollElement).off(l), this._element = null, 
                this._scrollElement = null, this._config = null, this._selector = null, this._offsets = null, 
                this._targets = null, this._activeTarget = null, this._scrollHeight = null;
            }, h.prototype._getConfig = function(n) {
                if (n = t.extend({}, u, n), "string" != typeof n.target) {
                    var i = t(n.target).attr("id");
                    i || (i = r.getUID(e), t(n.target).attr("id", i)), n.target = "#" + i;
                }
                return r.typeCheckConfig(e, n, d), n;
            }, h.prototype._getScrollTop = function() {
                return this._scrollElement === window ? this._scrollElement.pageYOffset : this._scrollElement.scrollTop;
            }, h.prototype._getScrollHeight = function() {
                return this._scrollElement.scrollHeight || Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
            }, h.prototype._getOffsetHeight = function() {
                return this._scrollElement === window ? window.innerHeight : this._scrollElement.offsetHeight;
            }, h.prototype._process = function() {
                var t = this._getScrollTop() + this._config.offset, e = this._getScrollHeight(), n = this._config.offset + e - this._getOffsetHeight();
                if (this._scrollHeight !== e && this.refresh(), t >= n) {
                    var i = this._targets[this._targets.length - 1];
                    return void (this._activeTarget !== i && this._activate(i));
                }
                if (this._activeTarget && t < this._offsets[0] && this._offsets[0] > 0) return this._activeTarget = null, 
                void this._clear();
                for (var o = this._offsets.length; o--; ) {
                    var r = this._activeTarget !== this._targets[o] && t >= this._offsets[o] && (void 0 === this._offsets[o + 1] || t < this._offsets[o + 1]);
                    r && this._activate(this._targets[o]);
                }
            }, h.prototype._activate = function(e) {
                this._activeTarget = e, this._clear();
                var n = this._selector.split(",");
                n = n.map(function(t) {
                    return t + '[data-target="' + e + '"],' + (t + '[href="' + e + '"]');
                });
                var i = t(n.join(","));
                i.hasClass(_.DROPDOWN_ITEM) ? (i.closest(g.DROPDOWN).find(g.DROPDOWN_TOGGLE).addClass(_.ACTIVE), 
                i.addClass(_.ACTIVE)) : i.parents(g.LI).find("> " + g.NAV_LINKS).addClass(_.ACTIVE), 
                t(this._scrollElement).trigger(f.ACTIVATE, {
                    relatedTarget: e
                });
            }, h.prototype._clear = function() {
                t(this._selector).filter(g.ACTIVE).removeClass(_.ACTIVE);
            }, h._jQueryInterface = function(e) {
                return this.each(function() {
                    var n = t(this).data(a), o = "object" === ("undefined" == typeof e ? "undefined" : i(e)) && e;
                    if (n || (n = new h(this, o), t(this).data(a, n)), "string" == typeof e) {
                        if (void 0 === n[e]) throw new Error('No method named "' + e + '"');
                        n[e]();
                    }
                });
            }, o(h, null, [ {
                key: "VERSION",
                get: function get() {
                    return s;
                }
            }, {
                key: "Default",
                get: function get() {
                    return u;
                }
            } ]), h;
        }();
        return t(window).on(f.LOAD_DATA_API, function() {
            for (var e = t.makeArray(t(g.DATA_SPY)), n = e.length; n--; ) {
                var i = t(e[n]);
                m._jQueryInterface.call(i, i.data());
            }
        }), t.fn[e] = m._jQueryInterface, t.fn[e].Constructor = m, t.fn[e].noConflict = function() {
            return t.fn[e] = c, m._jQueryInterface;
        }, m;
    }(jQuery), function(t) {
        var e = "tab", i = "4.0.0-alpha.6", s = "bs.tab", a = "." + s, l = ".data-api", h = t.fn[e], c = 150, u = {
            HIDE: "hide" + a,
            HIDDEN: "hidden" + a,
            SHOW: "show" + a,
            SHOWN: "shown" + a,
            CLICK_DATA_API: "click" + a + l
        }, d = {
            DROPDOWN_MENU: "dropdown-menu",
            ACTIVE: "active",
            DISABLED: "disabled",
            FADE: "fade",
            SHOW: "show"
        }, f = {
            A: "a",
            LI: "li",
            DROPDOWN: ".dropdown",
            LIST: "ul:not(.dropdown-menu), ol:not(.dropdown-menu), nav:not(.dropdown-menu)",
            FADE_CHILD: "> .nav-item .fade, > .fade",
            ACTIVE: ".active",
            ACTIVE_CHILD: "> .nav-item > .active, > .active",
            DATA_TOGGLE: '[data-toggle="tab"], [data-toggle="pill"]',
            DROPDOWN_TOGGLE: ".dropdown-toggle",
            DROPDOWN_ACTIVE_CHILD: "> .dropdown-menu .active"
        }, _ = function() {
            function e(t) {
                n(this, e), this._element = t;
            }
            return e.prototype.show = function() {
                var e = this;
                if (!(this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && t(this._element).hasClass(d.ACTIVE) || t(this._element).hasClass(d.DISABLED))) {
                    var n = void 0, i = void 0, o = t(this._element).closest(f.LIST)[0], s = r.getSelectorFromElement(this._element);
                    o && (i = t.makeArray(t(o).find(f.ACTIVE)), i = i[i.length - 1]);
                    var a = t.Event(u.HIDE, {
                        relatedTarget: this._element
                    }), l = t.Event(u.SHOW, {
                        relatedTarget: i
                    });
                    if (i && t(i).trigger(a), t(this._element).trigger(l), !l.isDefaultPrevented() && !a.isDefaultPrevented()) {
                        s && (n = t(s)[0]), this._activate(this._element, o);
                        var h = function h() {
                            var n = t.Event(u.HIDDEN, {
                                relatedTarget: e._element
                            }), o = t.Event(u.SHOWN, {
                                relatedTarget: i
                            });
                            t(i).trigger(n), t(e._element).trigger(o);
                        };
                        n ? this._activate(n, n.parentNode, h) : h();
                    }
                }
            }, e.prototype.dispose = function() {
                t.removeClass(this._element, s), this._element = null;
            }, e.prototype._activate = function(e, n, i) {
                var o = this, s = t(n).find(f.ACTIVE_CHILD)[0], a = i && r.supportsTransitionEnd() && (s && t(s).hasClass(d.FADE) || Boolean(t(n).find(f.FADE_CHILD)[0])), l = function l() {
                    return o._transitionComplete(e, s, a, i);
                };
                s && a ? t(s).one(r.TRANSITION_END, l).emulateTransitionEnd(c) : l(), s && t(s).removeClass(d.SHOW);
            }, e.prototype._transitionComplete = function(e, n, i, o) {
                if (n) {
                    t(n).removeClass(d.ACTIVE);
                    var s = t(n.parentNode).find(f.DROPDOWN_ACTIVE_CHILD)[0];
                    s && t(s).removeClass(d.ACTIVE), n.setAttribute("aria-expanded", !1);
                }
                if (t(e).addClass(d.ACTIVE), e.setAttribute("aria-expanded", !0), i ? (r.reflow(e), 
                t(e).addClass(d.SHOW)) : t(e).removeClass(d.FADE), e.parentNode && t(e.parentNode).hasClass(d.DROPDOWN_MENU)) {
                    var a = t(e).closest(f.DROPDOWN)[0];
                    a && t(a).find(f.DROPDOWN_TOGGLE).addClass(d.ACTIVE), e.setAttribute("aria-expanded", !0);
                }
                o && o();
            }, e._jQueryInterface = function(n) {
                return this.each(function() {
                    var i = t(this), o = i.data(s);
                    if (o || (o = new e(this), i.data(s, o)), "string" == typeof n) {
                        if (void 0 === o[n]) throw new Error('No method named "' + n + '"');
                        o[n]();
                    }
                });
            }, o(e, null, [ {
                key: "VERSION",
                get: function get() {
                    return i;
                }
            } ]), e;
        }();
        return t(document).on(u.CLICK_DATA_API, f.DATA_TOGGLE, function(e) {
            e.preventDefault(), _._jQueryInterface.call(t(this), "show");
        }), t.fn[e] = _._jQueryInterface, t.fn[e].Constructor = _, t.fn[e].noConflict = function() {
            return t.fn[e] = h, _._jQueryInterface;
        }, _;
    }(jQuery), function(t) {
        if ("undefined" == typeof Tether) throw new Error("Bootstrap tooltips require Tether (http://tether.io/)");
        var e = "tooltip", s = "4.0.0-alpha.6", a = "bs.tooltip", l = "." + a, h = t.fn[e], c = 150, u = "bs-tether", d = {
            animation: !0,
            template: '<div class="tooltip" role="tooltip"><div class="tooltip-inner"></div></div>',
            trigger: "hover focus",
            title: "",
            delay: 0,
            html: !1,
            selector: !1,
            placement: "top",
            offset: "0 0",
            constraints: [],
            container: !1
        }, f = {
            animation: "boolean",
            template: "string",
            title: "(string|element|function)",
            trigger: "string",
            delay: "(number|object)",
            html: "boolean",
            selector: "(string|boolean)",
            placement: "(string|function)",
            offset: "string",
            constraints: "array",
            container: "(string|element|boolean)"
        }, _ = {
            TOP: "bottom center",
            RIGHT: "middle left",
            BOTTOM: "top center",
            LEFT: "middle right"
        }, g = {
            SHOW: "show",
            OUT: "out"
        }, p = {
            HIDE: "hide" + l,
            HIDDEN: "hidden" + l,
            SHOW: "show" + l,
            SHOWN: "shown" + l,
            INSERTED: "inserted" + l,
            CLICK: "click" + l,
            FOCUSIN: "focusin" + l,
            FOCUSOUT: "focusout" + l,
            MOUSEENTER: "mouseenter" + l,
            MOUSELEAVE: "mouseleave" + l
        }, m = {
            FADE: "fade",
            SHOW: "show"
        }, E = {
            TOOLTIP: ".tooltip",
            TOOLTIP_INNER: ".tooltip-inner"
        }, v = {
            element: !1,
            enabled: !1
        }, T = {
            HOVER: "hover",
            FOCUS: "focus",
            CLICK: "click",
            MANUAL: "manual"
        }, I = function() {
            function h(t, e) {
                n(this, h), this._isEnabled = !0, this._timeout = 0, this._hoverState = "", this._activeTrigger = {}, 
                this._isTransitioning = !1, this._tether = null, this.element = t, this.config = this._getConfig(e), 
                this.tip = null, this._setListeners();
            }
            return h.prototype.enable = function() {
                this._isEnabled = !0;
            }, h.prototype.disable = function() {
                this._isEnabled = !1;
            }, h.prototype.toggleEnabled = function() {
                this._isEnabled = !this._isEnabled;
            }, h.prototype.toggle = function(e) {
                if (e) {
                    var n = this.constructor.DATA_KEY, i = t(e.currentTarget).data(n);
                    i || (i = new this.constructor(e.currentTarget, this._getDelegateConfig()), t(e.currentTarget).data(n, i)), 
                    i._activeTrigger.click = !i._activeTrigger.click, i._isWithActiveTrigger() ? i._enter(null, i) : i._leave(null, i);
                } else {
                    if (t(this.getTipElement()).hasClass(m.SHOW)) return void this._leave(null, this);
                    this._enter(null, this);
                }
            }, h.prototype.dispose = function() {
                clearTimeout(this._timeout), this.cleanupTether(), t.removeData(this.element, this.constructor.DATA_KEY), 
                t(this.element).off(this.constructor.EVENT_KEY), t(this.element).closest(".modal").off("hide.bs.modal"), 
                this.tip && t(this.tip).remove(), this._isEnabled = null, this._timeout = null, 
                this._hoverState = null, this._activeTrigger = null, this._tether = null, this.element = null, 
                this.config = null, this.tip = null;
            }, h.prototype.show = function() {
                var e = this;
                if ("none" === t(this.element).css("display")) throw new Error("Please use show on visible elements");
                var n = t.Event(this.constructor.Event.SHOW);
                if (this.isWithContent() && this._isEnabled) {
                    if (this._isTransitioning) throw new Error("Tooltip is transitioning");
                    t(this.element).trigger(n);
                    var i = t.contains(this.element.ownerDocument.documentElement, this.element);
                    if (n.isDefaultPrevented() || !i) return;
                    var o = this.getTipElement(), s = r.getUID(this.constructor.NAME);
                    o.setAttribute("id", s), this.element.setAttribute("aria-describedby", s), this.setContent(), 
                    this.config.animation && t(o).addClass(m.FADE);
                    var a = "function" == typeof this.config.placement ? this.config.placement.call(this, o, this.element) : this.config.placement, l = this._getAttachment(a), c = this.config.container === !1 ? document.body : t(this.config.container);
                    t(o).data(this.constructor.DATA_KEY, this).appendTo(c), t(this.element).trigger(this.constructor.Event.INSERTED), 
                    this._tether = new Tether({
                        attachment: l,
                        element: o,
                        target: this.element,
                        classes: v,
                        classPrefix: u,
                        offset: this.config.offset,
                        constraints: this.config.constraints,
                        addTargetClasses: !1
                    }), r.reflow(o), this._tether.position(), t(o).addClass(m.SHOW);
                    var d = function d() {
                        var n = e._hoverState;
                        e._hoverState = null, e._isTransitioning = !1, t(e.element).trigger(e.constructor.Event.SHOWN), 
                        n === g.OUT && e._leave(null, e);
                    };
                    if (r.supportsTransitionEnd() && t(this.tip).hasClass(m.FADE)) return this._isTransitioning = !0, 
                    void t(this.tip).one(r.TRANSITION_END, d).emulateTransitionEnd(h._TRANSITION_DURATION);
                    d();
                }
            }, h.prototype.hide = function(e) {
                var n = this, i = this.getTipElement(), o = t.Event(this.constructor.Event.HIDE);
                if (this._isTransitioning) throw new Error("Tooltip is transitioning");
                var s = function s() {
                    n._hoverState !== g.SHOW && i.parentNode && i.parentNode.removeChild(i), n.element.removeAttribute("aria-describedby"), 
                    t(n.element).trigger(n.constructor.Event.HIDDEN), n._isTransitioning = !1, n.cleanupTether(), 
                    e && e();
                };
                t(this.element).trigger(o), o.isDefaultPrevented() || (t(i).removeClass(m.SHOW), 
                this._activeTrigger[T.CLICK] = !1, this._activeTrigger[T.FOCUS] = !1, this._activeTrigger[T.HOVER] = !1, 
                r.supportsTransitionEnd() && t(this.tip).hasClass(m.FADE) ? (this._isTransitioning = !0, 
                t(i).one(r.TRANSITION_END, s).emulateTransitionEnd(c)) : s(), this._hoverState = "");
            }, h.prototype.isWithContent = function() {
                return Boolean(this.getTitle());
            }, h.prototype.getTipElement = function() {
                return this.tip = this.tip || t(this.config.template)[0];
            }, h.prototype.setContent = function() {
                var e = t(this.getTipElement());
                this.setElementContent(e.find(E.TOOLTIP_INNER), this.getTitle()), e.removeClass(m.FADE + " " + m.SHOW), 
                this.cleanupTether();
            }, h.prototype.setElementContent = function(e, n) {
                var o = this.config.html;
                "object" === ("undefined" == typeof n ? "undefined" : i(n)) && (n.nodeType || n.jquery) ? o ? t(n).parent().is(e) || e.empty().append(n) : e.text(t(n).text()) : e[o ? "html" : "text"](n);
            }, h.prototype.getTitle = function() {
                var t = this.element.getAttribute("data-original-title");
                return t || (t = "function" == typeof this.config.title ? this.config.title.call(this.element) : this.config.title), 
                t;
            }, h.prototype.cleanupTether = function() {
                this._tether && this._tether.destroy();
            }, h.prototype._getAttachment = function(t) {
                return _[t.toUpperCase()];
            }, h.prototype._setListeners = function() {
                var e = this, n = this.config.trigger.split(" ");
                n.forEach(function(n) {
                    if ("click" === n) t(e.element).on(e.constructor.Event.CLICK, e.config.selector, function(t) {
                        return e.toggle(t);
                    }); else if (n !== T.MANUAL) {
                        var i = n === T.HOVER ? e.constructor.Event.MOUSEENTER : e.constructor.Event.FOCUSIN, o = n === T.HOVER ? e.constructor.Event.MOUSELEAVE : e.constructor.Event.FOCUSOUT;
                        t(e.element).on(i, e.config.selector, function(t) {
                            return e._enter(t);
                        }).on(o, e.config.selector, function(t) {
                            return e._leave(t);
                        });
                    }
                    t(e.element).closest(".modal").on("hide.bs.modal", function() {
                        return e.hide();
                    });
                }), this.config.selector ? this.config = t.extend({}, this.config, {
                    trigger: "manual",
                    selector: ""
                }) : this._fixTitle();
            }, h.prototype._fixTitle = function() {
                var t = i(this.element.getAttribute("data-original-title"));
                (this.element.getAttribute("title") || "string" !== t) && (this.element.setAttribute("data-original-title", this.element.getAttribute("title") || ""), 
                this.element.setAttribute("title", ""));
            }, h.prototype._enter = function(e, n) {
                var i = this.constructor.DATA_KEY;
                return n = n || t(e.currentTarget).data(i), n || (n = new this.constructor(e.currentTarget, this._getDelegateConfig()), 
                t(e.currentTarget).data(i, n)), e && (n._activeTrigger["focusin" === e.type ? T.FOCUS : T.HOVER] = !0), 
                t(n.getTipElement()).hasClass(m.SHOW) || n._hoverState === g.SHOW ? void (n._hoverState = g.SHOW) : (clearTimeout(n._timeout), 
                n._hoverState = g.SHOW, n.config.delay && n.config.delay.show ? void (n._timeout = setTimeout(function() {
                    n._hoverState === g.SHOW && n.show();
                }, n.config.delay.show)) : void n.show());
            }, h.prototype._leave = function(e, n) {
                var i = this.constructor.DATA_KEY;
                if (n = n || t(e.currentTarget).data(i), n || (n = new this.constructor(e.currentTarget, this._getDelegateConfig()), 
                t(e.currentTarget).data(i, n)), e && (n._activeTrigger["focusout" === e.type ? T.FOCUS : T.HOVER] = !1), 
                !n._isWithActiveTrigger()) return clearTimeout(n._timeout), n._hoverState = g.OUT, 
                n.config.delay && n.config.delay.hide ? void (n._timeout = setTimeout(function() {
                    n._hoverState === g.OUT && n.hide();
                }, n.config.delay.hide)) : void n.hide();
            }, h.prototype._isWithActiveTrigger = function() {
                for (var t in this._activeTrigger) {
                    if (this._activeTrigger[t]) return !0;
                }
                return !1;
            }, h.prototype._getConfig = function(n) {
                return n = t.extend({}, this.constructor.Default, t(this.element).data(), n), n.delay && "number" == typeof n.delay && (n.delay = {
                    show: n.delay,
                    hide: n.delay
                }), r.typeCheckConfig(e, n, this.constructor.DefaultType), n;
            }, h.prototype._getDelegateConfig = function() {
                var t = {};
                if (this.config) for (var e in this.config) {
                    this.constructor.Default[e] !== this.config[e] && (t[e] = this.config[e]);
                }
                return t;
            }, h._jQueryInterface = function(e) {
                return this.each(function() {
                    var n = t(this).data(a), o = "object" === ("undefined" == typeof e ? "undefined" : i(e)) && e;
                    if ((n || !/dispose|hide/.test(e)) && (n || (n = new h(this, o), t(this).data(a, n)), 
                    "string" == typeof e)) {
                        if (void 0 === n[e]) throw new Error('No method named "' + e + '"');
                        n[e]();
                    }
                });
            }, o(h, null, [ {
                key: "VERSION",
                get: function get() {
                    return s;
                }
            }, {
                key: "Default",
                get: function get() {
                    return d;
                }
            }, {
                key: "NAME",
                get: function get() {
                    return e;
                }
            }, {
                key: "DATA_KEY",
                get: function get() {
                    return a;
                }
            }, {
                key: "Event",
                get: function get() {
                    return p;
                }
            }, {
                key: "EVENT_KEY",
                get: function get() {
                    return l;
                }
            }, {
                key: "DefaultType",
                get: function get() {
                    return f;
                }
            } ]), h;
        }();
        return t.fn[e] = I._jQueryInterface, t.fn[e].Constructor = I, t.fn[e].noConflict = function() {
            return t.fn[e] = h, I._jQueryInterface;
        }, I;
    }(jQuery));
    (function(r) {
        var a = "popover", l = "4.0.0-alpha.6", h = "bs.popover", c = "." + h, u = r.fn[a], d = r.extend({}, s.Default, {
            placement: "right",
            trigger: "click",
            content: "",
            template: '<div class="popover" role="tooltip"><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
        }), f = r.extend({}, s.DefaultType, {
            content: "(string|element|function)"
        }), _ = {
            FADE: "fade",
            SHOW: "show"
        }, g = {
            TITLE: ".popover-title",
            CONTENT: ".popover-content"
        }, p = {
            HIDE: "hide" + c,
            HIDDEN: "hidden" + c,
            SHOW: "show" + c,
            SHOWN: "shown" + c,
            INSERTED: "inserted" + c,
            CLICK: "click" + c,
            FOCUSIN: "focusin" + c,
            FOCUSOUT: "focusout" + c,
            MOUSEENTER: "mouseenter" + c,
            MOUSELEAVE: "mouseleave" + c
        }, m = function(s) {
            function u() {
                return n(this, u), t(this, s.apply(this, arguments));
            }
            return e(u, s), u.prototype.isWithContent = function() {
                return this.getTitle() || this._getContent();
            }, u.prototype.getTipElement = function() {
                return this.tip = this.tip || r(this.config.template)[0];
            }, u.prototype.setContent = function() {
                var t = r(this.getTipElement());
                this.setElementContent(t.find(g.TITLE), this.getTitle()), this.setElementContent(t.find(g.CONTENT), this._getContent()), 
                t.removeClass(_.FADE + " " + _.SHOW), this.cleanupTether();
            }, u.prototype._getContent = function() {
                return this.element.getAttribute("data-content") || ("function" == typeof this.config.content ? this.config.content.call(this.element) : this.config.content);
            }, u._jQueryInterface = function(t) {
                return this.each(function() {
                    var e = r(this).data(h), n = "object" === ("undefined" == typeof t ? "undefined" : i(t)) ? t : null;
                    if ((e || !/destroy|hide/.test(t)) && (e || (e = new u(this, n), r(this).data(h, e)), 
                    "string" == typeof t)) {
                        if (void 0 === e[t]) throw new Error('No method named "' + t + '"');
                        e[t]();
                    }
                });
            }, o(u, null, [ {
                key: "VERSION",
                get: function get() {
                    return l;
                }
            }, {
                key: "Default",
                get: function get() {
                    return d;
                }
            }, {
                key: "NAME",
                get: function get() {
                    return a;
                }
            }, {
                key: "DATA_KEY",
                get: function get() {
                    return h;
                }
            }, {
                key: "Event",
                get: function get() {
                    return p;
                }
            }, {
                key: "EVENT_KEY",
                get: function get() {
                    return c;
                }
            }, {
                key: "DefaultType",
                get: function get() {
                    return f;
                }
            } ]), u;
        }(s);
        return r.fn[a] = m._jQueryInterface, r.fn[a].Constructor = m, r.fn[a].noConflict = function() {
            return r.fn[a] = u, m._jQueryInterface;
        }, m;
    })(jQuery);
}();

"use strict";

function nextCalendarScreen(element) {
    var currentScreen = $(element).parent().parent().children(".Calendar__Screen");
    currentScreen.removeClass("Active");
    var nextScreen = $(currentScreen).next(".Calendar__Screen");
    nextScreen.addClass("Active");
}

function previousCalendarScreen(element) {
    var currentScreen = $(element).parent().parent().children(".Calendar__Screen");
    currentScreen.removeClass("Active");
    var prevScreen = $(currentScreen).prev(".Calendar__Screen");
    prevScreen.addClass("Active");
}

"use strict";

$(".Color__swatch").click(function() {
    $(".Color__swatch").removeClass("Active");
    $(this).addClass("Active");
});

"use strict";

function setFocusValue(element, value) {
    if (!$(element).val()) {
        $(element).val(value);
    }
}

function collapseAll(accordion, action) {
    $(accordion).collapse(action);
}

$(".checkAll").click(function() {
    var id = $(this).attr("id");
    $("." + id).prop("checked", this.checked);
});

function editInlineEditable() {
    $(".Inline-editable--enable").toggle();
    $(".Add-new-inline-editable").toggle();
    $(".Edit-inline-action").toggle();
    $(".Editable-check-text input").prop("disabled", function(i, v) {
        return !v;
    });
}

function setSelectedIcon(element) {
    $(element).parent().children().removeClass("Selected");
    $(element).addClass("Selected");
}

"use strict";

$("select").change(function() {
    if ($(this).val() == "modal-trigger") {
        $("#myModal").modal("show");
    }
});

"use strict";

$(".Hamburger").click(function() {
    $(this).toggleClass("Open");
    $(".Sub-header_bar").toggleClass("Hamburger-open");
    console.log("toggled");
});

"use strict";

$(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".Sub-header_bar").addClass("Sticky-header");
        $(".Header_bar").addClass("Only");
        $("html").addClass("W-Sticky-nav--en");
    } else {
        $(".Sub-header_bar").removeClass("Sticky-header");
        $(".Header_bar").removeClass("Only");
        $("html").removeClass("W-Sticky-nav--en");
    }
});

$(".Header_bar__alert").click(function() {
    $(".Header_bar__alert--notification").hide();
});

"use strict";

function addMarker(map, lat, long, contentString, type) {
    var label = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : null;
    var marker = new Marker({
        position: new google.maps.LatLng(lat, long),
        map: map,
        icon: "img/markers/" + type + ".svg",
        map_icon_label: label !== null ? '<i class="map-icon Icon--' + label + ' Icon--sm"></i>' : ""
    });
    var infowindow = new google.maps.InfoWindow({
        content: contentString,
        maxWidth: 480
    });
    marker.addListener("click", function() {
        infowindow.open(map, marker);
    });
}

"use strict";

$(".Radio__button--js .btn").click(function() {
    $(this).parent().children(".btn").removeClass("btn-primary Active").addClass("btn-outline-primary");
    $(this).removeClass("btn-outline-primary").addClass("btn-primary Active");
});

$(".Update__button--js .btn").click(function() {
    $(this).parent().children(".btn").html("Save").removeClass("btn btn-update").addClass("btn btn-save").toggleClass("hidden");
    $(this).removeClass("btn btn-save").html("Update").addClass("btn btn-update").toggleClass("show");
});

"use strict";

function multi_select_radioSelected(input) {
    $(input).parent().parent().find(".Selected").removeClass("Selected");
    $(input).parent().toggleClass("Selected");
}

"use strict";

function ribbonClick(element) {
    if ($(element).hasClass("Active")) {
        $(".Ribbon__header__wrap, .Ribbon__response, .Ribbon__header__chevron").removeClass("Active");
        $(".Response__content").slideUp();
    } else {
        $(".Ribbon__header__wrap, .Ribbon__response, .Ribbon__header__chevron").removeClass("Active");
        $(".Response__content").slideUp();
        $(element).parent().addClass("Active");
        $(element).toggleClass("Active");
        $(element).parent().parent().next(".Response__content").slideToggle();
        $(element).parent().parent().toggleClass("Active");
    }
}

function continueToNextRibbon(element) {
    $(".Ribbon__header__wrap, .Ribbon__response, .Ribbon__header__chevron").removeClass("Active");
    $(".Response__content").slideUp();
    $(element).parent().parent().next().next(".Response__content").slideDown();
    $(element).parent().parent().next(".Ribbon__response").addClass("Active");
    $(element).parent().parent().next().find(".Ribbon__header__wrap, .Ribbon__header__chevron").addClass("Active");
}

$(".collapse").on("shown.bs.collapse", function(e) {
    if (!$(e.target).hasClass("prevent_parent_collapse")) {
        $(this).prev().find(".fa-caret-down").removeClass("fa-caret-down").addClass("fa-caret-up");
        $(this).prev().find(".Hide-all").show();
        $(this).prev().find(".Show-all").hide();
    }
}).on("hidden.bs.collapse", function(e) {
    if (!$(e.target).hasClass("prevent_parent_collapse")) {
        $(this).prev().find(".fa-caret-up").removeClass("fa-caret-up").addClass("fa-caret-down");
        $(this).prev().find(".Hide-all").hide();
        $(this).prev().find(".Show-all").show();
    }
});

"use strict";

var riskIndicator = document.getElementById("Risk__indicator");

var updateButton = document.getElementById("Update_button");

var indicatorButton = document.getElementsByClassName("Risk_indicator_button");

var checkIndicatorText = document.getElementsByClassName("risk-text");

updateChange: updateButton.addEventListener("click", function() {
    console.log("Update Button Clicked!");
    riskIndicator.classList.toggle("active");
});

editState: updateButton.addEventListener("click", function() {
    for (i = 0; i < checkIndicatorText.length; i++) {
        console.log(checkIndicatorText[i]);
    }
});

saveButtonChange: updateButton.addEventListener("click", function() {
    if (updateButton.textContent === "Update") {
        updateButton.textContent = "Save";
    } else {
        updateButton.textContent = "Update";
    }
});

"use strict";

(function($, window, document, undefined) {
    "use strict";
})(jQuery, window, document);
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFnZW5jeS1hZG1pbi5qcyIsImFnZW5jeS1sb2dvLmpzIiwiYm9vdHN0cmFwLm1pbi5qcyIsImNhbGVuZGFyLmpzIiwiY29sb3ItcGFsZXR0ZS1waWNrLmpzIiwiZm9ybXMuanMiLCJpbml0aWFsX19kcm9wZG93bi1tb2RhbC10cmlnZ2VyLmpzIiwiaW5pdGlhbF9faGFtYnVyZ2VyLmpzIiwiaW5pdGlhbF9fc3RpY2t5LW5hdi5qcyIsIm1hcC5qcyIsInJhZGlvX19idXR0b25fX2hpZ2hsaWdodC5qcyIsInJlc3BvbnNlLXBsYW5fX211bHRpLXNlbGVjdC5qcyIsInJlc3BvbnNlLXBsYW5fX3JldmVhbC1yaWJib24uanMiLCJyaXNrX2luZGljYXRvcl9lZGl0aW5nX3N0YXRlLmpzIl0sIm5hbWVzIjpbImNvdW50cnlfcmVtb3ZlZCIsImNvdW50cmllcyIsIiQiLCJsZW5ndGgiLCJoaWRlIiwic2hvdyIsImdwYUFjdGlvbkNoYW5nZWQiLCJlbGVtZW50IiwiYWRkQWN0aW9uQnV0dG9uIiwiY2hlY2tlZCIsInJlbW92ZUNsYXNzIiwicGFyZW50IiwiZmluZCIsImkiLCJlYWNoIiwiYWRkQ2xhc3MiLCJhZGREZXBhcnRtZW50TW9kYWwiLCJzZWxlY3QiLCJtb2RhbF9pZCIsImhhc0NsYXNzIiwibW9kYWwiLCJvbiIsImUiLCJmaXJzdCIsInByb3AiLCJyZWFkVVJMIiwiaW5wdXQiLCJmaWxlcyIsInJlYWRlciIsIkZpbGVSZWFkZXIiLCJvbmxvYWQiLCJjc3MiLCJ0YXJnZXQiLCJyZXN1bHQiLCJyZWFkQXNEYXRhVVJMIiwicHJldmlld0xvZ28iLCJsb2dvSW1hZ2UiLCJ0cmlnZ2VyUHJldmlld0xvZ28iLCJwcmV2ZW50RGVmYXVsdCIsInRyaWdnZXIiLCJyZW1vdmVMb2dvUHJldmlldyIsImpRdWVyeSIsIkVycm9yIiwidCIsImZuIiwianF1ZXJ5Iiwic3BsaXQiLCJSZWZlcmVuY2VFcnJvciIsIl90eXBlb2YiLCJUeXBlRXJyb3IiLCJwcm90b3R5cGUiLCJPYmplY3QiLCJjcmVhdGUiLCJjb25zdHJ1Y3RvciIsInZhbHVlIiwiZW51bWVyYWJsZSIsIndyaXRhYmxlIiwiY29uZmlndXJhYmxlIiwic2V0UHJvdG90eXBlT2YiLCJfX3Byb3RvX18iLCJuIiwiU3ltYm9sIiwiaXRlcmF0b3IiLCJvIiwiZGVmaW5lUHJvcGVydHkiLCJrZXkiLCJyIiwidG9TdHJpbmciLCJjYWxsIiwibWF0Y2giLCJ0b0xvd2VyQ2FzZSIsIm5vZGVUeXBlIiwiYmluZFR5cGUiLCJhIiwiZW5kIiwiZGVsZWdhdGVUeXBlIiwiaGFuZGxlIiwiaXMiLCJ0aGlzIiwiaGFuZGxlT2JqIiwiaGFuZGxlciIsImFwcGx5IiwiYXJndW1lbnRzIiwid2luZG93IiwiUVVuaXQiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJoIiwic3R5bGUiLCJvbmUiLCJjIiwiVFJBTlNJVElPTl9FTkQiLCJzZXRUaW1lb3V0IiwidHJpZ2dlclRyYW5zaXRpb25FbmQiLCJzIiwiZW11bGF0ZVRyYW5zaXRpb25FbmQiLCJzdXBwb3J0c1RyYW5zaXRpb25FbmQiLCJldmVudCIsInNwZWNpYWwiLCJsIiwiV2Via2l0VHJhbnNpdGlvbiIsIk1velRyYW5zaXRpb24iLCJPVHJhbnNpdGlvbiIsInRyYW5zaXRpb24iLCJnZXRVSUQiLCJNYXRoIiwicmFuZG9tIiwiZ2V0RWxlbWVudEJ5SWQiLCJnZXRTZWxlY3RvckZyb21FbGVtZW50IiwiZ2V0QXR0cmlidXRlIiwidGVzdCIsInJlZmxvdyIsIm9mZnNldEhlaWdodCIsIkJvb2xlYW4iLCJ0eXBlQ2hlY2tDb25maWciLCJoYXNPd25Qcm9wZXJ0eSIsIlJlZ0V4cCIsInRvVXBwZXJDYXNlIiwidSIsIkRJU01JU1MiLCJkIiwiQ0xPU0UiLCJDTE9TRUQiLCJDTElDS19EQVRBX0FQSSIsImYiLCJBTEVSVCIsIkZBREUiLCJTSE9XIiwiXyIsIl9lbGVtZW50IiwiY2xvc2UiLCJfZ2V0Um9vdEVsZW1lbnQiLCJfdHJpZ2dlckNsb3NlRXZlbnQiLCJpc0RlZmF1bHRQcmV2ZW50ZWQiLCJfcmVtb3ZlRWxlbWVudCIsImRpc3Bvc2UiLCJyZW1vdmVEYXRhIiwiY2xvc2VzdCIsIkV2ZW50IiwiX2Rlc3Ryb3lFbGVtZW50IiwiZGV0YWNoIiwicmVtb3ZlIiwiX2pRdWVyeUludGVyZmFjZSIsImRhdGEiLCJfaGFuZGxlRGlzbWlzcyIsImdldCIsIkNvbnN0cnVjdG9yIiwibm9Db25mbGljdCIsIkFDVElWRSIsIkJVVFRPTiIsIkZPQ1VTIiwiREFUQV9UT0dHTEVfQ0FSUk9UIiwiREFUQV9UT0dHTEUiLCJJTlBVVCIsIkZPQ1VTX0JMVVJfREFUQV9BUEkiLCJ0b2dnbGUiLCJ0eXBlIiwiZm9jdXMiLCJzZXRBdHRyaWJ1dGUiLCJ0b2dnbGVDbGFzcyIsImludGVydmFsIiwia2V5Ym9hcmQiLCJzbGlkZSIsInBhdXNlIiwid3JhcCIsImciLCJwIiwiTkVYVCIsIlBSRVYiLCJMRUZUIiwiUklHSFQiLCJtIiwiU0xJREUiLCJTTElEIiwiS0VZRE9XTiIsIk1PVVNFRU5URVIiLCJNT1VTRUxFQVZFIiwiTE9BRF9EQVRBX0FQSSIsIkUiLCJDQVJPVVNFTCIsIklURU0iLCJ2IiwiQUNUSVZFX0lURU0iLCJORVhUX1BSRVYiLCJJTkRJQ0FUT1JTIiwiREFUQV9TTElERSIsIkRBVEFfUklERSIsIlQiLCJfaXRlbXMiLCJfaW50ZXJ2YWwiLCJfYWN0aXZlRWxlbWVudCIsIl9pc1BhdXNlZCIsIl9pc1NsaWRpbmciLCJfY29uZmlnIiwiX2dldENvbmZpZyIsIl9pbmRpY2F0b3JzRWxlbWVudCIsIl9hZGRFdmVudExpc3RlbmVycyIsIm5leHQiLCJfc2xpZGUiLCJuZXh0V2hlblZpc2libGUiLCJoaWRkZW4iLCJwcmV2IiwiUFJFVklPVVMiLCJjeWNsZSIsImNsZWFySW50ZXJ2YWwiLCJzZXRJbnRlcnZhbCIsInZpc2liaWxpdHlTdGF0ZSIsImJpbmQiLCJ0byIsIl9nZXRJdGVtSW5kZXgiLCJvZmYiLCJleHRlbmQiLCJfa2V5ZG93biIsImRvY3VtZW50RWxlbWVudCIsInRhZ05hbWUiLCJ3aGljaCIsIm1ha2VBcnJheSIsImluZGV4T2YiLCJfZ2V0SXRlbUJ5RGlyZWN0aW9uIiwiX3RyaWdnZXJTbGlkZUV2ZW50IiwicmVsYXRlZFRhcmdldCIsImRpcmVjdGlvbiIsIl9zZXRBY3RpdmVJbmRpY2F0b3JFbGVtZW50IiwiY2hpbGRyZW4iLCJfZGF0YUFwaUNsaWNrSGFuZGxlciIsIlNIT1dOIiwiSElERSIsIkhJRERFTiIsIkNPTExBUFNFIiwiQ09MTEFQU0lORyIsIkNPTExBUFNFRCIsIldJRFRIIiwiSEVJR0hUIiwiQUNUSVZFUyIsIl9pc1RyYW5zaXRpb25pbmciLCJfdHJpZ2dlckFycmF5IiwiaWQiLCJfcGFyZW50IiwiX2dldFBhcmVudCIsIl9hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3MiLCJfZ2V0RGltZW5zaW9uIiwiYXR0ciIsInNldFRyYW5zaXRpb25pbmciLCJzbGljZSIsIl9nZXRUYXJnZXRGcm9tRWxlbWVudCIsIkNMSUNLIiwiRk9DVVNJTl9EQVRBX0FQSSIsIktFWURPV05fREFUQV9BUEkiLCJCQUNLRFJPUCIsIkRJU0FCTEVEIiwiRk9STV9DSElMRCIsIlJPTEVfTUVOVSIsIlJPTEVfTElTVEJPWCIsIk5BVkJBUl9OQVYiLCJWSVNJQkxFX0lURU1TIiwiZGlzYWJsZWQiLCJfZ2V0UGFyZW50RnJvbUVsZW1lbnQiLCJfY2xlYXJNZW51cyIsImNsYXNzTmFtZSIsImluc2VydEJlZm9yZSIsInBhcmVudE5vZGUiLCJyZW1vdmVDaGlsZCIsImNvbnRhaW5zIiwiX2RhdGFBcGlLZXlkb3duSGFuZGxlciIsInN0b3BQcm9wYWdhdGlvbiIsImJhY2tkcm9wIiwiRk9DVVNJTiIsIlJFU0laRSIsIkNMSUNLX0RJU01JU1MiLCJLRVlET1dOX0RJU01JU1MiLCJNT1VTRVVQX0RJU01JU1MiLCJNT1VTRURPV05fRElTTUlTUyIsIlNDUk9MTEJBUl9NRUFTVVJFUiIsIk9QRU4iLCJESUFMT0ciLCJEQVRBX0RJU01JU1MiLCJGSVhFRF9DT05URU5UIiwiX2RpYWxvZyIsIl9iYWNrZHJvcCIsIl9pc1Nob3duIiwiX2lzQm9keU92ZXJmbG93aW5nIiwiX2lnbm9yZUJhY2tkcm9wQ2xpY2siLCJfb3JpZ2luYWxCb2R5UGFkZGluZyIsIl9zY3JvbGxiYXJXaWR0aCIsIl9jaGVja1Njcm9sbGJhciIsIl9zZXRTY3JvbGxiYXIiLCJib2R5IiwiX3NldEVzY2FwZUV2ZW50IiwiX3NldFJlc2l6ZUV2ZW50IiwiX3Nob3dCYWNrZHJvcCIsIl9zaG93RWxlbWVudCIsIl9oaWRlTW9kYWwiLCJOb2RlIiwiRUxFTUVOVF9OT0RFIiwiYXBwZW5kQ2hpbGQiLCJkaXNwbGF5IiwicmVtb3ZlQXR0cmlidXRlIiwic2Nyb2xsVG9wIiwiX2VuZm9yY2VGb2N1cyIsImhhcyIsIl9oYW5kbGVVcGRhdGUiLCJfcmVzZXRBZGp1c3RtZW50cyIsIl9yZXNldFNjcm9sbGJhciIsIl9yZW1vdmVCYWNrZHJvcCIsImFwcGVuZFRvIiwiY3VycmVudFRhcmdldCIsIl9hZGp1c3REaWFsb2ciLCJzY3JvbGxIZWlnaHQiLCJjbGllbnRIZWlnaHQiLCJwYWRkaW5nTGVmdCIsInBhZGRpbmdSaWdodCIsImNsaWVudFdpZHRoIiwiaW5uZXJXaWR0aCIsIl9nZXRTY3JvbGxiYXJXaWR0aCIsInBhcnNlSW50Iiwib2Zmc2V0V2lkdGgiLCJEZWZhdWx0Iiwib2Zmc2V0IiwibWV0aG9kIiwiQUNUSVZBVEUiLCJTQ1JPTEwiLCJEUk9QRE9XTl9JVEVNIiwiRFJPUERPV05fTUVOVSIsIk5BVl9MSU5LIiwiTkFWIiwiREFUQV9TUFkiLCJMSVNUX0lURU0iLCJMSSIsIkxJX0RST1BET1dOIiwiTkFWX0xJTktTIiwiRFJPUERPV04iLCJEUk9QRE9XTl9JVEVNUyIsIkRST1BET1dOX1RPR0dMRSIsIk9GRlNFVCIsIlBPU0lUSU9OIiwiX3Njcm9sbEVsZW1lbnQiLCJfc2VsZWN0b3IiLCJfb2Zmc2V0cyIsIl90YXJnZXRzIiwiX2FjdGl2ZVRhcmdldCIsIl9zY3JvbGxIZWlnaHQiLCJfcHJvY2VzcyIsInJlZnJlc2giLCJfZ2V0U2Nyb2xsVG9wIiwiX2dldFNjcm9sbEhlaWdodCIsIm1hcCIsInRvcCIsImZpbHRlciIsInNvcnQiLCJmb3JFYWNoIiwicHVzaCIsInBhZ2VZT2Zmc2V0IiwibWF4IiwiX2dldE9mZnNldEhlaWdodCIsImlubmVySGVpZ2h0IiwiX2FjdGl2YXRlIiwiX2NsZWFyIiwiam9pbiIsInBhcmVudHMiLCJBIiwiTElTVCIsIkZBREVfQ0hJTEQiLCJBQ1RJVkVfQ0hJTEQiLCJEUk9QRE9XTl9BQ1RJVkVfQ0hJTEQiLCJfdHJhbnNpdGlvbkNvbXBsZXRlIiwiVGV0aGVyIiwiYW5pbWF0aW9uIiwidGVtcGxhdGUiLCJ0aXRsZSIsImRlbGF5IiwiaHRtbCIsInNlbGVjdG9yIiwicGxhY2VtZW50IiwiY29uc3RyYWludHMiLCJjb250YWluZXIiLCJUT1AiLCJCT1RUT00iLCJPVVQiLCJJTlNFUlRFRCIsIkZPQ1VTT1VUIiwiVE9PTFRJUCIsIlRPT0xUSVBfSU5ORVIiLCJlbmFibGVkIiwiSE9WRVIiLCJNQU5VQUwiLCJJIiwiX2lzRW5hYmxlZCIsIl90aW1lb3V0IiwiX2hvdmVyU3RhdGUiLCJfYWN0aXZlVHJpZ2dlciIsIl90ZXRoZXIiLCJjb25maWciLCJ0aXAiLCJfc2V0TGlzdGVuZXJzIiwiZW5hYmxlIiwiZGlzYWJsZSIsInRvZ2dsZUVuYWJsZWQiLCJEQVRBX0tFWSIsIl9nZXREZWxlZ2F0ZUNvbmZpZyIsImNsaWNrIiwiX2lzV2l0aEFjdGl2ZVRyaWdnZXIiLCJfZW50ZXIiLCJfbGVhdmUiLCJnZXRUaXBFbGVtZW50IiwiY2xlYXJUaW1lb3V0IiwiY2xlYW51cFRldGhlciIsIkVWRU5UX0tFWSIsImlzV2l0aENvbnRlbnQiLCJvd25lckRvY3VtZW50IiwiTkFNRSIsInNldENvbnRlbnQiLCJfZ2V0QXR0YWNobWVudCIsImF0dGFjaG1lbnQiLCJjbGFzc2VzIiwiY2xhc3NQcmVmaXgiLCJhZGRUYXJnZXRDbGFzc2VzIiwicG9zaXRpb24iLCJfVFJBTlNJVElPTl9EVVJBVElPTiIsImdldFRpdGxlIiwic2V0RWxlbWVudENvbnRlbnQiLCJlbXB0eSIsImFwcGVuZCIsInRleHQiLCJkZXN0cm95IiwiX2ZpeFRpdGxlIiwiRGVmYXVsdFR5cGUiLCJjb250ZW50IiwiVElUTEUiLCJDT05URU5UIiwiX2dldENvbnRlbnQiLCJuZXh0Q2FsZW5kYXJTY3JlZW4iLCJjdXJyZW50U2NyZWVuIiwibmV4dFNjcmVlbiIsInByZXZpb3VzQ2FsZW5kYXJTY3JlZW4iLCJwcmV2U2NyZWVuIiwic2V0Rm9jdXNWYWx1ZSIsInZhbCIsImNvbGxhcHNlQWxsIiwiYWNjb3JkaW9uIiwiYWN0aW9uIiwiY29sbGFwc2UiLCJlZGl0SW5saW5lRWRpdGFibGUiLCJzZXRTZWxlY3RlZEljb24iLCJjaGFuZ2UiLCJjb25zb2xlIiwibG9nIiwic2Nyb2xsIiwiYWRkTWFya2VyIiwibGF0IiwibG9uZyIsImNvbnRlbnRTdHJpbmciLCJsYWJlbCIsInVuZGVmaW5lZCIsIm1hcmtlciIsIk1hcmtlciIsImdvb2dsZSIsIm1hcHMiLCJMYXRMbmciLCJpY29uIiwibWFwX2ljb25fbGFiZWwiLCJpbmZvd2luZG93IiwiSW5mb1dpbmRvdyIsIm1heFdpZHRoIiwiYWRkTGlzdGVuZXIiLCJvcGVuIiwibXVsdGlfc2VsZWN0X3JhZGlvU2VsZWN0ZWQiLCJyaWJib25DbGljayIsInNsaWRlVXAiLCJzbGlkZVRvZ2dsZSIsImNvbnRpbnVlVG9OZXh0UmliYm9uIiwic2xpZGVEb3duIiwicmlza0luZGljYXRvciIsInVwZGF0ZUJ1dHRvbiIsImluZGljYXRvckJ1dHRvbiIsImdldEVsZW1lbnRzQnlDbGFzc05hbWUiLCJjaGVja0luZGljYXRvclRleHQiLCJ1cGRhdGVDaGFuZ2UiLCJhZGRFdmVudExpc3RlbmVyIiwiY2xhc3NMaXN0IiwiZWRpdFN0YXRlIiwic2F2ZUJ1dHRvbkNoYW5nZSIsInRleHRDb250ZW50Il0sIm1hcHBpbmdzIjoiOztBQUNBLFNBQVNBO0lBRUwsSUFBSUMsWUFBWUMsRUFBRTtJQUVsQixJQUFHRCxVQUFVRSxVQUFVLEdBQ3ZCO1FBRUlELEVBQUUsaUJBQWlCRTtXQUNsQjtRQUNERixFQUFFLGlCQUFpQkc7Ozs7QUFLM0IsU0FBU0MsaUJBQWtCQztJQUN2QixJQUFJQyxrQkFBa0JOLEVBQUU7SUFDeEIsSUFBSUssUUFBUUUsU0FBUztRQUVqQkQsZ0JBQWdCRSxZQUFZO1FBRzVCUixFQUFFSyxTQUFTSSxTQUFTQSxTQUFTQyxLQUFLLDBCQUEwQlA7V0FDekQ7UUFFSEgsRUFBRUssU0FBU0ksU0FBU0EsU0FBU0MsS0FBSywwQkFBMEJSO1FBRzVELElBQUlTLElBQUk7UUFDUlgsRUFBRSxrQ0FBa0NZLEtBQUs7WUFDckNEOztRQUVKLElBQUlBLElBQUksR0FBRztZQUNQTCxnQkFBZ0JPLFNBQVM7Ozs7O0FBV3JDLFNBQVNDLG1CQUFtQkMsUUFBUUM7SUFDaEMsSUFBR2hCLEVBQUVlLFFBQVFMLEtBQUssYUFBYU8sU0FBUyxtQkFDeEM7UUFDSWpCLEVBQUVnQixVQUFVRSxNQUFNO1FBRWpCbEIsRUFBRSxtQkFBbUJtQixHQUFHLG1CQUFtQixTQUFVQztZQUNsRHBCLEVBQUVlLFFBQVFMLEtBQUssVUFBVVcsUUFBUUMsS0FBSyxZQUFZOzs7Ozs7O0FDbEQ5RCxTQUFTQyxRQUFRQztJQUNmLElBQUlBLE1BQU1DLFNBQVNELE1BQU1DLE1BQU0sSUFBSTtRQUMvQixJQUFJQyxTQUFTLElBQUlDO1FBRWpCRCxPQUFPRSxTQUFTLFNBQVVSO1lBQ3RCcEIsRUFBRSxrQ0FBa0M2QixJQUFJLG9CQUFvQixTQUFTVCxFQUFFVSxPQUFPQyxTQUFTO1lBQ3ZGL0IsRUFBRSxrQ0FBa0NhLFNBQVM7O1FBR2pEYSxPQUFPTSxjQUFjUixNQUFNQyxNQUFNOzs7O0FBSXZDLFNBQVNRLFlBQVlDO0lBQ2pCWCxRQUFRVztJQUNSbEMsRUFBRSxnQkFBZ0JFO0lBQ2xCRixFQUFFLGlCQUFpQkc7SUFDbkJILEVBQUUsZ0JBQWdCRzs7O0FBR3RCLFNBQVNnQyxtQkFBbUJmO0lBQ3hCQSxFQUFFZ0I7SUFDSHBDLEVBQUUsV0FBV3FDLFFBQVE7OztBQUd4QixTQUFTQyxrQkFBa0JsQjtJQUN2QkEsRUFBRWdCO0lBQ0ZwQyxFQUFFLGlCQUFpQkU7SUFDbkJGLEVBQUUsZ0JBQWdCRTtJQUNsQkYsRUFBRSxnQkFBZ0JHO0lBQ2xCSCxFQUFFLGtDQUFrQzZCLElBQUksb0JBQW9CO0lBQzVEN0IsRUFBRSxrQ0FBa0NRLFlBQVk7Ozs7Ozs7Ozs7O0FDMUJwRCxJQUFHLHNCQUFvQitCLFFBQU8sTUFBTSxJQUFJQyxNQUFNOztDQUFtRyxTQUFTQztJQUFHLElBQUlyQixJQUFFcUIsRUFBRUMsR0FBR0MsT0FBT0MsTUFBTSxLQUFLLEdBQUdBLE1BQU07SUFBSyxJQUFHeEIsRUFBRSxLQUFHLEtBQUdBLEVBQUUsS0FBRyxLQUFHLEtBQUdBLEVBQUUsTUFBSSxLQUFHQSxFQUFFLE1BQUlBLEVBQUUsS0FBRyxLQUFHQSxFQUFFLE1BQUksR0FBRSxNQUFNLElBQUlvQixNQUFNO0VBQWdGRCxVQUFTO0lBQVcsU0FBU0UsRUFBRUEsR0FBRXJCO1FBQUcsS0FBSXFCLEdBQUUsTUFBTSxJQUFJSSxlQUFlO1FBQTZELFFBQU96QixLQUFHLG9CQUFpQkEsTUFBakIsY0FBQSxjQUFBMEIsUUFBaUIxQixPQUFHLHFCQUFtQkEsSUFBRXFCLElBQUVyQjs7SUFBRSxTQUFTQSxFQUFFcUIsR0FBRXJCO1FBQUcsSUFBRyxxQkFBbUJBLEtBQUcsU0FBT0EsR0FBRSxNQUFNLElBQUkyQixVQUFVLHFFQUFrRTNCLE1BQWxFLGNBQUEsY0FBQTBCLFFBQWtFMUI7UUFBR3FCLEVBQUVPLFlBQVVDLE9BQU9DLE9BQU85QixLQUFHQSxFQUFFNEI7WUFBV0c7Z0JBQWFDLE9BQU1YO2dCQUFFWSxhQUFZO2dCQUFFQyxXQUFVO2dCQUFFQyxlQUFjOztZQUFLbkMsTUFBSTZCLE9BQU9PLGlCQUFlUCxPQUFPTyxlQUFlZixHQUFFckIsS0FBR3FCLEVBQUVnQixZQUFVckM7O0lBQUcsU0FBU3NDLEVBQUVqQixHQUFFckI7UUFBRyxNQUFLcUIsYUFBYXJCLElBQUcsTUFBTSxJQUFJMkIsVUFBVTs7SUFBcUMsSUFBSXBDLElBQUUscUJBQW1CZ0QsVUFBUSxZQUFBYixRQUFpQmEsT0FBT0MsWUFBUyxTQUFTbkI7UUFBRyxjQUFjQSxNQUFkLGNBQUEsY0FBQUssUUFBY0w7UUFBRyxTQUFTQTtRQUFHLE9BQU9BLEtBQUcscUJBQW1Ca0IsVUFBUWxCLEVBQUVVLGdCQUFjUSxVQUFRbEIsTUFBSWtCLE9BQU9YLFlBQVUsa0JBQWdCUCxNQUEzRixjQUFBLGNBQUFLLFFBQTJGTDtPQUFHb0IsSUFBRTtRQUFXLFNBQVNwQixFQUFFQSxHQUFFckI7WUFBRyxLQUFJLElBQUlzQyxJQUFFLEdBQUVBLElBQUV0QyxFQUFFbkIsUUFBT3lELEtBQUk7Z0JBQUMsSUFBSS9DLElBQUVTLEVBQUVzQztnQkFBRy9DLEVBQUUwQyxhQUFXMUMsRUFBRTBDLGVBQWEsR0FBRTFDLEVBQUU0QyxnQkFBYyxHQUFFLFdBQVU1QyxNQUFJQSxFQUFFMkMsWUFBVTtnQkFBR0wsT0FBT2EsZUFBZXJCLEdBQUU5QixFQUFFb0QsS0FBSXBEOzs7UUFBSSxPQUFPLFNBQVNTLEdBQUVzQyxHQUFFL0M7WUFBRyxPQUFPK0MsS0FBR2pCLEVBQUVyQixFQUFFNEIsV0FBVVUsSUFBRy9DLEtBQUc4QixFQUFFckIsR0FBRVQsSUFBR1M7O1NBQU00QyxJQUFFLFNBQVN2QjtRQUFHLFNBQVNyQixFQUFFcUI7WUFBRyxVQUFTd0IsU0FBU0MsS0FBS3pCLEdBQUcwQixNQUFNLGlCQUFpQixHQUFHQzs7UUFBYyxTQUFTVixFQUFFakI7WUFBRyxRQUFPQSxFQUFFLE1BQUlBLEdBQUc0Qjs7UUFBUyxTQUFTMUQ7WUFBSTtnQkFBTzJELFVBQVNDLEVBQUVDO2dCQUFJQyxjQUFhRixFQUFFQztnQkFBSUUsUUFBTyxTQUFBQSxPQUFTdEQ7b0JBQUcsSUFBR3FCLEVBQUVyQixFQUFFVSxRQUFRNkMsR0FBR0MsT0FBTSxPQUFPeEQsRUFBRXlELFVBQVVDLFFBQVFDLE1BQU1ILE1BQUtJOzs7O1FBQWEsU0FBU25CO1lBQUksSUFBR29CLE9BQU9DLE9BQU0sUUFBTztZQUFFLElBQUl6QyxJQUFFMEMsU0FBU0MsY0FBYztZQUFhLEtBQUksSUFBSWhFLEtBQUtpRSxHQUFiO2dCQUFlLFNBQVEsTUFBSTVDLEVBQUU2QyxNQUFNbEUsSUFBRztvQkFBT29ELEtBQUlhLEVBQUVqRTs7O1lBQUksUUFBTzs7UUFBRSxTQUFTNEMsRUFBRTVDO1lBQUcsSUFBSXNDLElBQUVrQixNQUFLakUsS0FBRztZQUFFLE9BQU84QixFQUFFbUMsTUFBTVcsSUFBSUMsRUFBRUMsZ0JBQWU7Z0JBQVc5RSxLQUFHO2dCQUFJK0UsV0FBVztnQkFBVy9FLEtBQUc2RSxFQUFFRyxxQkFBcUJqQztlQUFJdEMsSUFBR3dEOztRQUFLLFNBQVNnQjtZQUFJckIsSUFBRVYsS0FBSXBCLEVBQUVDLEdBQUdtRCx1QkFBcUI3QixHQUFFd0IsRUFBRU0sNEJBQTBCckQsRUFBRXNELE1BQU1DLFFBQVFSLEVBQUVDLGtCQUFnQjlFOztRQUFLLElBQUk0RCxLQUFHLEdBQUUwQixJQUFFLEtBQUlaO1lBQUdhLGtCQUFpQjtZQUFzQkMsZUFBYztZQUFnQkMsYUFBWTtZQUFnQ0MsWUFBVztXQUFpQmI7WUFBR0MsZ0JBQWU7WUFBa0JhLFFBQU8sU0FBQUEsT0FBUzdEO2dCQUFHLEdBQUE7b0JBQUdBLFFBQU04RCxLQUFLQyxXQUFTUDt5QkFBU2QsU0FBU3NCLGVBQWVoRTtnQkFBSSxPQUFPQTs7WUFBR2lFLHdCQUF1QixTQUFBQSx1QkFBU2pFO2dCQUFHLElBQUlyQixJQUFFcUIsRUFBRWtFLGFBQWE7Z0JBQWUsT0FBT3ZGLE1BQUlBLElBQUVxQixFQUFFa0UsYUFBYSxXQUFTLElBQUd2RixJQUFFLFdBQVd3RixLQUFLeEYsS0FBR0EsSUFBRTtnQkFBTUE7O1lBQUd5RixRQUFPLFNBQUFBLE9BQVNwRTtnQkFBRyxPQUFPQSxFQUFFcUU7O1lBQWNuQixzQkFBcUIsU0FBQUEscUJBQVN2RTtnQkFBR3FCLEVBQUVyQixHQUFHaUIsUUFBUWtDLEVBQUVDOztZQUFNc0IsdUJBQXNCLFNBQUFBO2dCQUFXLE9BQU9pQixRQUFReEM7O1lBQUl5QyxpQkFBZ0IsU0FBQUEsZ0JBQVN2RSxHQUFFOUIsR0FBRWtEO2dCQUFHLEtBQUksSUFBSUcsS0FBS0gsR0FBYjtvQkFBZSxJQUFHQSxFQUFFb0QsZUFBZWpELElBQUc7d0JBQUMsSUFBSTRCLElBQUUvQixFQUFFRyxJQUFHTyxJQUFFNUQsRUFBRXFELElBQUdpQyxJQUFFMUIsS0FBR2IsRUFBRWEsS0FBRyxZQUFVbkQsRUFBRW1EO3dCQUFHLEtBQUksSUFBSTJDLE9BQU90QixHQUFHZ0IsS0FBS1gsSUFBRyxNQUFNLElBQUl6RCxNQUFNQyxFQUFFMEUsZ0JBQWMsUUFBTSxhQUFXbkQsSUFBRSxzQkFBb0JpQyxJQUFFLFNBQU8sd0JBQXNCTCxJQUFFOzs7OztRQUFVLE9BQU9BLEtBQUlKO01BQUdqRCxTQUFRcUQsS0FBRyxTQUFTbkQ7UUFBRyxJQUFJckIsSUFBRSxTQUFRVCxJQUFFLGlCQUFnQmlGLElBQUUsWUFBV3JCLElBQUUsTUFBSXFCLEdBQUVLLElBQUUsYUFBWVosSUFBRTVDLEVBQUVDLEdBQUd0QixJQUFHb0UsSUFBRSxLQUFJNEI7WUFBR0MsU0FBUTtXQUEwQkM7WUFBR0MsT0FBTSxVQUFRaEQ7WUFBRWlELFFBQU8sV0FBU2pEO1lBQUVrRCxnQkFBZSxVQUFRbEQsSUFBRTBCO1dBQUd5QjtZQUFHQyxPQUFNO1lBQVFDLE1BQUs7WUFBT0MsTUFBSztXQUFRQyxJQUFFO1lBQVcsU0FBUzFHLEVBQUVxQjtnQkFBR2lCLEVBQUVrQixNQUFLeEQsSUFBR3dELEtBQUttRCxXQUFTdEY7O1lBQUUsT0FBT3JCLEVBQUU0QixVQUFVZ0YsUUFBTSxTQUFTdkY7Z0JBQUdBLElBQUVBLEtBQUdtQyxLQUFLbUQ7Z0JBQVMsSUFBSTNHLElBQUV3RCxLQUFLcUQsZ0JBQWdCeEYsSUFBR2lCLElBQUVrQixLQUFLc0QsbUJBQW1COUc7Z0JBQUdzQyxFQUFFeUUsd0JBQXNCdkQsS0FBS3dELGVBQWVoSDtlQUFJQSxFQUFFNEIsVUFBVXFGLFVBQVE7Z0JBQVc1RixFQUFFNkYsV0FBVzFELEtBQUttRCxVQUFTbkMsSUFBR2hCLEtBQUttRCxXQUFTO2VBQU0zRyxFQUFFNEIsVUFBVWlGLGtCQUFnQixTQUFTN0c7Z0JBQUcsSUFBSXNDLElBQUVNLEVBQUUwQyx1QkFBdUJ0RixJQUFHVCxLQUFHO2dCQUFFLE9BQU8rQyxNQUFJL0MsSUFBRThCLEVBQUVpQixHQUFHLEtBQUkvQyxNQUFJQSxJQUFFOEIsRUFBRXJCLEdBQUdtSCxRQUFRLE1BQUliLEVBQUVDLE9BQU8sS0FBSWhIO2VBQUdTLEVBQUU0QixVQUFVa0YscUJBQW1CLFNBQVM5RztnQkFBRyxJQUFJc0MsSUFBRWpCLEVBQUUrRixNQUFNbEIsRUFBRUM7Z0JBQU8sT0FBTzlFLEVBQUVyQixHQUFHaUIsUUFBUXFCLElBQUdBO2VBQUd0QyxFQUFFNEIsVUFBVW9GLGlCQUFlLFNBQVNoSDtnQkFBRyxJQUFJc0MsSUFBRWtCO2dCQUFLLE9BQU9uQyxFQUFFckIsR0FBR1osWUFBWWtILEVBQUVHLE9BQU03RCxFQUFFOEIsMkJBQXlCckQsRUFBRXJCLEdBQUdILFNBQVN5RyxFQUFFRSxhQUFXbkYsRUFBRXJCLEdBQUdtRSxJQUFJdkIsRUFBRXlCLGdCQUFlLFNBQVNoRDtvQkFBRyxPQUFPaUIsRUFBRStFLGdCQUFnQnJILEdBQUVxQjttQkFBS29ELHFCQUFxQkwsVUFBUVosS0FBSzZELGdCQUFnQnJIO2VBQUlBLEVBQUU0QixVQUFVeUYsa0JBQWdCLFNBQVNySDtnQkFBR3FCLEVBQUVyQixHQUFHc0gsU0FBU3JHLFFBQVFpRixFQUFFRSxRQUFRbUI7ZUFBVXZILEVBQUV3SCxtQkFBaUIsU0FBU2xGO2dCQUFHLE9BQU9rQixLQUFLaEUsS0FBSztvQkFBVyxJQUFJRCxJQUFFOEIsRUFBRW1DLE9BQU1mLElBQUVsRCxFQUFFa0ksS0FBS2pEO29CQUFHL0IsTUFBSUEsSUFBRSxJQUFJekMsRUFBRXdELE9BQU1qRSxFQUFFa0ksS0FBS2pELEdBQUUvQixLQUFJLFlBQVVILEtBQUdHLEVBQUVILEdBQUdrQjs7ZUFBU3hELEVBQUUwSCxpQkFBZSxTQUFTckc7Z0JBQUcsT0FBTyxTQUFTckI7b0JBQUdBLEtBQUdBLEVBQUVnQixrQkFBaUJLLEVBQUV1RixNQUFNcEQ7O2VBQVFmLEVBQUV6QyxHQUFFO2dCQUFPMkMsS0FBSTtnQkFBVWdGLEtBQUksU0FBQUE7b0JBQVcsT0FBT3BJOztrQkFBTVM7O1FBQUssT0FBT3FCLEVBQUUwQyxVQUFVaEUsR0FBR21HLEVBQUVHLGdCQUFlTCxFQUFFQyxTQUFRUyxFQUFFZ0IsZUFBZSxJQUFJaEIsT0FBSXJGLEVBQUVDLEdBQUd0QixLQUFHMEcsRUFBRWM7UUFBaUJuRyxFQUFFQyxHQUFHdEIsR0FBRzRILGNBQVlsQixHQUFFckYsRUFBRUMsR0FBR3RCLEdBQUc2SCxhQUFXO1lBQVcsT0FBT3hHLEVBQUVDLEdBQUd0QixLQUFHaUUsR0FBRXlDLEVBQUVjO1dBQWtCZDtNQUFHdkYsU0FBUSxTQUFTRTtRQUFHLElBQUlyQixJQUFFLFVBQVNULElBQUUsaUJBQWdCcUQsSUFBRSxhQUFZNEIsSUFBRSxNQUFJNUIsR0FBRU8sSUFBRSxhQUFZMEIsSUFBRXhELEVBQUVDLEdBQUd0QixJQUFHaUU7WUFBRzZELFFBQU87WUFBU0MsUUFBTztZQUFNQyxPQUFNO1dBQVM1RDtZQUFHNkQsb0JBQW1CO1lBQTBCQyxhQUFZO1lBQTBCQyxPQUFNO1lBQVFMLFFBQU87WUFBVUMsUUFBTztXQUFRL0I7WUFBR0ssZ0JBQWUsVUFBUTdCLElBQUVyQjtZQUFFaUYscUJBQW9CLFVBQVE1RCxJQUFFckIsSUFBRSxPQUFLLFNBQU9xQixJQUFFckI7V0FBSStDLElBQUU7WUFBVyxTQUFTbEcsRUFBRXFCO2dCQUFHaUIsRUFBRWtCLE1BQUt4RCxJQUFHd0QsS0FBS21ELFdBQVN0Rjs7WUFBRSxPQUFPckIsRUFBRTRCLFVBQVV5RyxTQUFPO2dCQUFXLElBQUlySSxLQUFHLEdBQUVzQyxJQUFFakIsRUFBRW1DLEtBQUttRCxVQUFVUSxRQUFRL0MsRUFBRThELGFBQWE7Z0JBQUcsSUFBRzVGLEdBQUU7b0JBQUMsSUFBSS9DLElBQUU4QixFQUFFbUMsS0FBS21ELFVBQVVySCxLQUFLOEUsRUFBRStELE9BQU87b0JBQUcsSUFBRzVJLEdBQUU7d0JBQUMsSUFBRyxZQUFVQSxFQUFFK0ksTUFBSyxJQUFHL0ksRUFBRUosV0FBU2tDLEVBQUVtQyxLQUFLbUQsVUFBVTlHLFNBQVNvRSxFQUFFNkQsU0FBUTlILEtBQUcsUUFBTTs0QkFBQyxJQUFJeUMsSUFBRXBCLEVBQUVpQixHQUFHaEQsS0FBSzhFLEVBQUUwRCxRQUFROzRCQUFHckYsS0FBR3BCLEVBQUVvQixHQUFHckQsWUFBWTZFLEVBQUU2RDs7d0JBQVE5SCxNQUFJVCxFQUFFSixXQUFTa0MsRUFBRW1DLEtBQUttRCxVQUFVOUcsU0FBU29FLEVBQUU2RCxTQUFRekcsRUFBRTlCLEdBQUcwQixRQUFRO3dCQUFXMUIsRUFBRWdKOzs7Z0JBQVMvRSxLQUFLbUQsU0FBUzZCLGFBQWEsaUJBQWdCbkgsRUFBRW1DLEtBQUttRCxVQUFVOUcsU0FBU29FLEVBQUU2RDtnQkFBUzlILEtBQUdxQixFQUFFbUMsS0FBS21ELFVBQVU4QixZQUFZeEUsRUFBRTZEO2VBQVM5SCxFQUFFNEIsVUFBVXFGLFVBQVE7Z0JBQVc1RixFQUFFNkYsV0FBVzFELEtBQUttRCxVQUFTL0QsSUFBR1ksS0FBS21ELFdBQVM7ZUFBTTNHLEVBQUV3SCxtQkFBaUIsU0FBU2xGO2dCQUFHLE9BQU9rQixLQUFLaEUsS0FBSztvQkFBVyxJQUFJRCxJQUFFOEIsRUFBRW1DLE1BQU1pRSxLQUFLN0U7b0JBQUdyRCxNQUFJQSxJQUFFLElBQUlTLEVBQUV3RCxPQUFNbkMsRUFBRW1DLE1BQU1pRSxLQUFLN0UsR0FBRXJELEtBQUksYUFBVytDLEtBQUcvQyxFQUFFK0M7O2VBQVFHLEVBQUV6QyxHQUFFO2dCQUFPMkMsS0FBSTtnQkFBVWdGLEtBQUksU0FBQUE7b0JBQVcsT0FBT3BJOztrQkFBTVM7O1FBQUssT0FBT3FCLEVBQUUwQyxVQUFVaEUsR0FBR2lHLEVBQUVLLGdCQUFlakMsRUFBRTZELG9CQUFtQixTQUFTakk7WUFBR0EsRUFBRWdCO1lBQWlCLElBQUlzQixJQUFFdEMsRUFBRVU7WUFBT1csRUFBRWlCLEdBQUd6QyxTQUFTb0UsRUFBRThELFlBQVV6RixJQUFFakIsRUFBRWlCLEdBQUc2RSxRQUFRL0MsRUFBRTJELFVBQVM3QixFQUFFc0IsaUJBQWlCMUUsS0FBS3pCLEVBQUVpQixJQUFHO1dBQVl2QyxHQUFHaUcsRUFBRW9DLHFCQUFvQmhFLEVBQUU2RCxvQkFBbUIsU0FBU2pJO1lBQUcsSUFBSXNDLElBQUVqQixFQUFFckIsRUFBRVUsUUFBUXlHLFFBQVEvQyxFQUFFMkQsUUFBUTtZQUFHMUcsRUFBRWlCLEdBQUdtRyxZQUFZeEUsRUFBRStELE9BQU0sZUFBZXhDLEtBQUt4RixFQUFFc0k7WUFBU2pILEVBQUVDLEdBQUd0QixLQUFHa0csRUFBRXNCLGtCQUFpQm5HLEVBQUVDLEdBQUd0QixHQUFHNEgsY0FBWTFCLEdBQUU3RSxFQUFFQyxHQUFHdEIsR0FBRzZILGFBQVc7WUFBVyxPQUFPeEcsRUFBRUMsR0FBR3RCLEtBQUc2RSxHQUFFcUIsRUFBRXNCO1dBQWtCdEI7TUFBRy9FLFNBQVEsU0FBU0U7UUFBRyxJQUFJckIsSUFBRSxZQUFXd0UsSUFBRSxpQkFBZ0JyQixJQUFFLGVBQWMwQixJQUFFLE1BQUkxQixHQUFFYyxJQUFFLGFBQVlHLElBQUUvQyxFQUFFQyxHQUFHdEIsSUFBR2dHLElBQUUsS0FBSUUsSUFBRSxJQUFHSSxJQUFFLElBQUdJO1lBQUdnQyxVQUFTO1lBQUlDLFdBQVU7WUFBRUMsUUFBTztZQUFFQyxPQUFNO1lBQVFDLE9BQU07V0FBR0M7WUFBR0wsVUFBUztZQUFtQkMsVUFBUztZQUFVQyxPQUFNO1lBQW1CQyxPQUFNO1lBQW1CQyxNQUFLO1dBQVdFO1lBQUdDLE1BQUs7WUFBT0MsTUFBSztZQUFPQyxNQUFLO1lBQU9DLE9BQU07V0FBU0M7WUFBR0MsT0FBTSxVQUFRekU7WUFBRTBFLE1BQUssU0FBTzFFO1lBQUUyRSxTQUFRLFlBQVUzRTtZQUFFNEUsWUFBVyxlQUFhNUU7WUFBRTZFLFlBQVcsZUFBYTdFO1lBQUU4RSxlQUFjLFNBQU85RSxJQUFFWjtZQUFFb0MsZ0JBQWUsVUFBUXhCLElBQUVaO1dBQUcyRjtZQUFHQyxVQUFTO1lBQVcvQixRQUFPO1lBQVN3QixPQUFNO1lBQVFGLE9BQU07WUFBc0JELE1BQUs7WUFBcUJGLE1BQUs7WUFBcUJDLE1BQUs7WUFBcUJZLE1BQUs7V0FBaUJDO1lBQUdqQyxRQUFPO1lBQVVrQyxhQUFZO1lBQXdCRixNQUFLO1lBQWlCRyxXQUFVO1lBQTJDQyxZQUFXO1lBQXVCQyxZQUFXO1lBQWdDQyxXQUFVO1dBQTBCQyxJQUFFO1lBQVcsU0FBU3BHLEVBQUVqRSxHQUFFVDtnQkFBRytDLEVBQUVrQixNQUFLUyxJQUFHVCxLQUFLOEcsU0FBTyxNQUFLOUcsS0FBSytHLFlBQVUsTUFBSy9HLEtBQUtnSCxpQkFBZTtnQkFBS2hILEtBQUtpSCxhQUFXLEdBQUVqSCxLQUFLa0gsY0FBWSxHQUFFbEgsS0FBS21ILFVBQVFuSCxLQUFLb0gsV0FBV3JMLElBQUdpRSxLQUFLbUQsV0FBU3RGLEVBQUVyQixHQUFHO2dCQUFHd0QsS0FBS3FILHFCQUFtQnhKLEVBQUVtQyxLQUFLbUQsVUFBVXJILEtBQUt5SyxFQUFFRyxZQUFZLElBQUcxRyxLQUFLc0g7O1lBQXFCLE9BQU83RyxFQUFFckMsVUFBVW1KLE9BQUs7Z0JBQVcsSUFBR3ZILEtBQUtrSCxZQUFXLE1BQU0sSUFBSXRKLE1BQU07Z0JBQXVCb0MsS0FBS3dILE9BQU9oQyxFQUFFQztlQUFPaEYsRUFBRXJDLFVBQVVxSixrQkFBZ0I7Z0JBQVdsSCxTQUFTbUgsVUFBUTFILEtBQUt1SDtlQUFROUcsRUFBRXJDLFVBQVV1SixPQUFLO2dCQUFXLElBQUczSCxLQUFLa0gsWUFBVyxNQUFNLElBQUl0SixNQUFNO2dCQUF1Qm9DLEtBQUt3SCxPQUFPaEMsRUFBRW9DO2VBQVduSCxFQUFFckMsVUFBVWlILFFBQU0sU0FBUzdJO2dCQUFHQSxNQUFJd0QsS0FBS2lILGFBQVcsSUFBR3BKLEVBQUVtQyxLQUFLbUQsVUFBVXJILEtBQUt5SyxFQUFFRSxXQUFXLE1BQUlySCxFQUFFOEIsNEJBQTBCOUIsRUFBRTJCLHFCQUFxQmYsS0FBS21EO2dCQUFVbkQsS0FBSzZILE9BQU8sS0FBSUMsY0FBYzlILEtBQUsrRyxZQUFXL0csS0FBSytHLFlBQVU7ZUFBTXRHLEVBQUVyQyxVQUFVeUosUUFBTSxTQUFTaEs7Z0JBQUdBLE1BQUltQyxLQUFLaUgsYUFBVyxJQUFHakgsS0FBSytHLGNBQVllLGNBQWM5SCxLQUFLK0csWUFBVy9HLEtBQUsrRyxZQUFVO2dCQUFNL0csS0FBS21ILFFBQVFqQyxhQUFXbEYsS0FBS2lILGNBQVlqSCxLQUFLK0csWUFBVWdCLGFBQWF4SCxTQUFTeUgsa0JBQWdCaEksS0FBS3lILGtCQUFnQnpILEtBQUt1SCxNQUFNVSxLQUFLakksT0FBTUEsS0FBS21ILFFBQVFqQztlQUFZekUsRUFBRXJDLFVBQVU4SixLQUFHLFNBQVMxTDtnQkFBRyxJQUFJc0MsSUFBRWtCO2dCQUFLQSxLQUFLZ0gsaUJBQWVuSixFQUFFbUMsS0FBS21ELFVBQVVySCxLQUFLeUssRUFBRUMsYUFBYTtnQkFBRyxJQUFJekssSUFBRWlFLEtBQUttSSxjQUFjbkksS0FBS2dIO2dCQUFnQixNQUFLeEssSUFBRXdELEtBQUs4RyxPQUFPekwsU0FBTyxLQUFHbUIsSUFBRSxJQUFHO29CQUFDLElBQUd3RCxLQUFLa0gsWUFBVyxZQUFZckosRUFBRW1DLEtBQUttRCxVQUFVeEMsSUFBSWtGLEVBQUVFLE1BQUs7d0JBQVcsT0FBT2pILEVBQUVvSixHQUFHMUw7O29CQUFLLElBQUdULE1BQUlTLEdBQUUsT0FBT3dELEtBQUtxRixjQUFhckYsS0FBSzZIO29CQUFRLElBQUk1SSxJQUFFekMsSUFBRVQsSUFBRXlKLEVBQUVDLE9BQUtELEVBQUVvQztvQkFBUzVILEtBQUt3SCxPQUFPdkksR0FBRWUsS0FBSzhHLE9BQU90Szs7ZUFBTWlFLEVBQUVyQyxVQUFVcUYsVUFBUTtnQkFBVzVGLEVBQUVtQyxLQUFLbUQsVUFBVWlGLElBQUkvRyxJQUFHeEQsRUFBRTZGLFdBQVcxRCxLQUFLbUQsVUFBU3hELElBQUdLLEtBQUs4RyxTQUFPLE1BQUs5RyxLQUFLbUgsVUFBUTtnQkFBS25ILEtBQUttRCxXQUFTLE1BQUtuRCxLQUFLK0csWUFBVSxNQUFLL0csS0FBS2lILFlBQVUsTUFBS2pILEtBQUtrSCxhQUFXO2dCQUFLbEgsS0FBS2dILGlCQUFlLE1BQUtoSCxLQUFLcUgscUJBQW1CO2VBQU01RyxFQUFFckMsVUFBVWdKLGFBQVcsU0FBU3RJO2dCQUFHLE9BQU9BLElBQUVqQixFQUFFd0ssV0FBVW5GLEdBQUVwRSxJQUFHTSxFQUFFZ0QsZ0JBQWdCNUYsR0FBRXNDLEdBQUV5RyxJQUFHekc7ZUFBRzJCLEVBQUVyQyxVQUFVa0oscUJBQW1CO2dCQUFXLElBQUk5SyxJQUFFd0Q7Z0JBQUtBLEtBQUttSCxRQUFRaEMsWUFBVXRILEVBQUVtQyxLQUFLbUQsVUFBVTVHLEdBQUdzSixFQUFFRyxTQUFRLFNBQVNuSTtvQkFBRyxPQUFPckIsRUFBRThMLFNBQVN6SztvQkFBSyxZQUFVbUMsS0FBS21ILFFBQVE5QixTQUFPLGtCQUFpQjlFLFNBQVNnSSxtQkFBaUIxSyxFQUFFbUMsS0FBS21ELFVBQVU1RyxHQUFHc0osRUFBRUksWUFBVyxTQUFTcEk7b0JBQUcsT0FBT3JCLEVBQUU2SSxNQUFNeEg7bUJBQUt0QixHQUFHc0osRUFBRUssWUFBVyxTQUFTckk7b0JBQUcsT0FBT3JCLEVBQUVxTCxNQUFNaEs7O2VBQU00QyxFQUFFckMsVUFBVWtLLFdBQVMsU0FBU3pLO2dCQUFHLEtBQUksa0JBQWtCbUUsS0FBS25FLEVBQUVYLE9BQU9zTCxVQUFTLFFBQU8zSyxFQUFFNEs7a0JBQU8sS0FBSy9GO29CQUFFN0UsRUFBRUwsa0JBQWlCd0MsS0FBSzJIO29CQUFPOztrQkFBTSxLQUFLN0U7b0JBQUVqRixFQUFFTCxrQkFBaUJ3QyxLQUFLdUg7b0JBQU87O2tCQUFNO29CQUFROztlQUFTOUcsRUFBRXJDLFVBQVUrSixnQkFBYyxTQUFTM0w7Z0JBQUcsT0FBT3dELEtBQUs4RyxTQUFPakosRUFBRTZLLFVBQVU3SyxFQUFFckIsR0FBR1gsU0FBU0MsS0FBS3lLLEVBQUVELFFBQU90RyxLQUFLOEcsT0FBTzZCLFFBQVFuTTtlQUFJaUUsRUFBRXJDLFVBQVV3SyxzQkFBb0IsU0FBUy9LLEdBQUVyQjtnQkFBRyxJQUFJc0MsSUFBRWpCLE1BQUkySCxFQUFFQyxNQUFLMUosSUFBRThCLE1BQUkySCxFQUFFb0MsVUFBUzNJLElBQUVlLEtBQUttSSxjQUFjM0wsSUFBRzRDLElBQUVZLEtBQUs4RyxPQUFPekwsU0FBTyxHQUFFMkYsSUFBRWpGLEtBQUcsTUFBSWtELEtBQUdILEtBQUdHLE1BQUlHO2dCQUFFLElBQUc0QixNQUFJaEIsS0FBS21ILFFBQVE3QixNQUFLLE9BQU85STtnQkFBRSxJQUFJbUQsSUFBRTlCLE1BQUkySCxFQUFFb0MsWUFBVSxJQUFFLEdBQUV2RyxLQUFHcEMsSUFBRVUsS0FBR0ssS0FBSzhHLE9BQU96TDtnQkFBTyxPQUFPZ0csT0FBSyxJQUFFckIsS0FBSzhHLE9BQU85RyxLQUFLOEcsT0FBT3pMLFNBQU8sS0FBRzJFLEtBQUs4RyxPQUFPekY7ZUFBSVosRUFBRXJDLFVBQVV5SyxxQkFBbUIsU0FBU3JNLEdBQUVzQztnQkFBRyxJQUFJL0MsSUFBRThCLEVBQUUrRixNQUFNaUMsRUFBRUM7b0JBQU9nRCxlQUFjdE07b0JBQUV1TSxXQUFVaks7O2dCQUFJLE9BQU9qQixFQUFFbUMsS0FBS21ELFVBQVUxRixRQUFRMUIsSUFBR0E7ZUFBRzBFLEVBQUVyQyxVQUFVNEssNkJBQTJCLFNBQVN4TTtnQkFBRyxJQUFHd0QsS0FBS3FILG9CQUFtQjtvQkFBQ3hKLEVBQUVtQyxLQUFLcUgsb0JBQW9CdkwsS0FBS3lLLEVBQUVqQyxRQUFRMUksWUFBWXdLLEVBQUU5QjtvQkFBUSxJQUFJeEYsSUFBRWtCLEtBQUtxSCxtQkFBbUI0QixTQUFTakosS0FBS21JLGNBQWMzTDtvQkFBSXNDLEtBQUdqQixFQUFFaUIsR0FBRzdDLFNBQVNtSyxFQUFFOUI7O2VBQVU3RCxFQUFFckMsVUFBVW9KLFNBQU8sU0FBU2hMLEdBQUVzQztnQkFBRyxJQUFJL0MsSUFBRWlFLE1BQUtmLElBQUVwQixFQUFFbUMsS0FBS21ELFVBQVVySCxLQUFLeUssRUFBRUMsYUFBYSxJQUFHeEYsSUFBRWxDLEtBQUdHLEtBQUdlLEtBQUs0SSxvQkFBb0JwTSxHQUFFeUMsSUFBR1UsSUFBRXdDLFFBQVFuQyxLQUFLK0csWUFBVzFGLFNBQU8sR0FBRVosU0FBTyxHQUFFRyxTQUFPO2dCQUFFLElBQUdwRSxNQUFJZ0osRUFBRUMsUUFBTXBFLElBQUUrRSxFQUFFVCxNQUFLbEYsSUFBRTJGLEVBQUVYLE1BQUs3RSxJQUFFNEUsRUFBRUcsU0FBT3RFLElBQUUrRSxFQUFFUixPQUFNbkYsSUFBRTJGLEVBQUVWO2dCQUFLOUUsSUFBRTRFLEVBQUVJLFFBQU81RSxLQUFHbkQsRUFBRW1ELEdBQUczRSxTQUFTK0osRUFBRTlCLFNBQVEsYUFBWXRFLEtBQUtrSCxjQUFZO2dCQUFHLElBQUl4RSxJQUFFMUMsS0FBSzZJLG1CQUFtQjdILEdBQUVKO2dCQUFHLEtBQUk4QixFQUFFYSx3QkFBc0J0RSxLQUFHK0IsR0FBRTtvQkFBQ2hCLEtBQUtrSCxjQUFZLEdBQUV2SCxLQUFHSyxLQUFLcUYsU0FBUXJGLEtBQUtnSiwyQkFBMkJoSTtvQkFBRyxJQUFJOEIsSUFBRWpGLEVBQUUrRixNQUFNaUMsRUFBRUU7d0JBQU0rQyxlQUFjOUg7d0JBQUUrSCxXQUFVbkk7O29CQUFJeEIsRUFBRThCLDJCQUF5QnJELEVBQUVtQyxLQUFLbUQsVUFBVTlHLFNBQVMrSixFQUFFTixVQUFRakksRUFBRW1ELEdBQUcvRSxTQUFTd0U7b0JBQUdyQixFQUFFNkMsT0FBT2pCLElBQUduRCxFQUFFb0IsR0FBR2hELFNBQVNvRixJQUFHeEQsRUFBRW1ELEdBQUcvRSxTQUFTb0YsSUFBR3hELEVBQUVvQixHQUFHMEIsSUFBSXZCLEVBQUV5QixnQkFBZTt3QkFBV2hELEVBQUVtRCxHQUFHcEYsWUFBWXlGLElBQUUsTUFBSVosR0FBR3hFLFNBQVNtSyxFQUFFOUIsU0FBUXpHLEVBQUVvQixHQUFHckQsWUFBWXdLLEVBQUU5QixTQUFPLE1BQUk3RCxJQUFFLE1BQUlZO3dCQUFHdEYsRUFBRW1MLGNBQVksR0FBRXBHLFdBQVc7NEJBQVcsT0FBT2pELEVBQUU5QixFQUFFb0gsVUFBVTFGLFFBQVFxRjsyQkFBSTt1QkFBSzdCLHFCQUFxQnVCLE9BQUszRSxFQUFFb0IsR0FBR3JELFlBQVl3SyxFQUFFOUIsU0FBUXpHLEVBQUVtRCxHQUFHL0UsU0FBU21LLEVBQUU5QjtvQkFBUXRFLEtBQUtrSCxjQUFZLEdBQUVySixFQUFFbUMsS0FBS21ELFVBQVUxRixRQUFRcUYsS0FBSW5ELEtBQUdLLEtBQUs2SDs7ZUFBVXBILEVBQUV1RCxtQkFBaUIsU0FBU3hIO2dCQUFHLE9BQU93RCxLQUFLaEUsS0FBSztvQkFBVyxJQUFJOEMsSUFBRWpCLEVBQUVtQyxNQUFNaUUsS0FBS3RFLElBQUdWLElBQUVwQixFQUFFd0ssV0FBVW5GLEdBQUVyRixFQUFFbUMsTUFBTWlFO29CQUFRLGNBQVksc0JBQW9CekgsSUFBRSxjQUFZVCxFQUFFUyxPQUFLcUIsRUFBRXdLLE9BQU9wSixHQUFFekM7b0JBQUcsSUFBSTRDLElBQUUsbUJBQWlCNUMsSUFBRUEsSUFBRXlDLEVBQUVtRztvQkFBTSxJQUFHdEcsTUFBSUEsSUFBRSxJQUFJMkIsRUFBRVQsTUFBS2YsSUFBR3BCLEVBQUVtQyxNQUFNaUUsS0FBS3RFLEdBQUViLEtBQUksbUJBQWlCdEMsR0FBRXNDLEVBQUVvSixHQUFHMUwsU0FBUSxJQUFHLG1CQUFpQjRDLEdBQUU7d0JBQUMsU0FBUSxNQUFJTixFQUFFTSxJQUFHLE1BQU0sSUFBSXhCLE1BQU0sc0JBQW9Cd0IsSUFBRTt3QkFBS04sRUFBRU07MkJBQVVILEVBQUVpRyxhQUFXcEcsRUFBRXVHLFNBQVF2RyxFQUFFK0k7O2VBQVlwSCxFQUFFeUksdUJBQXFCLFNBQVMxTTtnQkFBRyxJQUFJc0MsSUFBRU0sRUFBRTBDLHVCQUF1QjlCO2dCQUFNLElBQUdsQixHQUFFO29CQUFDLElBQUkvQyxJQUFFOEIsRUFBRWlCLEdBQUc7b0JBQUcsSUFBRy9DLEtBQUc4QixFQUFFOUIsR0FBR00sU0FBUytKLEVBQUVDLFdBQVU7d0JBQUMsSUFBSXBILElBQUVwQixFQUFFd0ssV0FBVXhLLEVBQUU5QixHQUFHa0ksUUFBT3BHLEVBQUVtQyxNQUFNaUUsU0FBUWpELElBQUVoQixLQUFLK0IsYUFBYTt3QkFBaUJmLE1BQUkvQixFQUFFaUcsWUFBVSxJQUFHekUsRUFBRXVELGlCQUFpQjFFLEtBQUt6QixFQUFFOUIsSUFBR2tELElBQUcrQixLQUFHbkQsRUFBRTlCLEdBQUdrSSxLQUFLdEUsR0FBR3VJLEdBQUdsSDt3QkFBR3hFLEVBQUVnQjs7O2VBQW9CeUIsRUFBRXdCLEdBQUU7Z0JBQU90QixLQUFJO2dCQUFVZ0YsS0FBSSxTQUFBQTtvQkFBVyxPQUFPbkQ7OztnQkFBSzdCLEtBQUk7Z0JBQVVnRixLQUFJLFNBQUFBO29CQUFXLE9BQU9qQjs7a0JBQU16Qzs7UUFBSyxPQUFPNUMsRUFBRTBDLFVBQVVoRSxHQUFHc0osRUFBRWhELGdCQUFlMEQsRUFBRUksWUFBV0UsRUFBRXFDLHVCQUFzQnJMLEVBQUV3QyxRQUFROUQsR0FBR3NKLEVBQUVNLGVBQWM7WUFBV3RJLEVBQUUwSSxFQUFFSyxXQUFXNUssS0FBSztnQkFBVyxJQUFJUSxJQUFFcUIsRUFBRW1DO2dCQUFNNkcsRUFBRTdDLGlCQUFpQjFFLEtBQUs5QyxHQUFFQSxFQUFFeUg7O1lBQVlwRyxFQUFFQyxHQUFHdEIsS0FBR3FLLEVBQUU3QyxrQkFBaUJuRyxFQUFFQyxHQUFHdEIsR0FBRzRILGNBQVl5QyxHQUFFaEosRUFBRUMsR0FBR3RCLEdBQUc2SCxhQUFXO1lBQVcsT0FBT3hHLEVBQUVDLEdBQUd0QixLQUFHb0UsR0FBRWlHLEVBQUU3QztXQUFrQjZDO01BQUdsSixTQUFRLFNBQVNFO1FBQUcsSUFBSXJCLElBQUUsWUFBV3dFLElBQUUsaUJBQWdCckIsSUFBRSxlQUFjMEIsSUFBRSxNQUFJMUIsR0FBRWMsSUFBRSxhQUFZRyxJQUFFL0MsRUFBRUMsR0FBR3RCLElBQUdnRyxJQUFFLEtBQUlFO1lBQUdtQyxTQUFRO1lBQUVoSixRQUFPO1dBQUlpSDtZQUFHK0IsUUFBTztZQUFVaEosUUFBTztXQUFVcUg7WUFBR0QsTUFBSyxTQUFPNUI7WUFBRThILE9BQU0sVUFBUTlIO1lBQUUrSCxNQUFLLFNBQU8vSDtZQUFFZ0ksUUFBTyxXQUFTaEk7WUFBRXdCLGdCQUFlLFVBQVF4QixJQUFFWjtXQUFHOEU7WUFBR3RDLE1BQUs7WUFBT3FHLFVBQVM7WUFBV0MsWUFBVztZQUFhQyxXQUFVO1dBQWFoRTtZQUFHaUUsT0FBTTtZQUFRQyxRQUFPO1dBQVU3RDtZQUFHOEQsU0FBUTtZQUFxQ2pGLGFBQVk7V0FBNEIwQixJQUFFO1lBQVcsU0FBUy9FLEVBQUU3RSxHQUFFVDtnQkFBRytDLEVBQUVrQixNQUFLcUIsSUFBR3JCLEtBQUs0SixvQkFBa0IsR0FBRTVKLEtBQUttRCxXQUFTM0csR0FBRXdELEtBQUttSCxVQUFRbkgsS0FBS29ILFdBQVdyTDtnQkFBR2lFLEtBQUs2SixnQkFBY2hNLEVBQUU2SyxVQUFVN0ssRUFBRSxxQ0FBbUNyQixFQUFFc04sS0FBRyxTQUFPLDRDQUEwQ3ROLEVBQUVzTixLQUFHO2dCQUFROUosS0FBSytKLFVBQVEvSixLQUFLbUgsUUFBUXRMLFNBQU9tRSxLQUFLZ0ssZUFBYSxNQUFLaEssS0FBS21ILFFBQVF0TCxVQUFRbUUsS0FBS2lLLDBCQUEwQmpLLEtBQUttRCxVQUFTbkQsS0FBSzZKO2dCQUFlN0osS0FBS21ILFFBQVF0QyxVQUFRN0UsS0FBSzZFOztZQUFTLE9BQU94RCxFQUFFakQsVUFBVXlHLFNBQU87Z0JBQVdoSCxFQUFFbUMsS0FBS21ELFVBQVU5RyxTQUFTa0osRUFBRXRDLFFBQU1qRCxLQUFLMUUsU0FBTzBFLEtBQUt6RTtlQUFROEYsRUFBRWpELFVBQVU3QyxPQUFLO2dCQUFXLElBQUlpQixJQUFFd0Q7Z0JBQUssSUFBR0EsS0FBSzRKLGtCQUFpQixNQUFNLElBQUloTSxNQUFNO2dCQUE2QixLQUFJQyxFQUFFbUMsS0FBS21ELFVBQVU5RyxTQUFTa0osRUFBRXRDLE9BQU07b0JBQUMsSUFBSW5FLFNBQU8sR0FBRS9DLFNBQU87b0JBQUUsSUFBR2lFLEtBQUsrSixZQUFVakwsSUFBRWpCLEVBQUU2SyxVQUFVN0ssRUFBRW1DLEtBQUsrSixTQUFTak8sS0FBSytKLEVBQUU4RCxXQUFVN0ssRUFBRXpELFdBQVN5RCxJQUFFO3NCQUFTQSxNQUFJL0MsSUFBRThCLEVBQUVpQixHQUFHbUYsS0FBS3RFLElBQUc1RCxLQUFHQSxFQUFFNk4sb0JBQW1CO3dCQUFDLElBQUkzSyxJQUFFcEIsRUFBRStGLE1BQU1WLEVBQUVEO3dCQUFNLElBQUdwRixFQUFFbUMsS0FBS21ELFVBQVUxRixRQUFRd0IsS0FBSUEsRUFBRXNFLHNCQUFxQjs0QkFBQ3pFLE1BQUl1QyxFQUFFMkMsaUJBQWlCMUUsS0FBS3pCLEVBQUVpQixJQUFHLFNBQVEvQyxLQUFHOEIsRUFBRWlCLEdBQUdtRixLQUFLdEUsR0FBRTs0QkFBTyxJQUFJcUIsSUFBRWhCLEtBQUtrSzs0QkFBZ0JyTSxFQUFFbUMsS0FBS21ELFVBQVV2SCxZQUFZMkosRUFBRStELFVBQVVyTixTQUFTc0osRUFBRWdFLGFBQVl2SixLQUFLbUQsU0FBU3pDLE1BQU1NLEtBQUc7NEJBQUVoQixLQUFLbUQsU0FBUzZCLGFBQWEsa0JBQWlCLElBQUdoRixLQUFLNkosY0FBY3hPLFVBQVF3QyxFQUFFbUMsS0FBSzZKLGVBQWVqTyxZQUFZMkosRUFBRWlFLFdBQVdXLEtBQUssa0JBQWlCOzRCQUFHbkssS0FBS29LLGtCQUFrQjs0QkFBRyxJQUFJM0osSUFBRSxTQUFGQTtnQ0FBYTVDLEVBQUVyQixFQUFFMkcsVUFBVXZILFlBQVkySixFQUFFZ0UsWUFBWXROLFNBQVNzSixFQUFFK0QsVUFBVXJOLFNBQVNzSixFQUFFdEMsT0FBTXpHLEVBQUUyRyxTQUFTekMsTUFBTU0sS0FBRztnQ0FBR3hFLEVBQUU0TixrQkFBa0IsSUFBR3ZNLEVBQUVyQixFQUFFMkcsVUFBVTFGLFFBQVF5RixFQUFFaUc7OzRCQUFRLEtBQUkvSixFQUFFOEIseUJBQXdCLFlBQVlUOzRCQUFJLElBQUlHLElBQUVJLEVBQUUsR0FBR3VCLGdCQUFjdkIsRUFBRXFKLE1BQU0sSUFBRzNILElBQUUsV0FBUzlCOzRCQUFFL0MsRUFBRW1DLEtBQUttRCxVQUFVeEMsSUFBSXZCLEVBQUV5QixnQkFBZUosR0FBR1EscUJBQXFCdUIsSUFBR3hDLEtBQUttRCxTQUFTekMsTUFBTU0sS0FBR2hCLEtBQUttRCxTQUFTVCxLQUFHOzs7O2VBQVNyQixFQUFFakQsVUFBVTlDLE9BQUs7Z0JBQVcsSUFBSWtCLElBQUV3RDtnQkFBSyxJQUFHQSxLQUFLNEosa0JBQWlCLE1BQU0sSUFBSWhNLE1BQU07Z0JBQTZCLElBQUdDLEVBQUVtQyxLQUFLbUQsVUFBVTlHLFNBQVNrSixFQUFFdEMsT0FBTTtvQkFBQyxJQUFJbkUsSUFBRWpCLEVBQUUrRixNQUFNVixFQUFFa0c7b0JBQU0sSUFBR3ZMLEVBQUVtQyxLQUFLbUQsVUFBVTFGLFFBQVFxQixLQUFJQSxFQUFFeUUsc0JBQXFCO3dCQUFDLElBQUl4SCxJQUFFaUUsS0FBS2tLLGlCQUFnQmpMLElBQUVsRCxNQUFJeUosRUFBRWlFLFFBQU0sZ0JBQWM7d0JBQWV6SixLQUFLbUQsU0FBU3pDLE1BQU0zRSxLQUFHaUUsS0FBS21ELFNBQVNsRSxLQUFHLE1BQUtHLEVBQUU2QyxPQUFPakMsS0FBS21ELFdBQVV0RixFQUFFbUMsS0FBS21ELFVBQVVsSCxTQUFTc0osRUFBRWdFLFlBQVkzTixZQUFZMkosRUFBRStELFVBQVUxTixZQUFZMkosRUFBRXRDO3dCQUFNakQsS0FBS21ELFNBQVM2QixhQUFhLGtCQUFpQixJQUFHaEYsS0FBSzZKLGNBQWN4TyxVQUFRd0MsRUFBRW1DLEtBQUs2SixlQUFlNU4sU0FBU3NKLEVBQUVpRSxXQUFXVyxLQUFLLGtCQUFpQjt3QkFBR25LLEtBQUtvSyxrQkFBa0I7d0JBQUcsSUFBSXBKLElBQUUsU0FBRkE7NEJBQWF4RSxFQUFFNE4sa0JBQWtCLElBQUd2TSxFQUFFckIsRUFBRTJHLFVBQVV2SCxZQUFZMkosRUFBRWdFLFlBQVl0TixTQUFTc0osRUFBRStELFVBQVU3TCxRQUFReUYsRUFBRW1HOzt3QkFBUyxPQUFPckosS0FBS21ELFNBQVN6QyxNQUFNM0UsS0FBRyxJQUFHcUQsRUFBRThCLCtCQUE2QnJELEVBQUVtQyxLQUFLbUQsVUFBVXhDLElBQUl2QixFQUFFeUIsZ0JBQWVHLEdBQUdDLHFCQUFxQnVCLFVBQVF4Qjs7O2VBQU9LLEVBQUVqRCxVQUFVZ00sbUJBQWlCLFNBQVN2TTtnQkFBR21DLEtBQUs0SixtQkFBaUIvTDtlQUFHd0QsRUFBRWpELFVBQVVxRixVQUFRO2dCQUFXNUYsRUFBRTZGLFdBQVcxRCxLQUFLbUQsVUFBU3hELElBQUdLLEtBQUttSCxVQUFRLE1BQUtuSCxLQUFLK0osVUFBUSxNQUFLL0osS0FBS21ELFdBQVM7Z0JBQUtuRCxLQUFLNkosZ0JBQWMsTUFBSzdKLEtBQUs0SixtQkFBaUI7ZUFBTXZJLEVBQUVqRCxVQUFVZ0osYUFBVyxTQUFTdEk7Z0JBQUcsT0FBT0EsSUFBRWpCLEVBQUV3SyxXQUFVM0YsR0FBRTVELElBQUdBLEVBQUUrRixTQUFPMUMsUUFBUXJELEVBQUUrRixTQUFRekYsRUFBRWdELGdCQUFnQjVGLEdBQUVzQyxHQUFFZ0U7Z0JBQUdoRTtlQUFHdUMsRUFBRWpELFVBQVU4TCxnQkFBYztnQkFBVyxJQUFJMU4sSUFBRXFCLEVBQUVtQyxLQUFLbUQsVUFBVTlHLFNBQVNtSixFQUFFaUU7Z0JBQU8sT0FBT2pOLElBQUVnSixFQUFFaUUsUUFBTWpFLEVBQUVrRTtlQUFRckksRUFBRWpELFVBQVU0TCxhQUFXO2dCQUFXLElBQUl4TixJQUFFd0QsTUFBS2xCLElBQUVqQixFQUFFbUMsS0FBS21ILFFBQVF0TCxRQUFRLElBQUdFLElBQUUsMkNBQXlDaUUsS0FBS21ILFFBQVF0TCxTQUFPO2dCQUFLLE9BQU9nQyxFQUFFaUIsR0FBR2hELEtBQUtDLEdBQUdDLEtBQUssU0FBUzZCLEdBQUVpQjtvQkFBR3RDLEVBQUV5TiwwQkFBMEI1SSxFQUFFaUosc0JBQXNCeEwsTUFBSUE7b0JBQU1BO2VBQUd1QyxFQUFFakQsVUFBVTZMLDRCQUEwQixTQUFTek4sR0FBRXNDO2dCQUFHLElBQUd0QyxHQUFFO29CQUFDLElBQUlULElBQUU4QixFQUFFckIsR0FBR0gsU0FBU2tKLEVBQUV0QztvQkFBTXpHLEVBQUV3SSxhQUFhLGlCQUFnQmpKLElBQUcrQyxFQUFFekQsVUFBUXdDLEVBQUVpQixHQUFHbUcsWUFBWU0sRUFBRWlFLFlBQVd6TixHQUFHb08sS0FBSyxpQkFBZ0JwTzs7ZUFBS3NGLEVBQUVpSix3QkFBc0IsU0FBUzlOO2dCQUFHLElBQUlzQyxJQUFFTSxFQUFFMEMsdUJBQXVCdEY7Z0JBQUcsT0FBT3NDLElBQUVqQixFQUFFaUIsR0FBRyxLQUFHO2VBQU11QyxFQUFFMkMsbUJBQWlCLFNBQVN4SDtnQkFBRyxPQUFPd0QsS0FBS2hFLEtBQUs7b0JBQVcsSUFBSThDLElBQUVqQixFQUFFbUMsT0FBTWYsSUFBRUgsRUFBRW1GLEtBQUt0RSxJQUFHUCxJQUFFdkIsRUFBRXdLLFdBQVUzRixHQUFFNUQsRUFBRW1GLFFBQU8sY0FBWSxzQkFBb0J6SCxJQUFFLGNBQVlULEVBQUVTLE9BQUtBO29CQUFHLEtBQUl5QyxLQUFHRyxFQUFFeUYsVUFBUSxZQUFZN0MsS0FBS3hGLE9BQUs0QyxFQUFFeUYsVUFBUSxJQUFHNUYsTUFBSUEsSUFBRSxJQUFJb0MsRUFBRXJCLE1BQUtaO29CQUFHTixFQUFFbUYsS0FBS3RFLEdBQUVWLEtBQUksbUJBQWlCekMsR0FBRTt3QkFBQyxTQUFRLE1BQUl5QyxFQUFFekMsSUFBRyxNQUFNLElBQUlvQixNQUFNLHNCQUFvQnBCLElBQUU7d0JBQUt5QyxFQUFFekM7OztlQUFTeUMsRUFBRW9DLEdBQUU7Z0JBQU9sQyxLQUFJO2dCQUFVZ0YsS0FBSSxTQUFBQTtvQkFBVyxPQUFPbkQ7OztnQkFBSzdCLEtBQUk7Z0JBQVVnRixLQUFJLFNBQUFBO29CQUFXLE9BQU96Qjs7a0JBQU1yQjs7UUFBSyxPQUFPeEQsRUFBRTBDLFVBQVVoRSxHQUFHMkcsRUFBRUwsZ0JBQWVnRCxFQUFFbkIsYUFBWSxTQUFTbEk7WUFBR0EsRUFBRWdCO1lBQWlCLElBQUlzQixJQUFFc0gsRUFBRWtFLHNCQUFzQnRLLE9BQU1qRSxJQUFFOEIsRUFBRWlCLEdBQUdtRixLQUFLdEUsSUFBR1YsSUFBRWxELElBQUUsV0FBUzhCLEVBQUVtQyxNQUFNaUU7WUFBT21DLEVBQUVwQyxpQkFBaUIxRSxLQUFLekIsRUFBRWlCLElBQUdHO1lBQUtwQixFQUFFQyxHQUFHdEIsS0FBRzRKLEVBQUVwQyxrQkFBaUJuRyxFQUFFQyxHQUFHdEIsR0FBRzRILGNBQVlnQyxHQUFFdkksRUFBRUMsR0FBR3RCLEdBQUc2SCxhQUFXO1lBQVcsT0FBT3hHLEVBQUVDLEdBQUd0QixLQUFHb0UsR0FBRXdGLEVBQUVwQztXQUFrQm9DO01BQUd6SSxTQUFRLFNBQVNFO1FBQUcsSUFBSXJCLElBQUUsWUFBV1QsSUFBRSxpQkFBZ0JpRixJQUFFLGVBQWNyQixJQUFFLE1BQUlxQixHQUFFSyxJQUFFLGFBQVlaLElBQUU1QyxFQUFFQyxHQUFHdEIsSUFBR29FLElBQUUsSUFBRzRCLElBQUUsSUFBR0UsSUFBRSxJQUFHSSxJQUFFLEdBQUVJO1lBQUdrRyxNQUFLLFNBQU96SjtZQUFFMEosUUFBTyxXQUFTMUo7WUFBRXNELE1BQUssU0FBT3REO1lBQUV3SixPQUFNLFVBQVF4SjtZQUFFNEssT0FBTSxVQUFRNUs7WUFBRWtELGdCQUFlLFVBQVFsRCxJQUFFMEI7WUFBRW1KLGtCQUFpQixZQUFVN0ssSUFBRTBCO1lBQUVvSixrQkFBaUIsWUFBVTlLLElBQUUwQjtXQUFHa0U7WUFBR21GLFVBQVM7WUFBb0JDLFVBQVM7WUFBVzFILE1BQUs7V0FBUXVDO1lBQUdrRixVQUFTO1lBQXFCaEcsYUFBWTtZQUEyQmtHLFlBQVc7WUFBaUJDLFdBQVU7WUFBZ0JDLGNBQWE7WUFBbUJDLFlBQVc7WUFBY0MsZUFBYztXQUEyRW5GLElBQUU7WUFBVyxTQUFTckosRUFBRXFCO2dCQUFHaUIsRUFBRWtCLE1BQUt4RCxJQUFHd0QsS0FBS21ELFdBQVN0RixHQUFFbUMsS0FBS3NIOztZQUFxQixPQUFPOUssRUFBRTRCLFVBQVV5RyxTQUFPO2dCQUFXLElBQUc3RSxLQUFLaUwsWUFBVXBOLEVBQUVtQyxNQUFNM0QsU0FBU2tKLEVBQUVvRixXQUFVLFFBQU87Z0JBQUUsSUFBSTdMLElBQUV0QyxFQUFFME8sc0JBQXNCbEwsT0FBTWpFLElBQUU4QixFQUFFaUIsR0FBR3pDLFNBQVNrSixFQUFFdEM7Z0JBQU0sSUFBR3pHLEVBQUUyTyxlQUFjcFAsR0FBRSxRQUFPO2dCQUFFLElBQUcsa0JBQWlCd0UsU0FBU2dJLG9CQUFrQjFLLEVBQUVpQixHQUFHNkUsUUFBUTZCLEVBQUV1RixZQUFZMVAsUUFBTztvQkFBQyxJQUFJNEQsSUFBRXNCLFNBQVNDLGNBQWM7b0JBQU92QixFQUFFbU0sWUFBVTdGLEVBQUVtRixVQUFTN00sRUFBRW9CLEdBQUdvTSxhQUFhckwsT0FBTW5DLEVBQUVvQixHQUFHMUMsR0FBRyxTQUFRQyxFQUFFMk87O2dCQUFhLElBQUkvTDtvQkFBRzBKLGVBQWM5STttQkFBTWdCLElBQUVuRCxFQUFFK0YsTUFBTVYsRUFBRUQsTUFBSzdEO2dCQUFHLE9BQU92QixFQUFFaUIsR0FBR3JCLFFBQVF1RCxLQUFJQSxFQUFFdUMseUJBQXVCdkQsS0FBSytFLFNBQVEvRSxLQUFLZ0YsYUFBYSxrQkFBaUI7Z0JBQUduSCxFQUFFaUIsR0FBR21HLFlBQVlNLEVBQUV0QyxPQUFNcEYsRUFBRWlCLEdBQUdyQixRQUFRSSxFQUFFK0YsTUFBTVYsRUFBRWlHLE9BQU0vSixNQUFLO2VBQUk1QyxFQUFFNEIsVUFBVXFGLFVBQVE7Z0JBQVc1RixFQUFFNkYsV0FBVzFELEtBQUttRCxVQUFTbkMsSUFBR25ELEVBQUVtQyxLQUFLbUQsVUFBVWlGLElBQUl6SSxJQUFHSyxLQUFLbUQsV0FBUztlQUFNM0csRUFBRTRCLFVBQVVrSixxQkFBbUI7Z0JBQVd6SixFQUFFbUMsS0FBS21ELFVBQVU1RyxHQUFHMkcsRUFBRXFILE9BQU12SyxLQUFLNkU7ZUFBU3JJLEVBQUV3SCxtQkFBaUIsU0FBU2xGO2dCQUFHLE9BQU9rQixLQUFLaEUsS0FBSztvQkFBVyxJQUFJRCxJQUFFOEIsRUFBRW1DLE1BQU1pRSxLQUFLakQ7b0JBQUcsSUFBR2pGLE1BQUlBLElBQUUsSUFBSVMsRUFBRXdELE9BQU1uQyxFQUFFbUMsTUFBTWlFLEtBQUtqRCxHQUFFakYsS0FBSSxtQkFBaUIrQyxHQUFFO3dCQUFDLFNBQVEsTUFBSS9DLEVBQUUrQyxJQUFHLE1BQU0sSUFBSWxCLE1BQU0sc0JBQW9Ca0IsSUFBRTt3QkFBSy9DLEVBQUUrQyxHQUFHUSxLQUFLVTs7O2VBQVV4RCxFQUFFMk8sY0FBWSxTQUFTck07Z0JBQUcsS0FBSUEsS0FBR0EsRUFBRTJKLFVBQVEzRixHQUFFO29CQUFDLElBQUkvRyxJQUFFOEIsRUFBRTJILEVBQUVrRixVQUFVO29CQUFHM08sS0FBR0EsRUFBRXVQLFdBQVdDLFlBQVl4UDtvQkFBRyxLQUFJLElBQUlrRCxJQUFFcEIsRUFBRTZLLFVBQVU3SyxFQUFFMkgsRUFBRWQsZUFBY3RGLElBQUUsR0FBRUEsSUFBRUgsRUFBRTVELFFBQU8rRCxLQUFJO3dCQUFDLElBQUk0QixJQUFFeEUsRUFBRTBPLHNCQUFzQmpNLEVBQUVHLEtBQUlPOzRCQUFHbUosZUFBYzdKLEVBQUVHOzt3QkFBSSxJQUFHdkIsRUFBRW1ELEdBQUczRSxTQUFTa0osRUFBRXRDLFdBQVNuRSxNQUFJLFlBQVVBLEVBQUVnRyxRQUFNLGtCQUFrQjlDLEtBQUtsRCxFQUFFNUIsT0FBT3NMLFlBQVUsY0FBWTFKLEVBQUVnRyxTQUFPakgsRUFBRTJOLFNBQVN4SyxHQUFFbEMsRUFBRTVCLFVBQVM7NEJBQUMsSUFBSW1FLElBQUV4RCxFQUFFK0YsTUFBTVYsRUFBRWtHLE1BQUt6Sjs0QkFBRzlCLEVBQUVtRCxHQUFHdkQsUUFBUTRELElBQUdBLEVBQUVrQyx5QkFBdUJ0RSxFQUFFRyxHQUFHNEYsYUFBYSxpQkFBZ0I7NEJBQVNuSCxFQUFFbUQsR0FBR3BGLFlBQVkySixFQUFFdEMsTUFBTXhGLFFBQVFJLEVBQUUrRixNQUFNVixFQUFFbUcsUUFBTzFKOzs7O2VBQVNuRCxFQUFFME8sd0JBQXNCLFNBQVMxTztnQkFBRyxJQUFJc0MsU0FBTyxHQUFFL0MsSUFBRXFELEVBQUUwQyx1QkFBdUJ0RjtnQkFBRyxPQUFPVCxNQUFJK0MsSUFBRWpCLEVBQUU5QixHQUFHLEtBQUkrQyxLQUFHdEMsRUFBRThPO2VBQVk5TyxFQUFFaVAseUJBQXVCLFNBQVMzTTtnQkFBRyxJQUFHLGdCQUFnQmtELEtBQUtsRCxFQUFFMkosV0FBUyxrQkFBa0J6RyxLQUFLbEQsRUFBRTVCLE9BQU9zTCxhQUFXMUosRUFBRXRCO2dCQUFpQnNCLEVBQUU0TSxvQkFBbUIxTCxLQUFLaUwsYUFBV3BOLEVBQUVtQyxNQUFNM0QsU0FBU2tKLEVBQUVvRixZQUFXO29CQUFDLElBQUk1TyxJQUFFUyxFQUFFME8sc0JBQXNCbEwsT0FBTWYsSUFBRXBCLEVBQUU5QixHQUFHTSxTQUFTa0osRUFBRXRDO29CQUFNLEtBQUloRSxLQUFHSCxFQUFFMkosVUFBUTdILEtBQUczQixLQUFHSCxFQUFFMkosVUFBUTdILEdBQUU7d0JBQUMsSUFBRzlCLEVBQUUySixVQUFRN0gsR0FBRTs0QkFBQyxJQUFJeEIsSUFBRXZCLEVBQUU5QixHQUFHRCxLQUFLMEosRUFBRWQsYUFBYTs0QkFBRzdHLEVBQUV1QixHQUFHM0IsUUFBUTs7d0JBQVMsWUFBWUksRUFBRW1DLE1BQU12QyxRQUFROztvQkFBUyxJQUFJdUQsSUFBRW5ELEVBQUU5QixHQUFHRCxLQUFLMEosRUFBRXdGLGVBQWU3RztvQkFBTSxJQUFHbkQsRUFBRTNGLFFBQU87d0JBQUMsSUFBSXNFLElBQUVxQixFQUFFMkgsUUFBUTdKLEVBQUU1Qjt3QkFBUTRCLEVBQUUySixVQUFRakcsS0FBRzdDLElBQUUsS0FBR0EsS0FBSWIsRUFBRTJKLFVBQVEvRixLQUFHL0MsSUFBRXFCLEVBQUUzRixTQUFPLEtBQUdzRSxLQUFJQSxJQUFFLE1BQUlBLElBQUU7d0JBQUdxQixFQUFFckIsR0FBR29GOzs7ZUFBVzlGLEVBQUV6QyxHQUFFO2dCQUFPMkMsS0FBSTtnQkFBVWdGLEtBQUksU0FBQUE7b0JBQVcsT0FBT3BJOztrQkFBTVM7O1FBQUssT0FBT3FCLEVBQUUwQyxVQUFVaEUsR0FBRzJHLEVBQUV1SCxrQkFBaUJqRixFQUFFZCxhQUFZbUIsRUFBRTRGLHdCQUF3QmxQLEdBQUcyRyxFQUFFdUgsa0JBQWlCakYsRUFBRXFGLFdBQVVoRixFQUFFNEYsd0JBQXdCbFAsR0FBRzJHLEVBQUV1SCxrQkFBaUJqRixFQUFFc0YsY0FBYWpGLEVBQUU0Rix3QkFBd0JsUCxHQUFHMkcsRUFBRUwsaUJBQWUsTUFBSUssRUFBRXNILGtCQUFpQjNFLEVBQUVzRixhQUFhNU8sR0FBRzJHLEVBQUVMLGdCQUFlMkMsRUFBRWQsYUFBWW1CLEVBQUV6SCxVQUFVeUcsUUFBUXRJLEdBQUcyRyxFQUFFTCxnQkFBZTJDLEVBQUVvRixZQUFXLFNBQVMvTTtZQUFHQSxFQUFFNk47WUFBb0I3TixFQUFFQyxHQUFHdEIsS0FBR3FKLEVBQUU3QixrQkFBaUJuRyxFQUFFQyxHQUFHdEIsR0FBRzRILGNBQVl5QixHQUFFaEksRUFBRUMsR0FBR3RCLEdBQUc2SCxhQUFXO1lBQVcsT0FBT3hHLEVBQUVDLEdBQUd0QixLQUFHaUUsR0FBRW9GLEVBQUU3QjtXQUFrQjZCO01BQUdsSSxTQUFRLFNBQVNFO1FBQUcsSUFBSXJCLElBQUUsU0FBUXdFLElBQUUsaUJBQWdCckIsSUFBRSxZQUFXMEIsSUFBRSxNQUFJMUIsR0FBRWMsSUFBRSxhQUFZRyxJQUFFL0MsRUFBRUMsR0FBR3RCLElBQUdnRyxJQUFFLEtBQUlFLElBQUUsS0FBSUksSUFBRSxJQUFHSTtZQUFHeUksV0FBVTtZQUFFeEcsV0FBVTtZQUFFSixRQUFPO1lBQUV4SixPQUFNO1dBQUdnSztZQUFHb0csVUFBUztZQUFtQnhHLFVBQVM7WUFBVUosT0FBTTtZQUFVeEosTUFBSztXQUFXaUs7WUFBRzRELE1BQUssU0FBTy9IO1lBQUVnSSxRQUFPLFdBQVNoSTtZQUFFNEIsTUFBSyxTQUFPNUI7WUFBRThILE9BQU0sVUFBUTlIO1lBQUV1SyxTQUFRLFlBQVV2SztZQUFFd0ssUUFBTyxXQUFTeEs7WUFBRXlLLGVBQWMsa0JBQWdCeks7WUFBRTBLLGlCQUFnQixvQkFBa0IxSztZQUFFMkssaUJBQWdCLG9CQUFrQjNLO1lBQUU0SyxtQkFBa0Isc0JBQW9CNUs7WUFBRXdCLGdCQUFlLFVBQVF4QixJQUFFWjtXQUFHb0Y7WUFBR3FHLG9CQUFtQjtZQUEwQnhCLFVBQVM7WUFBaUJ5QixNQUFLO1lBQWFuSixNQUFLO1lBQU9DLE1BQUs7V0FBUW1EO1lBQUdnRyxRQUFPO1lBQWdCMUgsYUFBWTtZQUF3QjJILGNBQWE7WUFBeUJDLGVBQWM7V0FBcUQvRixJQUFFO1lBQVcsU0FBUzlGLEVBQUVqRSxHQUFFVDtnQkFBRytDLEVBQUVrQixNQUFLUyxJQUFHVCxLQUFLbUgsVUFBUW5ILEtBQUtvSCxXQUFXckwsSUFBR2lFLEtBQUttRCxXQUFTM0csR0FBRXdELEtBQUt1TSxVQUFRMU8sRUFBRXJCLEdBQUdWLEtBQUtzSyxFQUFFZ0csUUFBUTtnQkFBR3BNLEtBQUt3TSxZQUFVLE1BQUt4TSxLQUFLeU0sWUFBVSxHQUFFek0sS0FBSzBNLHNCQUFvQixHQUFFMU0sS0FBSzJNLHdCQUFzQjtnQkFBRTNNLEtBQUs0SixvQkFBa0IsR0FBRTVKLEtBQUs0TSx1QkFBcUIsR0FBRTVNLEtBQUs2TSxrQkFBZ0I7O1lBQUUsT0FBT3BNLEVBQUVyQyxVQUFVeUcsU0FBTyxTQUFTaEg7Z0JBQUcsT0FBT21DLEtBQUt5TSxXQUFTek0sS0FBSzFFLFNBQU8wRSxLQUFLekUsS0FBS3NDO2VBQUk0QyxFQUFFckMsVUFBVTdDLE9BQUssU0FBU2lCO2dCQUFHLElBQUlzQyxJQUFFa0I7Z0JBQUssSUFBR0EsS0FBSzRKLGtCQUFpQixNQUFNLElBQUloTSxNQUFNO2dCQUEwQndCLEVBQUU4QiwyQkFBeUJyRCxFQUFFbUMsS0FBS21ELFVBQVU5RyxTQUFTd0osRUFBRTdDLFVBQVFoRCxLQUFLNEosb0JBQWtCO2dCQUFHLElBQUk3TixJQUFFOEIsRUFBRStGLE1BQU00QixFQUFFdkM7b0JBQU02RixlQUFjdE07O2dCQUFJcUIsRUFBRW1DLEtBQUttRCxVQUFVMUYsUUFBUTFCLElBQUdpRSxLQUFLeU0sWUFBVTFRLEVBQUV3SCx5QkFBdUJ2RCxLQUFLeU0sWUFBVTtnQkFBRXpNLEtBQUs4TSxtQkFBa0I5TSxLQUFLK00saUJBQWdCbFAsRUFBRTBDLFNBQVN5TSxNQUFNL1EsU0FBUzRKLEVBQUVzRztnQkFBTW5NLEtBQUtpTixtQkFBa0JqTixLQUFLa04sbUJBQWtCclAsRUFBRW1DLEtBQUttRCxVQUFVNUcsR0FBR2lKLEVBQUVzRyxlQUFjMUYsRUFBRWlHLGNBQWEsU0FBU3hPO29CQUFHLE9BQU9pQixFQUFFeEQsS0FBS3VDO29CQUFLQSxFQUFFbUMsS0FBS3VNLFNBQVNoUSxHQUFHaUosRUFBRXlHLG1CQUFrQjtvQkFBV3BPLEVBQUVpQixFQUFFcUUsVUFBVXhDLElBQUk2RSxFQUFFd0csaUJBQWdCLFNBQVN4UDt3QkFBR3FCLEVBQUVyQixFQUFFVSxRQUFRNkMsR0FBR2pCLEVBQUVxRSxjQUFZckUsRUFBRTZOLHdCQUFzQjs7b0JBQU8zTSxLQUFLbU4sY0FBYztvQkFBVyxPQUFPck8sRUFBRXNPLGFBQWE1UTs7ZUFBT2lFLEVBQUVyQyxVQUFVOUMsT0FBSyxTQUFTa0I7Z0JBQUcsSUFBSXNDLElBQUVrQjtnQkFBSyxJQUFHeEQsS0FBR0EsRUFBRWdCLGtCQUFpQndDLEtBQUs0SixrQkFBaUIsTUFBTSxJQUFJaE0sTUFBTTtnQkFBMEIsSUFBSTdCLElBQUVxRCxFQUFFOEIsMkJBQXlCckQsRUFBRW1DLEtBQUttRCxVQUFVOUcsU0FBU3dKLEVBQUU3QztnQkFBTWpILE1BQUlpRSxLQUFLNEosb0JBQWtCO2dCQUFHLElBQUkzSyxJQUFFcEIsRUFBRStGLE1BQU00QixFQUFFNEQ7Z0JBQU12TCxFQUFFbUMsS0FBS21ELFVBQVUxRixRQUFRd0IsSUFBR2UsS0FBS3lNLGFBQVd4TixFQUFFc0UseUJBQXVCdkQsS0FBS3lNLFlBQVU7Z0JBQUV6TSxLQUFLaU4sbUJBQWtCak4sS0FBS2tOLG1CQUFrQnJQLEVBQUUwQyxVQUFVNkgsSUFBSTVDLEVBQUVvRyxVQUFTL04sRUFBRW1DLEtBQUttRCxVQUFVdkgsWUFBWWlLLEVBQUU1QztnQkFBTXBGLEVBQUVtQyxLQUFLbUQsVUFBVWlGLElBQUk1QyxFQUFFc0csZ0JBQWVqTyxFQUFFbUMsS0FBS3VNLFNBQVNuRSxJQUFJNUMsRUFBRXlHO2dCQUFtQmxRLElBQUU4QixFQUFFbUMsS0FBS21ELFVBQVV4QyxJQUFJdkIsRUFBRXlCLGdCQUFlLFNBQVNoRDtvQkFBRyxPQUFPaUIsRUFBRXVPLFdBQVd4UDttQkFBS29ELHFCQUFxQnVCLEtBQUd4QyxLQUFLcU47ZUFBZTVNLEVBQUVyQyxVQUFVcUYsVUFBUTtnQkFBVzVGLEVBQUU2RixXQUFXMUQsS0FBS21ELFVBQVN4RCxJQUFHOUIsRUFBRXdDLFFBQU9FLFVBQVNQLEtBQUttRCxVQUFTbkQsS0FBS3dNLFdBQVdwRSxJQUFJL0c7Z0JBQUdyQixLQUFLbUgsVUFBUSxNQUFLbkgsS0FBS21ELFdBQVMsTUFBS25ELEtBQUt1TSxVQUFRLE1BQUt2TSxLQUFLd00sWUFBVTtnQkFBS3hNLEtBQUt5TSxXQUFTLE1BQUt6TSxLQUFLME0scUJBQW1CLE1BQUsxTSxLQUFLMk0sdUJBQXFCO2dCQUFLM00sS0FBSzRNLHVCQUFxQixNQUFLNU0sS0FBSzZNLGtCQUFnQjtlQUFNcE0sRUFBRXJDLFVBQVVnSixhQUFXLFNBQVN0STtnQkFBRyxPQUFPQSxJQUFFakIsRUFBRXdLLFdBQVVuRixHQUFFcEUsSUFBR00sRUFBRWdELGdCQUFnQjVGLEdBQUVzQyxHQUFFeUcsSUFBR3pHO2VBQUcyQixFQUFFckMsVUFBVWdQLGVBQWEsU0FBUzVRO2dCQUFHLElBQUlzQyxJQUFFa0IsTUFBS2pFLElBQUVxRCxFQUFFOEIsMkJBQXlCckQsRUFBRW1DLEtBQUttRCxVQUFVOUcsU0FBU3dKLEVBQUU3QztnQkFBTWhELEtBQUttRCxTQUFTbUksY0FBWXRMLEtBQUttRCxTQUFTbUksV0FBVzdMLGFBQVc2TixLQUFLQyxnQkFBY2hOLFNBQVN5TSxLQUFLUSxZQUFZeE4sS0FBS21EO2dCQUFVbkQsS0FBS21ELFNBQVN6QyxNQUFNK00sVUFBUSxTQUFRek4sS0FBS21ELFNBQVN1SyxnQkFBZ0I7Z0JBQWUxTixLQUFLbUQsU0FBU3dLLFlBQVUsR0FBRTVSLEtBQUdxRCxFQUFFNkMsT0FBT2pDLEtBQUttRCxXQUFVdEYsRUFBRW1DLEtBQUttRCxVQUFVbEgsU0FBUzRKLEVBQUU1QztnQkFBTWpELEtBQUttSCxRQUFRcEMsU0FBTy9FLEtBQUs0TjtnQkFBZ0IsSUFBSTNPLElBQUVwQixFQUFFK0YsTUFBTTRCLEVBQUUyRDtvQkFBT0wsZUFBY3RNO29CQUFJd0UsSUFBRSxTQUFGQTtvQkFBYWxDLEVBQUVxSSxRQUFRcEMsU0FBT2pHLEVBQUVxRSxTQUFTNEIsU0FBUWpHLEVBQUU4SyxvQkFBa0IsR0FBRS9MLEVBQUVpQixFQUFFcUUsVUFBVTFGLFFBQVF3Qjs7Z0JBQUlsRCxJQUFFOEIsRUFBRW1DLEtBQUt1TSxTQUFTNUwsSUFBSXZCLEVBQUV5QixnQkFBZUcsR0FBR0MscUJBQXFCdUIsS0FBR3hCO2VBQUtQLEVBQUVyQyxVQUFVd1AsZ0JBQWM7Z0JBQVcsSUFBSXBSLElBQUV3RDtnQkFBS25DLEVBQUUwQyxVQUFVNkgsSUFBSTVDLEVBQUVvRyxTQUFTclAsR0FBR2lKLEVBQUVvRyxTQUFRLFNBQVM5TTtvQkFBR3lCLGFBQVd6QixFQUFFNUIsVUFBUVYsRUFBRTJHLGFBQVdyRSxFQUFFNUIsVUFBUVcsRUFBRXJCLEVBQUUyRyxVQUFVMEssSUFBSS9PLEVBQUU1QixRQUFRN0IsVUFBUW1CLEVBQUUyRyxTQUFTNEI7O2VBQVd0RSxFQUFFckMsVUFBVTZPLGtCQUFnQjtnQkFBVyxJQUFJelEsSUFBRXdEO2dCQUFLQSxLQUFLeU0sWUFBVXpNLEtBQUttSCxRQUFRaEMsV0FBU3RILEVBQUVtQyxLQUFLbUQsVUFBVTVHLEdBQUdpSixFQUFFdUcsaUJBQWdCLFNBQVNsTztvQkFBR0EsRUFBRTRLLFVBQVEzRixLQUFHdEcsRUFBRWxCO3FCQUFTMEUsS0FBS3lNLFlBQVU1TyxFQUFFbUMsS0FBS21ELFVBQVVpRixJQUFJNUMsRUFBRXVHO2VBQWtCdEwsRUFBRXJDLFVBQVU4TyxrQkFBZ0I7Z0JBQVcsSUFBSTFRLElBQUV3RDtnQkFBS0EsS0FBS3lNLFdBQVM1TyxFQUFFd0MsUUFBUTlELEdBQUdpSixFQUFFcUcsUUFBTyxTQUFTaE87b0JBQUcsT0FBT3JCLEVBQUVzUixjQUFjalE7cUJBQUtBLEVBQUV3QyxRQUFRK0gsSUFBSTVDLEVBQUVxRztlQUFTcEwsRUFBRXJDLFVBQVVpUCxhQUFXO2dCQUFXLElBQUk3USxJQUFFd0Q7Z0JBQUtBLEtBQUttRCxTQUFTekMsTUFBTStNLFVBQVEsUUFBT3pOLEtBQUttRCxTQUFTNkIsYUFBYSxlQUFjO2dCQUFRaEYsS0FBSzRKLG9CQUFrQixHQUFFNUosS0FBS21OLGNBQWM7b0JBQVd0UCxFQUFFMEMsU0FBU3lNLE1BQU1wUixZQUFZaUssRUFBRXNHLE9BQU0zUCxFQUFFdVIscUJBQW9CdlIsRUFBRXdSO29CQUFrQm5RLEVBQUVyQixFQUFFMkcsVUFBVTFGLFFBQVErSCxFQUFFNkQ7O2VBQVc1SSxFQUFFckMsVUFBVTZQLGtCQUFnQjtnQkFBV2pPLEtBQUt3TSxjQUFZM08sRUFBRW1DLEtBQUt3TSxXQUFXekksVUFBUy9ELEtBQUt3TSxZQUFVO2VBQU8vTCxFQUFFckMsVUFBVStPLGdCQUFjLFNBQVMzUTtnQkFBRyxJQUFJc0MsSUFBRWtCLE1BQUtqRSxJQUFFOEIsRUFBRW1DLEtBQUttRCxVQUFVOUcsU0FBU3dKLEVBQUU3QyxRQUFNNkMsRUFBRTdDLE9BQUs7Z0JBQUcsSUFBR2hELEtBQUt5TSxZQUFVek0sS0FBS21ILFFBQVF3RSxVQUFTO29CQUFDLElBQUkxTSxJQUFFRyxFQUFFOEIsMkJBQXlCbkY7b0JBQUUsSUFBR2lFLEtBQUt3TSxZQUFVak0sU0FBU0MsY0FBYyxRQUFPUixLQUFLd00sVUFBVXBCLFlBQVV2RixFQUFFNkU7b0JBQVMzTyxLQUFHOEIsRUFBRW1DLEtBQUt3TSxXQUFXdlEsU0FBU0YsSUFBRzhCLEVBQUVtQyxLQUFLd00sV0FBVzBCLFNBQVMzTixTQUFTeU0sT0FBTW5QLEVBQUVtQyxLQUFLbUQsVUFBVTVHLEdBQUdpSixFQUFFc0csZUFBYyxTQUFTak87d0JBQUcsT0FBT2lCLEVBQUU2Tiw2QkFBMEI3TixFQUFFNk4sd0JBQXNCLFdBQVE5TyxFQUFFWCxXQUFTVyxFQUFFc1Esa0JBQWdCLGFBQVdyUCxFQUFFcUksUUFBUXdFLFdBQVM3TSxFQUFFcUUsU0FBUzRCLFVBQVFqRyxFQUFFeEQ7d0JBQVcyRCxLQUFHRyxFQUFFNkMsT0FBT2pDLEtBQUt3TSxZQUFXM08sRUFBRW1DLEtBQUt3TSxXQUFXdlEsU0FBUzRKLEVBQUU1QyxRQUFPekcsR0FBRTtvQkFBTyxLQUFJeUMsR0FBRSxZQUFZekM7b0JBQUlxQixFQUFFbUMsS0FBS3dNLFdBQVc3TCxJQUFJdkIsRUFBRXlCLGdCQUFlckUsR0FBR3lFLHFCQUFxQnlCO3VCQUFRLEtBQUkxQyxLQUFLeU0sWUFBVXpNLEtBQUt3TSxXQUFVO29CQUFDM08sRUFBRW1DLEtBQUt3TSxXQUFXNVEsWUFBWWlLLEVBQUU1QztvQkFBTSxJQUFJakMsSUFBRSxTQUFGQTt3QkFBYWxDLEVBQUVtUCxtQkFBa0J6UixLQUFHQTs7b0JBQUs0QyxFQUFFOEIsMkJBQXlCckQsRUFBRW1DLEtBQUttRCxVQUFVOUcsU0FBU3dKLEVBQUU3QyxRQUFNbkYsRUFBRW1DLEtBQUt3TSxXQUFXN0wsSUFBSXZCLEVBQUV5QixnQkFBZUcsR0FBR0MscUJBQXFCeUIsS0FBRzFCO3VCQUFTeEUsS0FBR0E7ZUFBS2lFLEVBQUVyQyxVQUFVMFAsZ0JBQWM7Z0JBQVc5TixLQUFLb087ZUFBaUIzTixFQUFFckMsVUFBVWdRLGdCQUFjO2dCQUFXLElBQUl2USxJQUFFbUMsS0FBS21ELFNBQVNrTCxlQUFhOU4sU0FBU2dJLGdCQUFnQitGO2lCQUFjdE8sS0FBSzBNLHNCQUFvQjdPLE1BQUltQyxLQUFLbUQsU0FBU3pDLE1BQU02TixjQUFZdk8sS0FBSzZNLGtCQUFnQjtnQkFBTTdNLEtBQUswTSx1QkFBcUI3TyxNQUFJbUMsS0FBS21ELFNBQVN6QyxNQUFNOE4sZUFBYXhPLEtBQUs2TSxrQkFBZ0I7ZUFBT3BNLEVBQUVyQyxVQUFVMlAsb0JBQWtCO2dCQUFXL04sS0FBS21ELFNBQVN6QyxNQUFNNk4sY0FBWSxJQUFHdk8sS0FBS21ELFNBQVN6QyxNQUFNOE4sZUFBYTtlQUFJL04sRUFBRXJDLFVBQVUwTyxrQkFBZ0I7Z0JBQVc5TSxLQUFLME0scUJBQW1Cbk0sU0FBU3lNLEtBQUt5QixjQUFZcE8sT0FBT3FPLFlBQVcxTyxLQUFLNk0sa0JBQWdCN00sS0FBSzJPO2VBQXNCbE8sRUFBRXJDLFVBQVUyTyxnQkFBYztnQkFBVyxJQUFJdlEsSUFBRW9TLFNBQVMvUSxFQUFFdUksRUFBRWtHLGVBQWVyUCxJQUFJLG9CQUFrQixHQUFFO2dCQUFJK0MsS0FBSzRNLHVCQUFxQnJNLFNBQVN5TSxLQUFLdE0sTUFBTThOLGdCQUFjLElBQUd4TyxLQUFLME0sdUJBQXFCbk0sU0FBU3lNLEtBQUt0TSxNQUFNOE4sZUFBYWhTLElBQUV3RCxLQUFLNk0sa0JBQWdCO2VBQU9wTSxFQUFFckMsVUFBVTRQLGtCQUFnQjtnQkFBV3pOLFNBQVN5TSxLQUFLdE0sTUFBTThOLGVBQWF4TyxLQUFLNE07ZUFBc0JuTSxFQUFFckMsVUFBVXVRLHFCQUFtQjtnQkFBVyxJQUFJOVEsSUFBRTBDLFNBQVNDLGNBQWM7Z0JBQU8zQyxFQUFFdU4sWUFBVXZGLEVBQUVxRyxvQkFBbUIzTCxTQUFTeU0sS0FBS1EsWUFBWTNQO2dCQUFHLElBQUlyQixJQUFFcUIsRUFBRWdSLGNBQVloUixFQUFFNFE7Z0JBQVksT0FBT2xPLFNBQVN5TSxLQUFLekIsWUFBWTFOLElBQUdyQjtlQUFHaUUsRUFBRXVELG1CQUFpQixTQUFTeEgsR0FBRXNDO2dCQUFHLE9BQU9rQixLQUFLaEUsS0FBSztvQkFBVyxJQUFJaUQsSUFBRXBCLEVBQUVtQyxNQUFNaUUsS0FBS3RFLElBQUdQLElBQUV2QixFQUFFd0ssV0FBVTVILEVBQUVxTyxTQUFRalIsRUFBRW1DLE1BQU1pRSxRQUFPLGNBQVksc0JBQW9CekgsSUFBRSxjQUFZVCxFQUFFUyxPQUFLQTtvQkFBRyxJQUFHeUMsTUFBSUEsSUFBRSxJQUFJd0IsRUFBRVQsTUFBS1osSUFBR3ZCLEVBQUVtQyxNQUFNaUUsS0FBS3RFLEdBQUVWLEtBQUksbUJBQWlCekMsR0FBRTt3QkFBQyxTQUFRLE1BQUl5QyxFQUFFekMsSUFBRyxNQUFNLElBQUlvQixNQUFNLHNCQUFvQnBCLElBQUU7d0JBQUt5QyxFQUFFekMsR0FBR3NDOzJCQUFRTSxFQUFFN0QsUUFBTTBELEVBQUUxRCxLQUFLdUQ7O2VBQU1HLEVBQUV3QixHQUFFO2dCQUFPdEIsS0FBSTtnQkFBVWdGLEtBQUksU0FBQUE7b0JBQVcsT0FBT25EOzs7Z0JBQUs3QixLQUFJO2dCQUFVZ0YsS0FBSSxTQUFBQTtvQkFBVyxPQUFPakI7O2tCQUFNekM7O1FBQUssT0FBTzVDLEVBQUUwQyxVQUFVaEUsR0FBR2lKLEVBQUUzQyxnQkFBZXVELEVBQUUxQixhQUFZLFNBQVNsSTtZQUFHLElBQUlzQyxJQUFFa0IsTUFBS2pFLFNBQU8sR0FBRWtELElBQUVHLEVBQUUwQyx1QkFBdUI5QjtZQUFNZixNQUFJbEQsSUFBRThCLEVBQUVvQixHQUFHO1lBQUksSUFBSStCLElBQUVuRCxFQUFFOUIsR0FBR2tJLEtBQUt0RSxLQUFHLFdBQVM5QixFQUFFd0ssV0FBVXhLLEVBQUU5QixHQUFHa0ksUUFBT3BHLEVBQUVtQyxNQUFNaUU7WUFBUSxRQUFNakUsS0FBS3dJLFdBQVMsV0FBU3hJLEtBQUt3SSxXQUFTaE0sRUFBRWdCO1lBQWlCLElBQUk2RCxJQUFFeEQsRUFBRTlCLEdBQUc0RSxJQUFJNkUsRUFBRXZDLE1BQUssU0FBU3pHO2dCQUFHQSxFQUFFK0csd0JBQXNCbEMsRUFBRVYsSUFBSTZFLEVBQUU2RCxRQUFPO29CQUFXeEwsRUFBRWlCLEdBQUdpQixHQUFHLGVBQWFqQixFQUFFaUc7OztZQUFZd0IsRUFBRXZDLGlCQUFpQjFFLEtBQUt6QixFQUFFOUIsSUFBR2lGLEdBQUVoQjtZQUFRbkMsRUFBRUMsR0FBR3RCLEtBQUcrSixFQUFFdkMsa0JBQWlCbkcsRUFBRUMsR0FBR3RCLEdBQUc0SCxjQUFZbUMsR0FBRTFJLEVBQUVDLEdBQUd0QixHQUFHNkgsYUFBVztZQUFXLE9BQU94RyxFQUFFQyxHQUFHdEIsS0FBR29FLEdBQUUyRixFQUFFdkM7V0FBa0J1QztNQUFHNUksU0FBUSxTQUFTRTtRQUFHLElBQUlyQixJQUFFLGFBQVl3RSxJQUFFLGlCQUFnQnJCLElBQUUsZ0JBQWUwQixJQUFFLE1BQUkxQixHQUFFYyxJQUFFLGFBQVlHLElBQUUvQyxFQUFFQyxHQUFHdEIsSUFBR2dHO1lBQUd1TSxRQUFPO1lBQUdDLFFBQU87WUFBTzlSLFFBQU87V0FBSXdGO1lBQUdxTSxRQUFPO1lBQVNDLFFBQU87WUFBUzlSLFFBQU87V0FBb0I0RjtZQUFHbU0sVUFBUyxhQUFXNU47WUFBRTZOLFFBQU8sV0FBUzdOO1lBQUU4RSxlQUFjLFNBQU85RSxJQUFFWjtXQUFHeUM7WUFBR2lNLGVBQWM7WUFBZ0JDLGVBQWM7WUFBZ0JDLFVBQVM7WUFBV0MsS0FBSTtZQUFNaEwsUUFBTztXQUFVaUI7WUFBR2dLLFVBQVM7WUFBc0JqTCxRQUFPO1lBQVVrTCxXQUFVO1lBQWFDLElBQUc7WUFBS0MsYUFBWTtZQUFjQyxXQUFVO1lBQVlDLFVBQVM7WUFBWUMsZ0JBQWU7WUFBaUJDLGlCQUFnQjtXQUFvQnRLO1lBQUd1SyxRQUFPO1lBQVNDLFVBQVM7V0FBWW5LLElBQUU7WUFBVyxTQUFTcEYsRUFBRWpFLEdBQUVUO2dCQUFHLElBQUlrRCxJQUFFZTtnQkFBS2xCLEVBQUVrQixNQUFLUyxJQUFHVCxLQUFLbUQsV0FBUzNHLEdBQUV3RCxLQUFLaVEsaUJBQWUsV0FBU3pULEVBQUVnTSxVQUFRbkksU0FBTzdEO2dCQUFFd0QsS0FBS21ILFVBQVFuSCxLQUFLb0gsV0FBV3JMLElBQUdpRSxLQUFLa1EsWUFBVWxRLEtBQUttSCxRQUFRakssU0FBTyxNQUFJcUksRUFBRW9LLFlBQVUsT0FBSzNQLEtBQUttSCxRQUFRakssU0FBTyxNQUFJcUksRUFBRXNLO2dCQUFnQjdQLEtBQUttUSxlQUFZblEsS0FBS29RLGVBQVlwUSxLQUFLcVEsZ0JBQWMsTUFBS3JRLEtBQUtzUSxnQkFBYztnQkFBRXpTLEVBQUVtQyxLQUFLaVEsZ0JBQWdCMVQsR0FBR3VHLEVBQUVvTSxRQUFPLFNBQVNyUjtvQkFBRyxPQUFPb0IsRUFBRXNSLFNBQVMxUztvQkFBS21DLEtBQUt3USxXQUFVeFEsS0FBS3VROztZQUFXLE9BQU85UCxFQUFFckMsVUFBVW9TLFVBQVE7Z0JBQVcsSUFBSWhVLElBQUV3RCxNQUFLbEIsSUFBRWtCLEtBQUtpUSxtQkFBaUJqUSxLQUFLaVEsZUFBZTVQLFNBQU9tRixFQUFFd0ssV0FBU3hLLEVBQUV1SyxRQUFPaFUsSUFBRSxXQUFTaUUsS0FBS21ILFFBQVE2SCxTQUFPbFEsSUFBRWtCLEtBQUttSCxRQUFRNkgsUUFBTy9QLElBQUVsRCxNQUFJeUosRUFBRXdLLFdBQVNoUSxLQUFLeVEsa0JBQWdCO2dCQUFFelEsS0FBS21RLGVBQVluUSxLQUFLb1EsZUFBWXBRLEtBQUtzUSxnQkFBY3RRLEtBQUswUTtnQkFBbUIsSUFBSTFQLElBQUVuRCxFQUFFNkssVUFBVTdLLEVBQUVtQyxLQUFLa1E7Z0JBQVlsUCxFQUFFMlAsSUFBSSxTQUFTblU7b0JBQUcsSUFBSXNDLFNBQU8sR0FBRWtDLElBQUU1QixFQUFFMEMsdUJBQXVCdEY7b0JBQUcsT0FBT3dFLE1BQUlsQyxJQUFFakIsRUFBRW1ELEdBQUcsS0FBSWxDLE1BQUlBLEVBQUUrUCxlQUFhL1AsRUFBRW9ELGtCQUFlckUsRUFBRWlCLEdBQUcvQyxLQUFLNlUsTUFBSTNSLEdBQUUrQixNQUFHO21CQUFPNlAsT0FBTyxTQUFTaFQ7b0JBQUcsT0FBT0E7bUJBQUlpVCxLQUFLLFNBQVNqVCxHQUFFckI7b0JBQUcsT0FBT3FCLEVBQUUsS0FBR3JCLEVBQUU7bUJBQUt1VSxRQUFRLFNBQVNsVDtvQkFBR3JCLEVBQUUyVCxTQUFTYSxLQUFLblQsRUFBRSxLQUFJckIsRUFBRTRULFNBQVNZLEtBQUtuVCxFQUFFOztlQUFPNEMsRUFBRXJDLFVBQVVxRixVQUFRO2dCQUFXNUYsRUFBRTZGLFdBQVcxRCxLQUFLbUQsVUFBU3hELElBQUc5QixFQUFFbUMsS0FBS2lRLGdCQUFnQjdILElBQUkvRyxJQUFHckIsS0FBS21ELFdBQVM7Z0JBQUtuRCxLQUFLaVEsaUJBQWUsTUFBS2pRLEtBQUttSCxVQUFRLE1BQUtuSCxLQUFLa1EsWUFBVSxNQUFLbFEsS0FBS21RLFdBQVM7Z0JBQUtuUSxLQUFLb1EsV0FBUyxNQUFLcFEsS0FBS3FRLGdCQUFjLE1BQUtyUSxLQUFLc1EsZ0JBQWM7ZUFBTTdQLEVBQUVyQyxVQUFVZ0osYUFBVyxTQUFTdEk7Z0JBQUcsSUFBR0EsSUFBRWpCLEVBQUV3SyxXQUFVN0YsR0FBRTFELElBQUcsbUJBQWlCQSxFQUFFNUIsUUFBTztvQkFBQyxJQUFJbkIsSUFBRThCLEVBQUVpQixFQUFFNUIsUUFBUWlOLEtBQUs7b0JBQU1wTyxNQUFJQSxJQUFFcUQsRUFBRXNDLE9BQU9sRixJQUFHcUIsRUFBRWlCLEVBQUU1QixRQUFRaU4sS0FBSyxNQUFLcE8sS0FBSStDLEVBQUU1QixTQUFPLE1BQUluQjs7Z0JBQUUsT0FBT3FELEVBQUVnRCxnQkFBZ0I1RixHQUFFc0MsR0FBRTRELElBQUc1RDtlQUFHMkIsRUFBRXJDLFVBQVVxUyxnQkFBYztnQkFBVyxPQUFPelEsS0FBS2lRLG1CQUFpQjVQLFNBQU9MLEtBQUtpUSxlQUFlZ0IsY0FBWWpSLEtBQUtpUSxlQUFldEM7ZUFBV2xOLEVBQUVyQyxVQUFVc1MsbUJBQWlCO2dCQUFXLE9BQU8xUSxLQUFLaVEsZUFBZTVCLGdCQUFjMU0sS0FBS3VQLElBQUkzUSxTQUFTeU0sS0FBS3FCLGNBQWE5TixTQUFTZ0ksZ0JBQWdCOEY7ZUFBZTVOLEVBQUVyQyxVQUFVK1MsbUJBQWlCO2dCQUFXLE9BQU9uUixLQUFLaVEsbUJBQWlCNVAsU0FBT0EsT0FBTytRLGNBQVlwUixLQUFLaVEsZUFBZS9OO2VBQWN6QixFQUFFckMsVUFBVW1TLFdBQVM7Z0JBQVcsSUFBSTFTLElBQUVtQyxLQUFLeVEsa0JBQWdCelEsS0FBS21ILFFBQVE0SCxRQUFPdlMsSUFBRXdELEtBQUswUSxvQkFBbUI1UixJQUFFa0IsS0FBS21ILFFBQVE0SCxTQUFPdlMsSUFBRXdELEtBQUttUjtnQkFBbUIsSUFBR25SLEtBQUtzUSxrQkFBZ0I5VCxLQUFHd0QsS0FBS3dRLFdBQVUzUyxLQUFHaUIsR0FBRTtvQkFBQyxJQUFJL0MsSUFBRWlFLEtBQUtvUSxTQUFTcFEsS0FBS29RLFNBQVMvVSxTQUFPO29CQUFHLGFBQVkyRSxLQUFLcVEsa0JBQWdCdFUsS0FBR2lFLEtBQUtxUixVQUFVdFY7O2dCQUFJLElBQUdpRSxLQUFLcVEsaUJBQWV4UyxJQUFFbUMsS0FBS21RLFNBQVMsTUFBSW5RLEtBQUttUSxTQUFTLEtBQUcsR0FBRSxPQUFPblEsS0FBS3FRLGdCQUFjO3FCQUFVclEsS0FBS3NSO2dCQUFTLEtBQUksSUFBSXJTLElBQUVlLEtBQUttUSxTQUFTOVUsUUFBTzRELE9BQUs7b0JBQUMsSUFBSUcsSUFBRVksS0FBS3FRLGtCQUFnQnJRLEtBQUtvUSxTQUFTblIsTUFBSXBCLEtBQUdtQyxLQUFLbVEsU0FBU2xSLFlBQVUsTUFBSWUsS0FBS21RLFNBQVNsUixJQUFFLE1BQUlwQixJQUFFbUMsS0FBS21RLFNBQVNsUixJQUFFO29CQUFJRyxLQUFHWSxLQUFLcVIsVUFBVXJSLEtBQUtvUSxTQUFTblI7O2VBQU13QixFQUFFckMsVUFBVWlULFlBQVUsU0FBUzdVO2dCQUFHd0QsS0FBS3FRLGdCQUFjN1QsR0FBRXdELEtBQUtzUjtnQkFBUyxJQUFJeFMsSUFBRWtCLEtBQUtrUSxVQUFVbFMsTUFBTTtnQkFBS2MsSUFBRUEsRUFBRTZSLElBQUksU0FBUzlTO29CQUFHLE9BQU9BLElBQUUsbUJBQWlCckIsSUFBRSxTQUFPcUIsSUFBRSxZQUFVckIsSUFBRTs7Z0JBQVEsSUFBSVQsSUFBRThCLEVBQUVpQixFQUFFeVMsS0FBSztnQkFBTXhWLEVBQUVNLFNBQVM2RyxFQUFFaU0sa0JBQWdCcFQsRUFBRTRILFFBQVE0QixFQUFFcUssVUFBVTlULEtBQUt5SixFQUFFdUssaUJBQWlCN1QsU0FBU2lILEVBQUVvQjtnQkFBUXZJLEVBQUVFLFNBQVNpSCxFQUFFb0IsV0FBU3ZJLEVBQUV5VixRQUFRak0sRUFBRWtLLElBQUkzVCxLQUFLLE9BQUt5SixFQUFFb0ssV0FBVzFULFNBQVNpSCxFQUFFb0I7Z0JBQVF6RyxFQUFFbUMsS0FBS2lRLGdCQUFnQnhTLFFBQVFxRixFQUFFbU07b0JBQVVuRyxlQUFjdE07O2VBQUtpRSxFQUFFckMsVUFBVWtULFNBQU87Z0JBQVd6VCxFQUFFbUMsS0FBS2tRLFdBQVdXLE9BQU90TCxFQUFFakIsUUFBUTFJLFlBQVlzSCxFQUFFb0I7ZUFBUzdELEVBQUV1RCxtQkFBaUIsU0FBU3hIO2dCQUFHLE9BQU93RCxLQUFLaEUsS0FBSztvQkFBVyxJQUFJOEMsSUFBRWpCLEVBQUVtQyxNQUFNaUUsS0FBS3RFLElBQUdWLElBQUUsY0FBWSxzQkFBb0J6QyxJQUFFLGNBQVlULEVBQUVTLE9BQUtBO29CQUN6MCtCLElBQUdzQyxNQUFJQSxJQUFFLElBQUkyQixFQUFFVCxNQUFLZixJQUFHcEIsRUFBRW1DLE1BQU1pRSxLQUFLdEUsR0FBRWIsS0FBSSxtQkFBaUJ0QyxHQUFFO3dCQUFDLFNBQVEsTUFBSXNDLEVBQUV0QyxJQUFHLE1BQU0sSUFBSW9CLE1BQU0sc0JBQW9CcEIsSUFBRTt3QkFBS3NDLEVBQUV0Qzs7O2VBQVN5QyxFQUFFd0IsR0FBRTtnQkFBT3RCLEtBQUk7Z0JBQVVnRixLQUFJLFNBQUFBO29CQUFXLE9BQU9uRDs7O2dCQUFLN0IsS0FBSTtnQkFBVWdGLEtBQUksU0FBQUE7b0JBQVcsT0FBTzNCOztrQkFBTS9COztRQUFLLE9BQU81QyxFQUFFd0MsUUFBUTlELEdBQUd1RyxFQUFFcUQsZUFBYztZQUFXLEtBQUksSUFBSTNKLElBQUVxQixFQUFFNkssVUFBVTdLLEVBQUUwSCxFQUFFZ0ssWUFBV3pRLElBQUV0QyxFQUFFbkIsUUFBT3lELE9BQUs7Z0JBQUMsSUFBSS9DLElBQUU4QixFQUFFckIsRUFBRXNDO2dCQUFJK0csRUFBRTdCLGlCQUFpQjFFLEtBQUt2RCxHQUFFQSxFQUFFa0k7O1lBQVdwRyxFQUFFQyxHQUFHdEIsS0FBR3FKLEVBQUU3QixrQkFBaUJuRyxFQUFFQyxHQUFHdEIsR0FBRzRILGNBQVl5QixHQUFFaEksRUFBRUMsR0FBR3RCLEdBQUc2SCxhQUFXO1lBQVcsT0FBT3hHLEVBQUVDLEdBQUd0QixLQUFHb0UsR0FBRWlGLEVBQUU3QjtXQUFrQjZCO01BQUdsSSxTQUFRLFNBQVNFO1FBQUcsSUFBSXJCLElBQUUsT0FBTVQsSUFBRSxpQkFBZ0JpRixJQUFFLFVBQVNyQixJQUFFLE1BQUlxQixHQUFFSyxJQUFFLGFBQVlaLElBQUU1QyxFQUFFQyxHQUFHdEIsSUFBR29FLElBQUUsS0FBSTRCO1lBQUc0RyxNQUFLLFNBQU96SjtZQUFFMEosUUFBTyxXQUFTMUo7WUFBRXNELE1BQUssU0FBT3REO1lBQUV3SixPQUFNLFVBQVF4SjtZQUFFa0QsZ0JBQWUsVUFBUWxELElBQUUwQjtXQUFHcUI7WUFBRzBNLGVBQWM7WUFBZ0I5SyxRQUFPO1lBQVNxRyxVQUFTO1lBQVczSCxNQUFLO1lBQU9DLE1BQUs7V0FBUUg7WUFBRzJPLEdBQUU7WUFBSWhDLElBQUc7WUFBS0csVUFBUztZQUFZOEIsTUFBSztZQUEwRUMsWUFBVztZQUE2QnJOLFFBQU87WUFBVXNOLGNBQWE7WUFBbUNsTixhQUFZO1lBQTRDb0wsaUJBQWdCO1lBQW1CK0IsdUJBQXNCO1dBQTRCM08sSUFBRTtZQUFXLFNBQVMxRyxFQUFFcUI7Z0JBQUdpQixFQUFFa0IsTUFBS3hELElBQUd3RCxLQUFLbUQsV0FBU3RGOztZQUFFLE9BQU9yQixFQUFFNEIsVUFBVTdDLE9BQUs7Z0JBQVcsSUFBSWlCLElBQUV3RDtnQkFBSyxNQUFLQSxLQUFLbUQsU0FBU21JLGNBQVl0TCxLQUFLbUQsU0FBU21JLFdBQVc3TCxhQUFXNk4sS0FBS0MsZ0JBQWMxUCxFQUFFbUMsS0FBS21ELFVBQVU5RyxTQUFTcUcsRUFBRTRCLFdBQVN6RyxFQUFFbUMsS0FBS21ELFVBQVU5RyxTQUFTcUcsRUFBRWlJLFlBQVc7b0JBQUMsSUFBSTdMLFNBQU8sR0FBRS9DLFNBQU8sR0FBRWtELElBQUVwQixFQUFFbUMsS0FBS21ELFVBQVVRLFFBQVFiLEVBQUU0TyxNQUFNLElBQUcxUSxJQUFFNUIsRUFBRTBDLHVCQUF1QjlCLEtBQUttRDtvQkFBVWxFLE1BQUlsRCxJQUFFOEIsRUFBRTZLLFVBQVU3SyxFQUFFb0IsR0FBR25ELEtBQUtnSCxFQUFFd0IsVUFBU3ZJLElBQUVBLEVBQUVBLEVBQUVWLFNBQU87b0JBQUksSUFBSXNFLElBQUU5QixFQUFFK0YsTUFBTXBCLEVBQUU0Rzt3QkFBTU4sZUFBYzlJLEtBQUttRDt3QkFBVzlCLElBQUV4RCxFQUFFK0YsTUFBTXBCLEVBQUVTO3dCQUFNNkYsZUFBYy9NOztvQkFBSSxJQUFHQSxLQUFHOEIsRUFBRTlCLEdBQUcwQixRQUFRa0MsSUFBRzlCLEVBQUVtQyxLQUFLbUQsVUFBVTFGLFFBQVE0RCxLQUFJQSxFQUFFa0MseUJBQXVCNUQsRUFBRTRELHNCQUFxQjt3QkFBQ3ZDLE1BQUlsQyxJQUFFakIsRUFBRW1ELEdBQUcsS0FBSWhCLEtBQUtxUixVQUFVclIsS0FBS21ELFVBQVNsRTt3QkFBRyxJQUFJd0IsSUFBRSxTQUFGQTs0QkFBYSxJQUFJM0IsSUFBRWpCLEVBQUUrRixNQUFNcEIsRUFBRTZHO2dDQUFRUCxlQUFjdE0sRUFBRTJHO2dDQUFXbEUsSUFBRXBCLEVBQUUrRixNQUFNcEIsRUFBRTJHO2dDQUFPTCxlQUFjL007OzRCQUFJOEIsRUFBRTlCLEdBQUcwQixRQUFRcUIsSUFBR2pCLEVBQUVyQixFQUFFMkcsVUFBVTFGLFFBQVF3Qjs7d0JBQUlILElBQUVrQixLQUFLcVIsVUFBVXZTLEdBQUVBLEVBQUV3TSxZQUFXN0ssS0FBR0E7OztlQUFPakUsRUFBRTRCLFVBQVVxRixVQUFRO2dCQUFXNUYsRUFBRWpDLFlBQVlvRSxLQUFLbUQsVUFBU25DLElBQUdoQixLQUFLbUQsV0FBUztlQUFNM0csRUFBRTRCLFVBQVVpVCxZQUFVLFNBQVM3VSxHQUFFc0MsR0FBRS9DO2dCQUFHLElBQUlrRCxJQUFFZSxNQUFLZ0IsSUFBRW5ELEVBQUVpQixHQUFHaEQsS0FBS2dILEVBQUU4TyxjQUFjLElBQUdqUyxJQUFFNUQsS0FBR3FELEVBQUU4Qiw0QkFBMEJGLEtBQUduRCxFQUFFbUQsR0FBRzNFLFNBQVNxRyxFQUFFTSxTQUFPYixRQUFRdEUsRUFBRWlCLEdBQUdoRCxLQUFLZ0gsRUFBRTZPLFlBQVksTUFBS3RRLElBQUUsU0FBRkE7b0JBQWEsT0FBT3BDLEVBQUU2UyxvQkFBb0J0VixHQUFFd0UsR0FBRXJCLEdBQUU1RDs7Z0JBQUlpRixLQUFHckIsSUFBRTlCLEVBQUVtRCxHQUFHTCxJQUFJdkIsRUFBRXlCLGdCQUFlUSxHQUFHSixxQkFBcUJMLEtBQUdTLEtBQUlMLEtBQUduRCxFQUFFbUQsR0FBR3BGLFlBQVk4RyxFQUFFTztlQUFPekcsRUFBRTRCLFVBQVUwVCxzQkFBb0IsU0FBU3RWLEdBQUVzQyxHQUFFL0MsR0FBRWtEO2dCQUFHLElBQUdILEdBQUU7b0JBQUNqQixFQUFFaUIsR0FBR2xELFlBQVk4RyxFQUFFNEI7b0JBQVEsSUFBSXRELElBQUVuRCxFQUFFaUIsRUFBRXdNLFlBQVl4UCxLQUFLZ0gsRUFBRStPLHVCQUF1QjtvQkFBRzdRLEtBQUduRCxFQUFFbUQsR0FBR3BGLFlBQVk4RyxFQUFFNEIsU0FBUXhGLEVBQUVrRyxhQUFhLGtCQUFpQjs7Z0JBQUcsSUFBR25ILEVBQUVyQixHQUFHUCxTQUFTeUcsRUFBRTRCLFNBQVE5SCxFQUFFd0ksYUFBYSxrQkFBaUIsSUFBR2pKLEtBQUdxRCxFQUFFNkMsT0FBT3pGO2dCQUFHcUIsRUFBRXJCLEdBQUdQLFNBQVN5RyxFQUFFTyxTQUFPcEYsRUFBRXJCLEdBQUdaLFlBQVk4RyxFQUFFTSxPQUFNeEcsRUFBRThPLGNBQVl6TixFQUFFckIsRUFBRThPLFlBQVlqUCxTQUFTcUcsRUFBRTBNLGdCQUFlO29CQUFDLElBQUl6UCxJQUFFOUIsRUFBRXJCLEdBQUdtSCxRQUFRYixFQUFFOE0sVUFBVTtvQkFBR2pRLEtBQUc5QixFQUFFOEIsR0FBRzdELEtBQUtnSCxFQUFFZ04saUJBQWlCN1QsU0FBU3lHLEVBQUU0QixTQUFROUgsRUFBRXdJLGFBQWEsa0JBQWlCOztnQkFBRy9GLEtBQUdBO2VBQUt6QyxFQUFFd0gsbUJBQWlCLFNBQVNsRjtnQkFBRyxPQUFPa0IsS0FBS2hFLEtBQUs7b0JBQVcsSUFBSUQsSUFBRThCLEVBQUVtQyxPQUFNZixJQUFFbEQsRUFBRWtJLEtBQUtqRDtvQkFBRyxJQUFHL0IsTUFBSUEsSUFBRSxJQUFJekMsRUFBRXdELE9BQU1qRSxFQUFFa0ksS0FBS2pELEdBQUUvQixLQUFJLG1CQUFpQkgsR0FBRTt3QkFBQyxTQUFRLE1BQUlHLEVBQUVILElBQUcsTUFBTSxJQUFJbEIsTUFBTSxzQkFBb0JrQixJQUFFO3dCQUFLRyxFQUFFSDs7O2VBQVNHLEVBQUV6QyxHQUFFO2dCQUFPMkMsS0FBSTtnQkFBVWdGLEtBQUksU0FBQUE7b0JBQVcsT0FBT3BJOztrQkFBTVM7O1FBQUssT0FBT3FCLEVBQUUwQyxVQUFVaEUsR0FBR2lHLEVBQUVLLGdCQUFlQyxFQUFFNEIsYUFBWSxTQUFTbEk7WUFBR0EsRUFBRWdCLGtCQUFpQjBGLEVBQUVjLGlCQUFpQjFFLEtBQUt6QixFQUFFbUMsT0FBTTtZQUFVbkMsRUFBRUMsR0FBR3RCLEtBQUcwRyxFQUFFYyxrQkFBaUJuRyxFQUFFQyxHQUFHdEIsR0FBRzRILGNBQVlsQixHQUFFckYsRUFBRUMsR0FBR3RCLEdBQUc2SCxhQUFXO1lBQVcsT0FBT3hHLEVBQUVDLEdBQUd0QixLQUFHaUUsR0FBRXlDLEVBQUVjO1dBQWtCZDtNQUFHdkYsU0FBUSxTQUFTRTtRQUFHLElBQUcsc0JBQW9Ca1UsUUFBTyxNQUFNLElBQUluVSxNQUFNO1FBQXlELElBQUlwQixJQUFFLFdBQVV3RSxJQUFFLGlCQUFnQnJCLElBQUUsY0FBYTBCLElBQUUsTUFBSTFCLEdBQUVjLElBQUU1QyxFQUFFQyxHQUFHdEIsSUFBR29FLElBQUUsS0FBSTRCLElBQUUsYUFBWUU7WUFBR3NQLFlBQVc7WUFBRUMsVUFBUztZQUE4RXhVLFNBQVE7WUFBY3lVLE9BQU07WUFBR0MsT0FBTTtZQUFFQyxPQUFNO1lBQUVDLFdBQVU7WUFBRUMsV0FBVTtZQUFNdkQsUUFBTztZQUFNd0Q7WUFBZUMsWUFBVztXQUFHMVA7WUFBR2tQLFdBQVU7WUFBVUMsVUFBUztZQUFTQyxPQUFNO1lBQTRCelUsU0FBUTtZQUFTMFUsT0FBTTtZQUFrQkMsTUFBSztZQUFVQyxVQUFTO1lBQW1CQyxXQUFVO1lBQW9CdkQsUUFBTztZQUFTd0QsYUFBWTtZQUFRQyxXQUFVO1dBQTRCdFA7WUFBR3VQLEtBQUk7WUFBZ0I3TSxPQUFNO1lBQWM4TSxRQUFPO1lBQWEvTSxNQUFLO1dBQWdCSjtZQUFHdEMsTUFBSztZQUFPMFAsS0FBSTtXQUFPbk47WUFBRzRELE1BQUssU0FBTy9IO1lBQUVnSSxRQUFPLFdBQVNoSTtZQUFFNEIsTUFBSyxTQUFPNUI7WUFBRThILE9BQU0sVUFBUTlIO1lBQUV1UixVQUFTLGFBQVd2UjtZQUFFa0osT0FBTSxVQUFRbEo7WUFBRXVLLFNBQVEsWUFBVXZLO1lBQUV3UixVQUFTLGFBQVd4UjtZQUFFNEUsWUFBVyxlQUFhNUU7WUFBRTZFLFlBQVcsZUFBYTdFO1dBQUd3RTtZQUFHN0MsTUFBSztZQUFPQyxNQUFLO1dBQVFtRDtZQUFHME0sU0FBUTtZQUFXQyxlQUFjO1dBQWtCeE07WUFBRzlLLFVBQVM7WUFBRXVYLFVBQVM7V0FBR25NO1lBQUdvTSxPQUFNO1lBQVF6TyxPQUFNO1lBQVErRixPQUFNO1lBQVEySSxRQUFPO1dBQVVDLElBQUU7WUFBVyxTQUFTMVMsRUFBRTVDLEdBQUVyQjtnQkFBR3NDLEVBQUVrQixNQUFLUyxJQUFHVCxLQUFLb1QsY0FBWSxHQUFFcFQsS0FBS3FULFdBQVMsR0FBRXJULEtBQUtzVCxjQUFZLElBQUd0VCxLQUFLdVQ7Z0JBQWtCdlQsS0FBSzRKLG9CQUFrQixHQUFFNUosS0FBS3dULFVBQVEsTUFBS3hULEtBQUt2RSxVQUFRb0MsR0FBRW1DLEtBQUt5VCxTQUFPelQsS0FBS29ILFdBQVc1SztnQkFBR3dELEtBQUswVCxNQUFJLE1BQUsxVCxLQUFLMlQ7O1lBQWdCLE9BQU9sVCxFQUFFckMsVUFBVXdWLFNBQU87Z0JBQVc1VCxLQUFLb1QsY0FBWTtlQUFHM1MsRUFBRXJDLFVBQVV5VixVQUFRO2dCQUFXN1QsS0FBS29ULGNBQVk7ZUFBRzNTLEVBQUVyQyxVQUFVMFYsZ0JBQWM7Z0JBQVc5VCxLQUFLb1QsY0FBWXBULEtBQUtvVDtlQUFZM1MsRUFBRXJDLFVBQVV5RyxTQUFPLFNBQVNySTtnQkFBRyxJQUFHQSxHQUFFO29CQUFDLElBQUlzQyxJQUFFa0IsS0FBS3pCLFlBQVl3VixVQUFTaFksSUFBRThCLEVBQUVyQixFQUFFMlIsZUFBZWxLLEtBQUtuRjtvQkFBRy9DLE1BQUlBLElBQUUsSUFBSWlFLEtBQUt6QixZQUFZL0IsRUFBRTJSLGVBQWNuTyxLQUFLZ1UsdUJBQXNCblcsRUFBRXJCLEVBQUUyUixlQUFlbEssS0FBS25GLEdBQUUvQztvQkFBSUEsRUFBRXdYLGVBQWVVLFNBQU9sWSxFQUFFd1gsZUFBZVUsT0FBTWxZLEVBQUVtWSx5QkFBdUJuWSxFQUFFb1ksT0FBTyxNQUFLcFksS0FBR0EsRUFBRXFZLE9BQU8sTUFBS3JZO3VCQUFPO29CQUFDLElBQUc4QixFQUFFbUMsS0FBS3FVLGlCQUFpQmhZLFNBQVN3SixFQUFFNUMsT0FBTSxZQUFZakQsS0FBS29VLE9BQU8sTUFBS3BVO29CQUFNQSxLQUFLbVUsT0FBTyxNQUFLblU7O2VBQVFTLEVBQUVyQyxVQUFVcUYsVUFBUTtnQkFBVzZRLGFBQWF0VSxLQUFLcVQsV0FBVXJULEtBQUt1VSxpQkFBZ0IxVyxFQUFFNkYsV0FBVzFELEtBQUt2RSxTQUFRdUUsS0FBS3pCLFlBQVl3VjtnQkFBVWxXLEVBQUVtQyxLQUFLdkUsU0FBUzJNLElBQUlwSSxLQUFLekIsWUFBWWlXLFlBQVczVyxFQUFFbUMsS0FBS3ZFLFNBQVNrSSxRQUFRLFVBQVV5RSxJQUFJO2dCQUFpQnBJLEtBQUswVCxPQUFLN1YsRUFBRW1DLEtBQUswVCxLQUFLM1AsVUFBUy9ELEtBQUtvVCxhQUFXLE1BQUtwVCxLQUFLcVQsV0FBUztnQkFBS3JULEtBQUtzVCxjQUFZLE1BQUt0VCxLQUFLdVQsaUJBQWUsTUFBS3ZULEtBQUt3VCxVQUFRLE1BQUt4VCxLQUFLdkUsVUFBUTtnQkFBS3VFLEtBQUt5VCxTQUFPLE1BQUt6VCxLQUFLMFQsTUFBSTtlQUFNalQsRUFBRXJDLFVBQVU3QyxPQUFLO2dCQUFXLElBQUlpQixJQUFFd0Q7Z0JBQUssSUFBRyxXQUFTbkMsRUFBRW1DLEtBQUt2RSxTQUFTd0IsSUFBSSxZQUFXLE1BQU0sSUFBSVcsTUFBTTtnQkFBdUMsSUFBSWtCLElBQUVqQixFQUFFK0YsTUFBTTVELEtBQUt6QixZQUFZcUYsTUFBTVg7Z0JBQU0sSUFBR2pELEtBQUt5VSxtQkFBaUJ6VSxLQUFLb1QsWUFBVztvQkFBQyxJQUFHcFQsS0FBSzRKLGtCQUFpQixNQUFNLElBQUloTSxNQUFNO29CQUE0QkMsRUFBRW1DLEtBQUt2RSxTQUFTZ0MsUUFBUXFCO29CQUFHLElBQUkvQyxJQUFFOEIsRUFBRTJOLFNBQVN4TCxLQUFLdkUsUUFBUWlaLGNBQWNuTSxpQkFBZ0J2SSxLQUFLdkU7b0JBQVMsSUFBR3FELEVBQUV5RSx5QkFBdUJ4SCxHQUFFO29CQUFPLElBQUlrRCxJQUFFZSxLQUFLcVUsaUJBQWdCclQsSUFBRTVCLEVBQUVzQyxPQUFPMUIsS0FBS3pCLFlBQVlvVztvQkFBTTFWLEVBQUUrRixhQUFhLE1BQUtoRSxJQUFHaEIsS0FBS3ZFLFFBQVF1SixhQUFhLG9CQUFtQmhFLElBQUdoQixLQUFLNFU7b0JBQWE1VSxLQUFLeVQsT0FBT3pCLGFBQVduVSxFQUFFb0IsR0FBR2hELFNBQVM0SixFQUFFN0M7b0JBQU0sSUFBSXJELElBQUUscUJBQW1CSyxLQUFLeVQsT0FBT25CLFlBQVV0UyxLQUFLeVQsT0FBT25CLFVBQVVoVCxLQUFLVSxNQUFLZixHQUFFZSxLQUFLdkUsV0FBU3VFLEtBQUt5VCxPQUFPbkIsV0FBVWpSLElBQUVyQixLQUFLNlUsZUFBZWxWLElBQUdpQixJQUFFWixLQUFLeVQsT0FBT2pCLGVBQWEsSUFBRWpTLFNBQVN5TSxPQUFLblAsRUFBRW1DLEtBQUt5VCxPQUFPakI7b0JBQVczVSxFQUFFb0IsR0FBR2dGLEtBQUtqRSxLQUFLekIsWUFBWXdWLFVBQVMvVCxNQUFNa08sU0FBU3ROLElBQUcvQyxFQUFFbUMsS0FBS3ZFLFNBQVNnQyxRQUFRdUMsS0FBS3pCLFlBQVlxRixNQUFNZ1A7b0JBQVU1UyxLQUFLd1QsVUFBUSxJQUFJekI7d0JBQVErQyxZQUFXelQ7d0JBQUU1RixTQUFRd0Q7d0JBQUUvQixRQUFPOEMsS0FBS3ZFO3dCQUFRc1osU0FBUXhPO3dCQUFFeU8sYUFBWXhTO3dCQUFFdU0sUUFBTy9PLEtBQUt5VCxPQUFPMUU7d0JBQU93RCxhQUFZdlMsS0FBS3lULE9BQU9sQjt3QkFBWTBDLG1CQUFrQjt3QkFBSTdWLEVBQUU2QyxPQUFPaEQsSUFBR2UsS0FBS3dULFFBQVEwQixZQUFXclgsRUFBRW9CLEdBQUdoRCxTQUFTNEosRUFBRTVDO29CQUFNLElBQUlQLElBQUUsU0FBRkE7d0JBQWEsSUFBSTVELElBQUV0QyxFQUFFOFc7d0JBQVk5VyxFQUFFOFcsY0FBWSxNQUFLOVcsRUFBRW9OLG9CQUFrQixHQUFFL0wsRUFBRXJCLEVBQUVmLFNBQVNnQyxRQUFRakIsRUFBRStCLFlBQVlxRixNQUFNdUY7d0JBQU9ySyxNQUFJeUcsRUFBRW9OLE9BQUtuVyxFQUFFNFgsT0FBTyxNQUFLNVg7O29CQUFJLElBQUc0QyxFQUFFOEIsMkJBQXlCckQsRUFBRW1DLEtBQUswVCxLQUFLclgsU0FBU3dKLEVBQUU3QyxPQUFNLE9BQU9oRCxLQUFLNEosb0JBQWtCO3lCQUFPL0wsRUFBRW1DLEtBQUswVCxLQUFLL1MsSUFBSXZCLEVBQUV5QixnQkFBZTZCLEdBQUd6QixxQkFBcUJSLEVBQUUwVTtvQkFBc0J6Uzs7ZUFBTWpDLEVBQUVyQyxVQUFVOUMsT0FBSyxTQUFTa0I7Z0JBQUcsSUFBSXNDLElBQUVrQixNQUFLakUsSUFBRWlFLEtBQUtxVSxpQkFBZ0JwVixJQUFFcEIsRUFBRStGLE1BQU01RCxLQUFLekIsWUFBWXFGLE1BQU13RjtnQkFBTSxJQUFHcEosS0FBSzRKLGtCQUFpQixNQUFNLElBQUloTSxNQUFNO2dCQUE0QixJQUFJb0QsSUFBRSxTQUFGQTtvQkFBYWxDLEVBQUV3VSxnQkFBYy9OLEVBQUV0QyxRQUFNbEgsRUFBRXVQLGNBQVl2UCxFQUFFdVAsV0FBV0MsWUFBWXhQLElBQUcrQyxFQUFFckQsUUFBUWlTLGdCQUFnQjtvQkFBb0I3UCxFQUFFaUIsRUFBRXJELFNBQVNnQyxRQUFRcUIsRUFBRVAsWUFBWXFGLE1BQU15RixTQUFRdkssRUFBRThLLG9CQUFrQixHQUFFOUssRUFBRXlWO29CQUFnQi9YLEtBQUdBOztnQkFBS3FCLEVBQUVtQyxLQUFLdkUsU0FBU2dDLFFBQVF3QixJQUFHQSxFQUFFc0UseUJBQXVCMUYsRUFBRTlCLEdBQUdILFlBQVlpSyxFQUFFNUM7Z0JBQU1qRCxLQUFLdVQsZUFBZTFNLEVBQUUwRCxVQUFRLEdBQUV2SyxLQUFLdVQsZUFBZTFNLEVBQUVyQyxVQUFRLEdBQUV4RSxLQUFLdVQsZUFBZTFNLEVBQUVvTSxVQUFRO2dCQUFFN1QsRUFBRThCLDJCQUF5QnJELEVBQUVtQyxLQUFLMFQsS0FBS3JYLFNBQVN3SixFQUFFN0MsU0FBT2hELEtBQUs0SixvQkFBa0I7Z0JBQUUvTCxFQUFFOUIsR0FBRzRFLElBQUl2QixFQUFFeUIsZ0JBQWVHLEdBQUdDLHFCQUFxQkwsTUFBSUksS0FBSWhCLEtBQUtzVCxjQUFZO2VBQUs3UyxFQUFFckMsVUFBVXFXLGdCQUFjO2dCQUFXLE9BQU90UyxRQUFRbkMsS0FBS29WO2VBQWEzVSxFQUFFckMsVUFBVWlXLGdCQUFjO2dCQUFXLE9BQU9yVSxLQUFLMFQsTUFBSTFULEtBQUswVCxPQUFLN1YsRUFBRW1DLEtBQUt5VCxPQUFPeEIsVUFBVTtlQUFJeFIsRUFBRXJDLFVBQVV3VyxhQUFXO2dCQUFXLElBQUlwWSxJQUFFcUIsRUFBRW1DLEtBQUtxVTtnQkFBaUJyVSxLQUFLcVYsa0JBQWtCN1ksRUFBRVYsS0FBS3NLLEVBQUUyTSxnQkFBZS9TLEtBQUtvVixhQUFZNVksRUFBRVosWUFBWWlLLEVBQUU3QyxPQUFLLE1BQUk2QyxFQUFFNUM7Z0JBQU1qRCxLQUFLdVU7ZUFBaUI5VCxFQUFFckMsVUFBVWlYLG9CQUFrQixTQUFTN1ksR0FBRXNDO2dCQUFHLElBQUlHLElBQUVlLEtBQUt5VCxPQUFPckI7Z0JBQUssY0FBWSxzQkFBb0J0VCxJQUFFLGNBQVkvQyxFQUFFK0MsUUFBTUEsRUFBRVcsWUFBVVgsRUFBRWYsVUFBUWtCLElBQUVwQixFQUFFaUIsR0FBR2pELFNBQVNrRSxHQUFHdkQsTUFBSUEsRUFBRThZLFFBQVFDLE9BQU96VyxLQUFHdEMsRUFBRWdaLEtBQUszWCxFQUFFaUIsR0FBRzBXLFVBQVFoWixFQUFFeUMsSUFBRSxTQUFPLFFBQVFIO2VBQUkyQixFQUFFckMsVUFBVWdYLFdBQVM7Z0JBQVcsSUFBSXZYLElBQUVtQyxLQUFLdkUsUUFBUXNHLGFBQWE7Z0JBQXVCLE9BQU9sRSxNQUFJQSxJQUFFLHFCQUFtQm1DLEtBQUt5VCxPQUFPdkIsUUFBTWxTLEtBQUt5VCxPQUFPdkIsTUFBTTVTLEtBQUtVLEtBQUt2RSxXQUFTdUUsS0FBS3lULE9BQU92QjtnQkFBT3JVO2VBQUc0QyxFQUFFckMsVUFBVW1XLGdCQUFjO2dCQUFXdlUsS0FBS3dULFdBQVN4VCxLQUFLd1QsUUFBUWlDO2VBQVdoVixFQUFFckMsVUFBVXlXLGlCQUFlLFNBQVNoWDtnQkFBRyxPQUFPcUYsRUFBRXJGLEVBQUUwRTtlQUFnQjlCLEVBQUVyQyxVQUFVdVYsZ0JBQWM7Z0JBQVcsSUFBSW5YLElBQUV3RCxNQUFLbEIsSUFBRWtCLEtBQUt5VCxPQUFPaFcsUUFBUU8sTUFBTTtnQkFBS2MsRUFBRWlTLFFBQVEsU0FBU2pTO29CQUFHLElBQUcsWUFBVUEsR0FBRWpCLEVBQUVyQixFQUFFZixTQUFTYyxHQUFHQyxFQUFFK0IsWUFBWXFGLE1BQU0yRyxPQUFNL04sRUFBRWlYLE9BQU9wQixVQUFTLFNBQVN4VTt3QkFBRyxPQUFPckIsRUFBRXFJLE9BQU9oSDs2QkFBVSxJQUFHaUIsTUFBSStILEVBQUVxTSxRQUFPO3dCQUFDLElBQUluWCxJQUFFK0MsTUFBSStILEVBQUVvTSxRQUFNelcsRUFBRStCLFlBQVlxRixNQUFNcUMsYUFBV3pKLEVBQUUrQixZQUFZcUYsTUFBTWdJLFNBQVEzTSxJQUFFSCxNQUFJK0gsRUFBRW9NLFFBQU16VyxFQUFFK0IsWUFBWXFGLE1BQU1zQyxhQUFXMUosRUFBRStCLFlBQVlxRixNQUFNaVA7d0JBQVNoVixFQUFFckIsRUFBRWYsU0FBU2MsR0FBR1IsR0FBRVMsRUFBRWlYLE9BQU9wQixVQUFTLFNBQVN4VTs0QkFBRyxPQUFPckIsRUFBRTJYLE9BQU90VzsyQkFBS3RCLEdBQUcwQyxHQUFFekMsRUFBRWlYLE9BQU9wQixVQUFTLFNBQVN4VTs0QkFBRyxPQUFPckIsRUFBRTRYLE9BQU92Vzs7O29CQUFLQSxFQUFFckIsRUFBRWYsU0FBU2tJLFFBQVEsVUFBVXBILEdBQUcsaUJBQWdCO3dCQUFXLE9BQU9DLEVBQUVsQjs7b0JBQVcwRSxLQUFLeVQsT0FBT3BCLFdBQVNyUyxLQUFLeVQsU0FBTzVWLEVBQUV3SyxXQUFVckksS0FBS3lUO29CQUFRaFcsU0FBUTtvQkFBUzRVLFVBQVM7cUJBQUtyUyxLQUFLMFY7ZUFBYWpWLEVBQUVyQyxVQUFVc1gsWUFBVTtnQkFBVyxJQUFJN1gsSUFBRTlCLEVBQUVpRSxLQUFLdkUsUUFBUXNHLGFBQWE7aUJBQXlCL0IsS0FBS3ZFLFFBQVFzRyxhQUFhLFlBQVUsYUFBV2xFLE9BQUttQyxLQUFLdkUsUUFBUXVKLGFBQWEsdUJBQXNCaEYsS0FBS3ZFLFFBQVFzRyxhQUFhLFlBQVU7Z0JBQUkvQixLQUFLdkUsUUFBUXVKLGFBQWEsU0FBUTtlQUFNdkUsRUFBRXJDLFVBQVUrVixTQUFPLFNBQVMzWCxHQUFFc0M7Z0JBQUcsSUFBSS9DLElBQUVpRSxLQUFLekIsWUFBWXdWO2dCQUFTLE9BQU9qVixJQUFFQSxLQUFHakIsRUFBRXJCLEVBQUUyUixlQUFlbEssS0FBS2xJLElBQUcrQyxNQUFJQSxJQUFFLElBQUlrQixLQUFLekIsWUFBWS9CLEVBQUUyUixlQUFjbk8sS0FBS2dVO2dCQUFzQm5XLEVBQUVyQixFQUFFMlIsZUFBZWxLLEtBQUtsSSxHQUFFK0MsS0FBSXRDLE1BQUlzQyxFQUFFeVUsZUFBZSxjQUFZL1csRUFBRXNJLE9BQUsrQixFQUFFckMsUUFBTXFDLEVBQUVvTSxVQUFRO2dCQUFHcFYsRUFBRWlCLEVBQUV1VixpQkFBaUJoWSxTQUFTd0osRUFBRTVDLFNBQU9uRSxFQUFFd1UsZ0JBQWMvTixFQUFFdEMsYUFBVW5FLEVBQUV3VSxjQUFZL04sRUFBRXRDLFNBQU9xUixhQUFheFYsRUFBRXVVO2dCQUFVdlUsRUFBRXdVLGNBQVkvTixFQUFFdEMsTUFBS25FLEVBQUUyVSxPQUFPdEIsU0FBT3JULEVBQUUyVSxPQUFPdEIsTUFBTTVXLGFBQVV1RCxFQUFFdVUsV0FBU3ZTLFdBQVc7b0JBQVdoQyxFQUFFd1UsZ0JBQWMvTixFQUFFdEMsUUFBTW5FLEVBQUV2RDttQkFBUXVELEVBQUUyVSxPQUFPdEIsTUFBTTVXLGNBQVl1RCxFQUFFdkQ7ZUFBU2tGLEVBQUVyQyxVQUFVZ1csU0FBTyxTQUFTNVgsR0FBRXNDO2dCQUFHLElBQUkvQyxJQUFFaUUsS0FBS3pCLFlBQVl3VjtnQkFBUyxJQUFHalYsSUFBRUEsS0FBR2pCLEVBQUVyQixFQUFFMlIsZUFBZWxLLEtBQUtsSSxJQUFHK0MsTUFBSUEsSUFBRSxJQUFJa0IsS0FBS3pCLFlBQVkvQixFQUFFMlIsZUFBY25PLEtBQUtnVTtnQkFBc0JuVyxFQUFFckIsRUFBRTJSLGVBQWVsSyxLQUFLbEksR0FBRStDLEtBQUl0QyxNQUFJc0MsRUFBRXlVLGVBQWUsZUFBYS9XLEVBQUVzSSxPQUFLK0IsRUFBRXJDLFFBQU1xQyxFQUFFb00sVUFBUTtpQkFBSW5VLEVBQUVvVix3QkFBdUIsT0FBT0ksYUFBYXhWLEVBQUV1VSxXQUFVdlUsRUFBRXdVLGNBQVkvTixFQUFFb047Z0JBQUk3VCxFQUFFMlUsT0FBT3RCLFNBQU9yVCxFQUFFMlUsT0FBT3RCLE1BQU03VyxhQUFVd0QsRUFBRXVVLFdBQVN2UyxXQUFXO29CQUFXaEMsRUFBRXdVLGdCQUFjL04sRUFBRW9OLE9BQUs3VCxFQUFFeEQ7bUJBQVF3RCxFQUFFMlUsT0FBT3RCLE1BQU03VyxjQUFZd0QsRUFBRXhEO2VBQVFtRixFQUFFckMsVUFBVThWLHVCQUFxQjtnQkFBVyxLQUFJLElBQUlyVyxLQUFLbUMsS0FBS3VULGdCQUFsQjtvQkFBaUMsSUFBR3ZULEtBQUt1VCxlQUFlMVYsSUFBRyxRQUFPOztnQkFBRSxRQUFPO2VBQUc0QyxFQUFFckMsVUFBVWdKLGFBQVcsU0FBU3RJO2dCQUFHLE9BQU9BLElBQUVqQixFQUFFd0ssV0FBVXJJLEtBQUt6QixZQUFZdVEsU0FBUWpSLEVBQUVtQyxLQUFLdkUsU0FBU3dJLFFBQU9uRixJQUFHQSxFQUFFcVQsU0FBTyxtQkFBaUJyVCxFQUFFcVQsVUFBUXJULEVBQUVxVDtvQkFBTzVXLE1BQUt1RCxFQUFFcVQ7b0JBQU03VyxNQUFLd0QsRUFBRXFUO29CQUFRL1MsRUFBRWdELGdCQUFnQjVGLEdBQUVzQyxHQUFFa0IsS0FBS3pCLFlBQVlvWCxjQUFhN1c7ZUFBRzJCLEVBQUVyQyxVQUFVNFYscUJBQW1CO2dCQUFXLElBQUluVztnQkFBSyxJQUFHbUMsS0FBS3lULFFBQU8sS0FBSSxJQUFJalgsS0FBS3dELEtBQUt5VCxRQUFsQjtvQkFBeUJ6VCxLQUFLekIsWUFBWXVRLFFBQVF0UyxPQUFLd0QsS0FBS3lULE9BQU9qWCxPQUFLcUIsRUFBRXJCLEtBQUd3RCxLQUFLeVQsT0FBT2pYOztnQkFBSSxPQUFPcUI7ZUFBRzRDLEVBQUV1RCxtQkFBaUIsU0FBU3hIO2dCQUFHLE9BQU93RCxLQUFLaEUsS0FBSztvQkFBVyxJQUFJOEMsSUFBRWpCLEVBQUVtQyxNQUFNaUUsS0FBS3RFLElBQUdWLElBQUUsY0FBWSxzQkFBb0J6QyxJQUFFLGNBQVlULEVBQUVTLE9BQUtBO29CQUFFLEtBQUlzQyxNQUFJLGVBQWVrRCxLQUFLeEYsUUFBTXNDLE1BQUlBLElBQUUsSUFBSTJCLEVBQUVULE1BQUtmLElBQUdwQixFQUFFbUMsTUFBTWlFLEtBQUt0RSxHQUFFYjtvQkFBSSxtQkFBaUJ0QyxJQUFHO3dCQUFDLFNBQVEsTUFBSXNDLEVBQUV0QyxJQUFHLE1BQU0sSUFBSW9CLE1BQU0sc0JBQW9CcEIsSUFBRTt3QkFBS3NDLEVBQUV0Qzs7O2VBQVN5QyxFQUFFd0IsR0FBRTtnQkFBT3RCLEtBQUk7Z0JBQVVnRixLQUFJLFNBQUFBO29CQUFXLE9BQU9uRDs7O2dCQUFLN0IsS0FBSTtnQkFBVWdGLEtBQUksU0FBQUE7b0JBQVcsT0FBT3pCOzs7Z0JBQUt2RCxLQUFJO2dCQUFPZ0YsS0FBSSxTQUFBQTtvQkFBVyxPQUFPM0g7OztnQkFBSzJDLEtBQUk7Z0JBQVdnRixLQUFJLFNBQUFBO29CQUFXLE9BQU94RTs7O2dCQUFLUixLQUFJO2dCQUFRZ0YsS0FBSSxTQUFBQTtvQkFBVyxPQUFPcUI7OztnQkFBS3JHLEtBQUk7Z0JBQVlnRixLQUFJLFNBQUFBO29CQUFXLE9BQU85Qzs7O2dCQUFLbEMsS0FBSTtnQkFBY2dGLEtBQUksU0FBQUE7b0JBQVcsT0FBT3JCOztrQkFBTXJDOztRQUFLLE9BQU81QyxFQUFFQyxHQUFHdEIsS0FBRzJXLEVBQUVuUCxrQkFBaUJuRyxFQUFFQyxHQUFHdEIsR0FBRzRILGNBQVkrTyxHQUFFdFYsRUFBRUMsR0FBR3RCLEdBQUc2SCxhQUFXO1lBQVcsT0FBT3hHLEVBQUVDLEdBQUd0QixLQUFHaUUsR0FBRTBTLEVBQUVuUDtXQUFrQm1QO01BQUd4VjtLQUFTLFNBQVV5QjtRQUFHLElBQUlPLElBQUUsV0FBVTBCLElBQUUsaUJBQWdCWixJQUFFLGNBQWFHLElBQUUsTUFBSUgsR0FBRStCLElBQUVwRCxFQUFFdEIsR0FBRzZCLElBQUcrQyxJQUFFdEQsRUFBRWlKLFdBQVVySCxFQUFFOE47WUFBU3dELFdBQVU7WUFBUTdVLFNBQVE7WUFBUW1ZLFNBQVE7WUFBRzNELFVBQVM7WUFBaUhuUCxJQUFFMUQsRUFBRWlKLFdBQVVySCxFQUFFMlU7WUFBYUMsU0FBUTtZQUE4QjFTO1lBQUdGLE1BQUs7WUFBT0MsTUFBSztXQUFRc0M7WUFBR3NRLE9BQU07WUFBaUJDLFNBQVE7V0FBb0J0UTtZQUFHNEQsTUFBSyxTQUFPeEk7WUFBRXlJLFFBQU8sV0FBU3pJO1lBQUVxQyxNQUFLLFNBQU9yQztZQUFFdUksT0FBTSxVQUFRdkk7WUFBRWdTLFVBQVMsYUFBV2hTO1lBQUUySixPQUFNLFVBQVEzSjtZQUFFZ0wsU0FBUSxZQUFVaEw7WUFBRWlTLFVBQVMsYUFBV2pTO1lBQUVxRixZQUFXLGVBQWFyRjtZQUFFc0YsWUFBVyxlQUFhdEY7V0FBR2lGLElBQUUsU0FBUzdFO1lBQUcsU0FBU3dCO2dCQUFJLE9BQU8xRCxFQUFFa0IsTUFBS3dDLElBQUczRSxFQUFFbUMsTUFBS2dCLEVBQUViLE1BQU1ILE1BQUtJOztZQUFZLE9BQU81RCxFQUFFZ0csR0FBRXhCLElBQUd3QixFQUFFcEUsVUFBVXFXLGdCQUFjO2dCQUFXLE9BQU96VSxLQUFLb1YsY0FBWXBWLEtBQUsrVjtlQUFldlQsRUFBRXBFLFVBQVVpVyxnQkFBYztnQkFBVyxPQUFPclUsS0FBSzBULE1BQUkxVCxLQUFLMFQsT0FBS3RVLEVBQUVZLEtBQUt5VCxPQUFPeEIsVUFBVTtlQUFJelAsRUFBRXBFLFVBQVV3VyxhQUFXO2dCQUFXLElBQUkvVyxJQUFFdUIsRUFBRVksS0FBS3FVO2dCQUFpQnJVLEtBQUtxVixrQkFBa0J4WCxFQUFFL0IsS0FBS3lKLEVBQUVzUSxRQUFPN1YsS0FBS29WLGFBQVlwVixLQUFLcVYsa0JBQWtCeFgsRUFBRS9CLEtBQUt5SixFQUFFdVEsVUFBUzlWLEtBQUsrVjtnQkFBZWxZLEVBQUVqQyxZQUFZc0gsRUFBRUYsT0FBSyxNQUFJRSxFQUFFRCxPQUFNakQsS0FBS3VVO2VBQWlCL1IsRUFBRXBFLFVBQVUyWCxjQUFZO2dCQUFXLE9BQU8vVixLQUFLdkUsUUFBUXNHLGFBQWEsb0JBQWtCLHFCQUFtQi9CLEtBQUt5VCxPQUFPbUMsVUFBUTVWLEtBQUt5VCxPQUFPbUMsUUFBUXRXLEtBQUtVLEtBQUt2RSxXQUFTdUUsS0FBS3lULE9BQU9tQztlQUFVcFQsRUFBRXdCLG1CQUFpQixTQUFTbkc7Z0JBQUcsT0FBT21DLEtBQUtoRSxLQUFLO29CQUFXLElBQUlRLElBQUU0QyxFQUFFWSxNQUFNaUUsS0FBS3hELElBQUczQixJQUFFLGNBQVksc0JBQW9CakIsSUFBRSxjQUFZOUIsRUFBRThCLE1BQUlBLElBQUU7b0JBQUssS0FBSXJCLE1BQUksZUFBZXdGLEtBQUtuRSxRQUFNckIsTUFBSUEsSUFBRSxJQUFJZ0csRUFBRXhDLE1BQUtsQixJQUFHTSxFQUFFWSxNQUFNaUUsS0FBS3hELEdBQUVqRTtvQkFBSSxtQkFBaUJxQixJQUFHO3dCQUFDLFNBQVEsTUFBSXJCLEVBQUVxQixJQUFHLE1BQU0sSUFBSUQsTUFBTSxzQkFBb0JDLElBQUU7d0JBQUtyQixFQUFFcUI7OztlQUFTb0IsRUFBRXVELEdBQUU7Z0JBQU9yRCxLQUFJO2dCQUFVZ0YsS0FBSSxTQUFBQTtvQkFBVyxPQUFPOUM7OztnQkFBS2xDLEtBQUk7Z0JBQVVnRixLQUFJLFNBQUFBO29CQUFXLE9BQU96Qjs7O2dCQUFLdkQsS0FBSTtnQkFBT2dGLEtBQUksU0FBQUE7b0JBQVcsT0FBT3hFOzs7Z0JBQUtSLEtBQUk7Z0JBQVdnRixLQUFJLFNBQUFBO29CQUFXLE9BQU8xRDs7O2dCQUFLdEIsS0FBSTtnQkFBUWdGLEtBQUksU0FBQUE7b0JBQVcsT0FBT3FCOzs7Z0JBQUtyRyxLQUFJO2dCQUFZZ0YsS0FBSSxTQUFBQTtvQkFBVyxPQUFPdkQ7OztnQkFBS3pCLEtBQUk7Z0JBQWNnRixLQUFJLFNBQUFBO29CQUFXLE9BQU9yQjs7a0JBQU1OO1VBQUd4QjtRQUFHLE9BQU81QixFQUFFdEIsR0FBRzZCLEtBQUdrRyxFQUFFN0Isa0JBQWlCNUUsRUFBRXRCLEdBQUc2QixHQUFHeUUsY0FBWXlCLEdBQUV6RyxFQUFFdEIsR0FBRzZCLEdBQUcwRSxhQUFXO1lBQVcsT0FBT2pGLEVBQUV0QixHQUFHNkIsS0FBRzZDLEdBQUVxRCxFQUFFN0I7V0FBa0I2QjtPQUFJbEk7Ozs7O0FDRHAvYixTQUFTcVksbUJBQW1CdmE7SUFDeEIsSUFBSXdhLGdCQUFnQjdhLEVBQUVLLFNBQVNJLFNBQVNBLFNBQVNvTixTQUFTO0lBQzFEZ04sY0FBY3JhLFlBQVk7SUFFMUIsSUFBSXNhLGFBQWE5YSxFQUFFNmEsZUFBZTFPLEtBQUs7SUFDdkMyTyxXQUFXamEsU0FBUzs7O0FBUXhCLFNBQVNrYSx1QkFBdUIxYTtJQUM1QixJQUFJd2EsZ0JBQWdCN2EsRUFBRUssU0FBU0ksU0FBU0EsU0FBU29OLFNBQVM7SUFDMURnTixjQUFjcmEsWUFBWTtJQUUxQixJQUFJd2EsYUFBYWhiLEVBQUU2YSxlQUFldE8sS0FBSztJQUN2Q3lPLFdBQVduYSxTQUFTOzs7OztBQ3JCeEJiLEVBQUUsa0JBQWtCNlksTUFBTTtJQUN4QjdZLEVBQUUsa0JBQWtCUSxZQUFZO0lBQ2hDUixFQUFFNEUsTUFBTS9ELFNBQVM7Ozs7O0FDRW5CLFNBQVNvYSxjQUFjNWEsU0FBUytDO0lBQzVCLEtBQUlwRCxFQUFFSyxTQUFTNmEsT0FDZjtRQUNJbGIsRUFBRUssU0FBUzZhLElBQUk5WDs7OztBQVV2QixTQUFTK1gsWUFBWUMsV0FBV0M7SUFFNUJyYixFQUFFb2IsV0FBV0UsU0FBU0Q7OztBQUkxQnJiLEVBQUUsYUFBYTZZLE1BQU07SUFFakIsSUFBSW5LLEtBQUsxTyxFQUFFNEUsTUFBTW1LLEtBQUs7SUFHdEIvTyxFQUFFLE1BQU0wTyxJQUFJcE4sS0FBSyxXQUFXc0QsS0FBS3JFOzs7QUFNckMsU0FBU2diO0lBRUx2YixFQUFFLDRCQUE0QnlKO0lBQzlCekosRUFBRSw0QkFBNEJ5SjtJQUM5QnpKLEVBQUUsdUJBQXVCeUo7SUFHekJ6SixFQUFFLDhCQUE4QnNCLEtBQUssWUFBWSxTQUFTWCxHQUFHd0s7UUFBSyxRQUFRQTs7OztBQU05RSxTQUFTcVEsZ0JBQWdCbmI7SUFDckJMLEVBQUVLLFNBQVNJLFNBQVNvTixXQUFXck4sWUFBWTtJQUMzQ1IsRUFBRUssU0FBU1EsU0FBUzs7Ozs7QUNuRHhCYixFQUFFLFVBQVV5YixPQUFPO0lBQ2YsSUFBSXpiLEVBQUU0RSxNQUFNc1csU0FBUyxpQkFBaUI7UUFDbENsYixFQUFFLFlBQVlrQixNQUFNOzs7Ozs7QUNGNUJsQixFQUFFLGNBQWM2WSxNQUFNO0lBQ2xCN1ksRUFBRTRFLE1BQU1pRixZQUFZO0lBQ3BCN0osRUFBRSxtQkFBbUI2SixZQUFZO0lBQ2pDNlIsUUFBUUMsSUFBSTs7Ozs7QUNIaEIzYixFQUFFaUYsUUFBUTJXLE9BQU87SUFDYixJQUFJQSxTQUFTNWIsRUFBRWlGLFFBQVFzTjtJQUV2QixJQUFJcUosVUFBVSxJQUFJO1FBQ2Q1YixFQUFFLG1CQUFtQmEsU0FBUztRQUM5QmIsRUFBRSxlQUFlYSxTQUFTO1FBQzFCYixFQUFFLFFBQVFhLFNBQVM7V0FDaEI7UUFDSGIsRUFBRSxtQkFBbUJRLFlBQVk7UUFDakNSLEVBQUUsZUFBZVEsWUFBWTtRQUM3QlIsRUFBRSxRQUFRUSxZQUFZOzs7O0FBSTlCUixFQUFFLHNCQUFzQjZZLE1BQU07SUFDMUI3WSxFQUFFLG9DQUFvQ0U7Ozs7O0FDSjFDLFNBQVMyYixVQUFVdEcsS0FBS3VHLEtBQUtDLE1BQU1DLGVBQWV0UztJQUNsRCxJQUR5RHVTLFFBQ3pEalgsVUFBQS9FLFNBQUEsS0FBQStFLFVBQUEsT0FBQWtYLFlBQUFsWCxVQUFBLEtBRGlFO0lBRWhFLElBQUltWCxTQUFTLElBQUlDO1FBQ2hCdEMsVUFBVSxJQUFJdUMsT0FBT0MsS0FBS0MsT0FBT1QsS0FBS0M7UUFDdEN4RyxLQUFLQTtRQUNMaUgsTUFBTSxpQkFBaUI5UyxPQUFPO1FBQzlCK1MsZ0JBQWlCUixVQUFVLE9BQVEsOEJBQThCQSxRQUFRLG9CQUFvQjs7SUFHOUYsSUFBSVMsYUFBYSxJQUFJTCxPQUFPQyxLQUFLSztRQUN0Qm5DLFNBQVN3QjtRQUNsQlksVUFBVTs7SUFHWlQsT0FBT1UsWUFBWSxTQUFTO1FBQzNCSCxXQUFXSSxLQUFLdkgsS0FBSzRHOzs7Ozs7QUN4QnZCbmMsRUFBRSwyQkFBMkI2WSxNQUFNO0lBQ2xDN1ksRUFBRTRFLE1BQU1uRSxTQUFTb04sU0FBUyxRQUFRck4sWUFBWSxzQkFBc0JLLFNBQVM7SUFDN0ViLEVBQUU0RSxNQUFNcEUsWUFBWSx1QkFBdUJLLFNBQVM7OztBQUtyRGIsRUFBRSw0QkFBNEI2WSxNQUFNO0lBQ2hDN1ksRUFBRTRFLE1BQU1uRSxTQUFTb04sU0FBUyxRQUFRbUosS0FBSyxRQUFReFcsWUFBWSxrQkFBa0JLLFNBQVMsZ0JBQWdCZ0osWUFBWTtJQUNsSDdKLEVBQUU0RSxNQUFNcEUsWUFBWSxnQkFBZ0J3VyxLQUFLLFVBQVVuVyxTQUFTLGtCQUFrQmdKLFlBQVk7Ozs7O0FDTjlGLFNBQVNrVCwyQkFBMkJ2YjtJQUNoQ3hCLEVBQUV3QixPQUFPZixTQUFTQSxTQUFTQyxLQUFLLGFBQWFGLFlBQVk7SUFDekRSLEVBQUV3QixPQUFPZixTQUFTb0osWUFBWTs7Ozs7QUNQbEMsU0FBU21ULFlBQVkzYztJQUVqQixJQUFLTCxFQUFHSyxTQUFVWSxTQUFVLFdBQWE7UUFDckNqQixFQUFFLHNFQUFzRVEsWUFBWTtRQUNwRlIsRUFBRSxzQkFBc0JpZDtXQUc1QjtRQUNJamQsRUFBRSxzRUFBc0VRLFlBQVk7UUFDcEZSLEVBQUUsc0JBQXNCaWQ7UUFHeEJqZCxFQUFFSyxTQUFTSSxTQUFTSSxTQUFTO1FBQzdCYixFQUFFSyxTQUFTd0osWUFBWTtRQUN2QjdKLEVBQUVLLFNBQVNJLFNBQVNBLFNBQVMwTCxLQUFLLHNCQUFzQitRO1FBQ3hEbGQsRUFBRUssU0FBU0ksU0FBU0EsU0FBU29KLFlBQVk7Ozs7QUFJakQsU0FBU3NULHFCQUFxQjljO0lBQ3RCTCxFQUFFLHNFQUFzRVEsWUFBWTtJQUNwRlIsRUFBRSxzQkFBc0JpZDtJQUd4QmpkLEVBQUVLLFNBQVNJLFNBQVNBLFNBQVMwTCxPQUFPQSxLQUFLLHNCQUFzQmlSO0lBQy9EcGQsRUFBRUssU0FBU0ksU0FBU0EsU0FBUzBMLEtBQUsscUJBQXFCdEwsU0FBUztJQUNoRWIsRUFBRUssU0FBU0ksU0FBU0EsU0FBUzBMLE9BQU96TCxLQUFLLG1EQUFtREcsU0FBUzs7O0FBSTdHYixFQUFFLGFBQWFtQixHQUFHLHFCQUFxQixTQUFTQztJQUN4QyxLQUFJcEIsRUFBRW9CLEVBQUVVLFFBQVFiLFNBQVMsNEJBQTJCO1FBQ2hEakIsRUFBRTRFLE1BQU0ySCxPQUFPN0wsS0FBSyxrQkFBa0JGLFlBQVksaUJBQWlCSyxTQUFTO1FBQzVFYixFQUFFNEUsTUFBTTJILE9BQU83TCxLQUFLLGFBQWFQO1FBQ2pDSCxFQUFFNEUsTUFBTTJILE9BQU83TCxLQUFLLGFBQWFSOztHQUV0Q2lCLEdBQUcsc0JBQXNCLFNBQVNDO0lBQ2pDLEtBQUlwQixFQUFFb0IsRUFBRVUsUUFBUWIsU0FBUyw0QkFBMkI7UUFDaERqQixFQUFFNEUsTUFBTTJILE9BQU83TCxLQUFLLGdCQUFnQkYsWUFBWSxlQUFlSyxTQUFTO1FBQ3hFYixFQUFFNEUsTUFBTTJILE9BQU83TCxLQUFLLGFBQWFSO1FBQ2pDRixFQUFFNEUsTUFBTTJILE9BQU83TCxLQUFLLGFBQWFQOzs7Ozs7QUN2QzdDLElBQU1rZCxnQkFBZ0JsWSxTQUFTc0IsZUFBZTs7QUFFOUMsSUFBTTZXLGVBQWVuWSxTQUFTc0IsZUFBZTs7QUFFN0MsSUFBTThXLGtCQUFrQnBZLFNBQVNxWSx1QkFBdUI7O0FBRXhELElBQU1DLHFCQUFxQnRZLFNBQVNxWSx1QkFBdUI7O0FBSW5ERSxjQUFjSixhQUFhSyxpQkFBaUIsU0FBUztJQUNqRGpDLFFBQVFDLElBQUk7SUFDWjBCLGNBQWNPLFVBQVVuVSxPQUFPOzs7QUFJbkNvVSxXQUFXUCxhQUFhSyxpQkFBaUIsU0FBUztJQUc5QyxLQUFLaGQsSUFBSSxHQUFHQSxJQUFJOGMsbUJBQW1CeGQsUUFBUVUsS0FBSztRQUM1QythLFFBQVFDLElBQUk4QixtQkFBbUI5Yzs7OztBQUt2Q21kLGtCQUFrQlIsYUFBYUssaUJBQWlCLFNBQVM7SUFDckQsSUFBSUwsYUFBYVMsZ0JBQWdCLFVBQVU7UUFDdkNULGFBQWFTLGNBQWM7V0FHeEI7UUFDSFQsYUFBYVMsY0FBYzs7Ozs7O0NiL0IzQyxTQUFBL2QsR0FBQWlGLFFBQVNuRixVQUFBQTtJQUVMO0dBS0lFLFFBQUVpRixRQUFBRSIsImZpbGUiOiJtYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gV2hlbiBhIHJlbW92ZSBmaWVsZCBpcyBjbGlja2VkXG5mdW5jdGlvbiBjb3VudHJ5X3JlbW92ZWQoKVxue1xuICAgIHZhciBjb3VudHJpZXMgPSAkKCcjY291bnRyaWVzX3BhcmVudCBzZWxlY3QnKTtcblxuICAgIGlmKGNvdW50cmllcy5sZW5ndGggPD0gMSlcbiAgICB7XG4gICAgICAgIC8vIGhpZGUgdGhlIHJlbW92ZSBsaW5rc1xuICAgICAgICAkKCcucmVtb3ZlX2ZpZWxkJykuaGlkZSgpO1xuICAgIH1lbHNle1xuICAgICAgICAkKCcucmVtb3ZlX2ZpZWxkJykuc2hvdygpO1xuICAgIH1cbn1cblxuLy8gR2VuZXJpYyBwcmVwYXJlZG5lc3MgYWN0aW9uIGl0ZW1cbmZ1bmN0aW9uIGdwYUFjdGlvbkNoYW5nZWQoIGVsZW1lbnQgKSB7XG4gICAgdmFyIGFkZEFjdGlvbkJ1dHRvbiA9ICQoXCIjYWRkLWFjdGlvbi1idG5cIik7XG4gICAgaWYgKGVsZW1lbnQuY2hlY2tlZCkge1xuICAgICAgICAvLyBFbmFibGUgdGhlIGFkZCBhY3Rpb24gYnV0dG9uXG4gICAgICAgIGFkZEFjdGlvbkJ1dHRvbi5yZW1vdmVDbGFzcyhcImRpc2FibGVkXCIpO1xuICAgICAgICBcbiAgICAgICAgLy8gU2hvdyBkZXBhcnRtZW50IGRyb3Bkb3duXG4gICAgICAgICQoZWxlbWVudCkucGFyZW50KCkucGFyZW50KCkuZmluZChcIi5ncGFfYWN0aW9uX2RlcGFydG1lbnRcIikuc2hvdygpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEhpZGUgZGVwYXJ0bWVudCBkcm9wZG93blxuICAgICAgICAkKGVsZW1lbnQpLnBhcmVudCgpLnBhcmVudCgpLmZpbmQoXCIuZ3BhX2FjdGlvbl9kZXBhcnRtZW50XCIpLmhpZGUoKTtcblxuICAgICAgICAvLyBEaXNhYmxlIHRoZSBhZGQgYWN0aW9uIGJ1dHRvbiBpZiB0aGVyZSBhcmUgbm8gY2hlY2tlZCBhY3Rpb25zXG4gICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgJChcImlucHV0W25hbWU9Z3BhX2FjdGlvbl06Y2hlY2tlZFwiKS5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgaSsrO1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKGkgPCAxKSB7XG4gICAgICAgICAgICBhZGRBY3Rpb25CdXR0b24uYWRkQ2xhc3MoXCJkaXNhYmxlZFwiKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG5cbi8qXG4qIFZlcmlmeSBpZiB0aGUgQWRkIGRlcGFydG1lbnQgb3B0aW9uIGlzIHNlbGVjdGVkIGFuZCBvcGVuIHRoZSBtb2RhbCB3aW5kb3dcbipcbiogQHBhcmFtIE9iamVjdCBzZWxlY3QgICAgICBUaGUgc2VsZWN0IE9iamVjdFxuKiBAcGFyYW0gc3RyaW5nIG1vZGFsX2lkICAgIFRoZSBtb2RhbCBpZCB0byBvcGVuXG4qL1xuZnVuY3Rpb24gYWRkRGVwYXJ0bWVudE1vZGFsKHNlbGVjdCwgbW9kYWxfaWQpe1xuICAgIGlmKCQoc2VsZWN0KS5maW5kKFwiOnNlbGVjdGVkXCIpLmhhc0NsYXNzKCdhZGQtZGVwYXJ0bWVudCcpKVxuICAgIHtcbiAgICAgICAgJChtb2RhbF9pZCkubW9kYWwoJ3Nob3cnKTtcblxuICAgICAgICAgJCgnI2FkZF9kZXBhcnRtZW50Jykub24oJ2hpZGRlbi5icy5tb2RhbCcsIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAkKHNlbGVjdCkuZmluZChcIm9wdGlvblwiKS5maXJzdCgpLnByb3AoJ3NlbGVjdGVkJywgdHJ1ZSk7XG4gICAgICAgIH0pXG4gICAgfVxufSIsImZ1bmN0aW9uIHJlYWRVUkwoaW5wdXQpIHtcbiAgaWYgKGlucHV0LmZpbGVzICYmIGlucHV0LmZpbGVzWzBdKSB7XG4gICAgICB2YXIgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgIFxuICAgICAgcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgJCgnLkFnZW5jeS1kZXRhaWxzX19sb2dvX19wcmV2aWV3JykuY3NzKCdiYWNrZ3JvdW5kLWltYWdlJywgJ3VybCgnICsgZS50YXJnZXQucmVzdWx0ICsgJyknKTtcbiAgICAgICAgICAkKCcuQWdlbmN5LWRldGFpbHNfX2xvZ29fX3ByZXZpZXcnKS5hZGRDbGFzcygnU2VsZWN0ZWQnKVxuICAgICAgfVxuICAgICAgXG4gICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChpbnB1dC5maWxlc1swXSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcHJldmlld0xvZ28obG9nb0ltYWdlKXtcbiAgICByZWFkVVJMKGxvZ29JbWFnZSk7XG4gICAgJChcIiNzZWxlY3QtbG9nb1wiKS5oaWRlKCk7XG4gICAgJChcIiNyZXBsYWNlLWxvZ29cIikuc2hvdygpO1xuICAgICQoXCIjcmVtb3ZlLWxvZ29cIikuc2hvdygpO1xufVxuXG5mdW5jdGlvbiB0cmlnZ2VyUHJldmlld0xvZ28oZSl7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgJChcIiNpbWdJbnBcIikudHJpZ2dlcignY2xpY2snKTtcbn1cblxuZnVuY3Rpb24gcmVtb3ZlTG9nb1ByZXZpZXcoZSl7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICQoXCIjcmVwbGFjZS1sb2dvXCIpLmhpZGUoKTtcbiAgICAkKFwiI3JlbW92ZS1sb2dvXCIpLmhpZGUoKTtcbiAgICAkKFwiI3NlbGVjdC1sb2dvXCIpLnNob3coKTtcbiAgICAkKCcuQWdlbmN5LWRldGFpbHNfX2xvZ29fX3ByZXZpZXcnKS5jc3MoJ2JhY2tncm91bmQtaW1hZ2UnLCAnbm9uZScpO1xuICAgICQoJy5BZ2VuY3ktZGV0YWlsc19fbG9nb19fcHJldmlldycpLnJlbW92ZUNsYXNzKCdTZWxlY3RlZCcpO1xufSIsIi8qIVxuICogQm9vdHN0cmFwIHY0LjAuMC1hbHBoYS42IChodHRwczovL2dldGJvb3RzdHJhcC5jb20pXG4gKiBDb3B5cmlnaHQgMjAxMS0yMDE3IFRoZSBCb290c3RyYXAgQXV0aG9ycyAoaHR0cHM6Ly9naXRodWIuY29tL3R3YnMvYm9vdHN0cmFwL2dyYXBocy9jb250cmlidXRvcnMpXG4gKiBMaWNlbnNlZCB1bmRlciBNSVQgKGh0dHBzOi8vZ2l0aHViLmNvbS90d2JzL2Jvb3RzdHJhcC9ibG9iL21hc3Rlci9MSUNFTlNFKVxuICovXG5pZihcInVuZGVmaW5lZFwiPT10eXBlb2YgalF1ZXJ5KXRocm93IG5ldyBFcnJvcihcIkJvb3RzdHJhcCdzIEphdmFTY3JpcHQgcmVxdWlyZXMgalF1ZXJ5LiBqUXVlcnkgbXVzdCBiZSBpbmNsdWRlZCBiZWZvcmUgQm9vdHN0cmFwJ3MgSmF2YVNjcmlwdC5cIik7K2Z1bmN0aW9uKHQpe3ZhciBlPXQuZm4uanF1ZXJ5LnNwbGl0KFwiIFwiKVswXS5zcGxpdChcIi5cIik7aWYoZVswXTwyJiZlWzFdPDl8fDE9PWVbMF0mJjk9PWVbMV0mJmVbMl08MXx8ZVswXT49NCl0aHJvdyBuZXcgRXJyb3IoXCJCb290c3RyYXAncyBKYXZhU2NyaXB0IHJlcXVpcmVzIGF0IGxlYXN0IGpRdWVyeSB2MS45LjEgYnV0IGxlc3MgdGhhbiB2NC4wLjBcIil9KGpRdWVyeSksK2Z1bmN0aW9uKCl7ZnVuY3Rpb24gdCh0LGUpe2lmKCF0KXRocm93IG5ldyBSZWZlcmVuY2VFcnJvcihcInRoaXMgaGFzbid0IGJlZW4gaW5pdGlhbGlzZWQgLSBzdXBlcigpIGhhc24ndCBiZWVuIGNhbGxlZFwiKTtyZXR1cm4hZXx8XCJvYmplY3RcIiE9dHlwZW9mIGUmJlwiZnVuY3Rpb25cIiE9dHlwZW9mIGU/dDplfWZ1bmN0aW9uIGUodCxlKXtpZihcImZ1bmN0aW9uXCIhPXR5cGVvZiBlJiZudWxsIT09ZSl0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3VwZXIgZXhwcmVzc2lvbiBtdXN0IGVpdGhlciBiZSBudWxsIG9yIGEgZnVuY3Rpb24sIG5vdCBcIit0eXBlb2YgZSk7dC5wcm90b3R5cGU9T2JqZWN0LmNyZWF0ZShlJiZlLnByb3RvdHlwZSx7Y29uc3RydWN0b3I6e3ZhbHVlOnQsZW51bWVyYWJsZTohMSx3cml0YWJsZTohMCxjb25maWd1cmFibGU6ITB9fSksZSYmKE9iamVjdC5zZXRQcm90b3R5cGVPZj9PYmplY3Quc2V0UHJvdG90eXBlT2YodCxlKTp0Ll9fcHJvdG9fXz1lKX1mdW5jdGlvbiBuKHQsZSl7aWYoISh0IGluc3RhbmNlb2YgZSkpdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKX12YXIgaT1cImZ1bmN0aW9uXCI9PXR5cGVvZiBTeW1ib2wmJlwic3ltYm9sXCI9PXR5cGVvZiBTeW1ib2wuaXRlcmF0b3I/ZnVuY3Rpb24odCl7cmV0dXJuIHR5cGVvZiB0fTpmdW5jdGlvbih0KXtyZXR1cm4gdCYmXCJmdW5jdGlvblwiPT10eXBlb2YgU3ltYm9sJiZ0LmNvbnN0cnVjdG9yPT09U3ltYm9sJiZ0IT09U3ltYm9sLnByb3RvdHlwZT9cInN5bWJvbFwiOnR5cGVvZiB0fSxvPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gdCh0LGUpe2Zvcih2YXIgbj0wO248ZS5sZW5ndGg7bisrKXt2YXIgaT1lW25dO2kuZW51bWVyYWJsZT1pLmVudW1lcmFibGV8fCExLGkuY29uZmlndXJhYmxlPSEwLFwidmFsdWVcImluIGkmJihpLndyaXRhYmxlPSEwKSxPYmplY3QuZGVmaW5lUHJvcGVydHkodCxpLmtleSxpKX19cmV0dXJuIGZ1bmN0aW9uKGUsbixpKXtyZXR1cm4gbiYmdChlLnByb3RvdHlwZSxuKSxpJiZ0KGUsaSksZX19KCkscj1mdW5jdGlvbih0KXtmdW5jdGlvbiBlKHQpe3JldHVybnt9LnRvU3RyaW5nLmNhbGwodCkubWF0Y2goL1xccyhbYS16QS1aXSspLylbMV0udG9Mb3dlckNhc2UoKX1mdW5jdGlvbiBuKHQpe3JldHVybih0WzBdfHx0KS5ub2RlVHlwZX1mdW5jdGlvbiBpKCl7cmV0dXJue2JpbmRUeXBlOmEuZW5kLGRlbGVnYXRlVHlwZTphLmVuZCxoYW5kbGU6ZnVuY3Rpb24oZSl7aWYodChlLnRhcmdldCkuaXModGhpcykpcmV0dXJuIGUuaGFuZGxlT2JqLmhhbmRsZXIuYXBwbHkodGhpcyxhcmd1bWVudHMpfX19ZnVuY3Rpb24gbygpe2lmKHdpbmRvdy5RVW5pdClyZXR1cm4hMTt2YXIgdD1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYm9vdHN0cmFwXCIpO2Zvcih2YXIgZSBpbiBoKWlmKHZvaWQgMCE9PXQuc3R5bGVbZV0pcmV0dXJue2VuZDpoW2VdfTtyZXR1cm4hMX1mdW5jdGlvbiByKGUpe3ZhciBuPXRoaXMsaT0hMTtyZXR1cm4gdCh0aGlzKS5vbmUoYy5UUkFOU0lUSU9OX0VORCxmdW5jdGlvbigpe2k9ITB9KSxzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7aXx8Yy50cmlnZ2VyVHJhbnNpdGlvbkVuZChuKX0sZSksdGhpc31mdW5jdGlvbiBzKCl7YT1vKCksdC5mbi5lbXVsYXRlVHJhbnNpdGlvbkVuZD1yLGMuc3VwcG9ydHNUcmFuc2l0aW9uRW5kKCkmJih0LmV2ZW50LnNwZWNpYWxbYy5UUkFOU0lUSU9OX0VORF09aSgpKX12YXIgYT0hMSxsPTFlNixoPXtXZWJraXRUcmFuc2l0aW9uOlwid2Via2l0VHJhbnNpdGlvbkVuZFwiLE1velRyYW5zaXRpb246XCJ0cmFuc2l0aW9uZW5kXCIsT1RyYW5zaXRpb246XCJvVHJhbnNpdGlvbkVuZCBvdHJhbnNpdGlvbmVuZFwiLHRyYW5zaXRpb246XCJ0cmFuc2l0aW9uZW5kXCJ9LGM9e1RSQU5TSVRJT05fRU5EOlwiYnNUcmFuc2l0aW9uRW5kXCIsZ2V0VUlEOmZ1bmN0aW9uKHQpe2RvIHQrPX5+KE1hdGgucmFuZG9tKCkqbCk7d2hpbGUoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQodCkpO3JldHVybiB0fSxnZXRTZWxlY3RvckZyb21FbGVtZW50OmZ1bmN0aW9uKHQpe3ZhciBlPXQuZ2V0QXR0cmlidXRlKFwiZGF0YS10YXJnZXRcIik7cmV0dXJuIGV8fChlPXQuZ2V0QXR0cmlidXRlKFwiaHJlZlwiKXx8XCJcIixlPS9eI1thLXpdL2kudGVzdChlKT9lOm51bGwpLGV9LHJlZmxvdzpmdW5jdGlvbih0KXtyZXR1cm4gdC5vZmZzZXRIZWlnaHR9LHRyaWdnZXJUcmFuc2l0aW9uRW5kOmZ1bmN0aW9uKGUpe3QoZSkudHJpZ2dlcihhLmVuZCl9LHN1cHBvcnRzVHJhbnNpdGlvbkVuZDpmdW5jdGlvbigpe3JldHVybiBCb29sZWFuKGEpfSx0eXBlQ2hlY2tDb25maWc6ZnVuY3Rpb24odCxpLG8pe2Zvcih2YXIgciBpbiBvKWlmKG8uaGFzT3duUHJvcGVydHkocikpe3ZhciBzPW9bcl0sYT1pW3JdLGw9YSYmbihhKT9cImVsZW1lbnRcIjplKGEpO2lmKCFuZXcgUmVnRXhwKHMpLnRlc3QobCkpdGhyb3cgbmV3IEVycm9yKHQudG9VcHBlckNhc2UoKStcIjogXCIrKCdPcHRpb24gXCInK3IrJ1wiIHByb3ZpZGVkIHR5cGUgXCInK2wrJ1wiICcpKygnYnV0IGV4cGVjdGVkIHR5cGUgXCInK3MrJ1wiLicpKX19fTtyZXR1cm4gcygpLGN9KGpRdWVyeSkscz0oZnVuY3Rpb24odCl7dmFyIGU9XCJhbGVydFwiLGk9XCI0LjAuMC1hbHBoYS42XCIscz1cImJzLmFsZXJ0XCIsYT1cIi5cIitzLGw9XCIuZGF0YS1hcGlcIixoPXQuZm5bZV0sYz0xNTAsdT17RElTTUlTUzonW2RhdGEtZGlzbWlzcz1cImFsZXJ0XCJdJ30sZD17Q0xPU0U6XCJjbG9zZVwiK2EsQ0xPU0VEOlwiY2xvc2VkXCIrYSxDTElDS19EQVRBX0FQSTpcImNsaWNrXCIrYStsfSxmPXtBTEVSVDpcImFsZXJ0XCIsRkFERTpcImZhZGVcIixTSE9XOlwic2hvd1wifSxfPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gZSh0KXtuKHRoaXMsZSksdGhpcy5fZWxlbWVudD10fXJldHVybiBlLnByb3RvdHlwZS5jbG9zZT1mdW5jdGlvbih0KXt0PXR8fHRoaXMuX2VsZW1lbnQ7dmFyIGU9dGhpcy5fZ2V0Um9vdEVsZW1lbnQodCksbj10aGlzLl90cmlnZ2VyQ2xvc2VFdmVudChlKTtuLmlzRGVmYXVsdFByZXZlbnRlZCgpfHx0aGlzLl9yZW1vdmVFbGVtZW50KGUpfSxlLnByb3RvdHlwZS5kaXNwb3NlPWZ1bmN0aW9uKCl7dC5yZW1vdmVEYXRhKHRoaXMuX2VsZW1lbnQscyksdGhpcy5fZWxlbWVudD1udWxsfSxlLnByb3RvdHlwZS5fZ2V0Um9vdEVsZW1lbnQ9ZnVuY3Rpb24oZSl7dmFyIG49ci5nZXRTZWxlY3RvckZyb21FbGVtZW50KGUpLGk9ITE7cmV0dXJuIG4mJihpPXQobilbMF0pLGl8fChpPXQoZSkuY2xvc2VzdChcIi5cIitmLkFMRVJUKVswXSksaX0sZS5wcm90b3R5cGUuX3RyaWdnZXJDbG9zZUV2ZW50PWZ1bmN0aW9uKGUpe3ZhciBuPXQuRXZlbnQoZC5DTE9TRSk7cmV0dXJuIHQoZSkudHJpZ2dlcihuKSxufSxlLnByb3RvdHlwZS5fcmVtb3ZlRWxlbWVudD1mdW5jdGlvbihlKXt2YXIgbj10aGlzO3JldHVybiB0KGUpLnJlbW92ZUNsYXNzKGYuU0hPVyksci5zdXBwb3J0c1RyYW5zaXRpb25FbmQoKSYmdChlKS5oYXNDbGFzcyhmLkZBREUpP3ZvaWQgdChlKS5vbmUoci5UUkFOU0lUSU9OX0VORCxmdW5jdGlvbih0KXtyZXR1cm4gbi5fZGVzdHJveUVsZW1lbnQoZSx0KX0pLmVtdWxhdGVUcmFuc2l0aW9uRW5kKGMpOnZvaWQgdGhpcy5fZGVzdHJveUVsZW1lbnQoZSl9LGUucHJvdG90eXBlLl9kZXN0cm95RWxlbWVudD1mdW5jdGlvbihlKXt0KGUpLmRldGFjaCgpLnRyaWdnZXIoZC5DTE9TRUQpLnJlbW92ZSgpfSxlLl9qUXVlcnlJbnRlcmZhY2U9ZnVuY3Rpb24obil7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe3ZhciBpPXQodGhpcyksbz1pLmRhdGEocyk7b3x8KG89bmV3IGUodGhpcyksaS5kYXRhKHMsbykpLFwiY2xvc2VcIj09PW4mJm9bbl0odGhpcyl9KX0sZS5faGFuZGxlRGlzbWlzcz1mdW5jdGlvbih0KXtyZXR1cm4gZnVuY3Rpb24oZSl7ZSYmZS5wcmV2ZW50RGVmYXVsdCgpLHQuY2xvc2UodGhpcyl9fSxvKGUsbnVsbCxbe2tleTpcIlZFUlNJT05cIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gaX19XSksZX0oKTtyZXR1cm4gdChkb2N1bWVudCkub24oZC5DTElDS19EQVRBX0FQSSx1LkRJU01JU1MsXy5faGFuZGxlRGlzbWlzcyhuZXcgXykpLHQuZm5bZV09Xy5falF1ZXJ5SW50ZXJmYWNlLHQuZm5bZV0uQ29uc3RydWN0b3I9Xyx0LmZuW2VdLm5vQ29uZmxpY3Q9ZnVuY3Rpb24oKXtyZXR1cm4gdC5mbltlXT1oLF8uX2pRdWVyeUludGVyZmFjZX0sX30oalF1ZXJ5KSxmdW5jdGlvbih0KXt2YXIgZT1cImJ1dHRvblwiLGk9XCI0LjAuMC1hbHBoYS42XCIscj1cImJzLmJ1dHRvblwiLHM9XCIuXCIrcixhPVwiLmRhdGEtYXBpXCIsbD10LmZuW2VdLGg9e0FDVElWRTpcImFjdGl2ZVwiLEJVVFRPTjpcImJ0blwiLEZPQ1VTOlwiZm9jdXNcIn0sYz17REFUQV9UT0dHTEVfQ0FSUk9UOidbZGF0YS10b2dnbGVePVwiYnV0dG9uXCJdJyxEQVRBX1RPR0dMRTonW2RhdGEtdG9nZ2xlPVwiYnV0dG9uc1wiXScsSU5QVVQ6XCJpbnB1dFwiLEFDVElWRTpcIi5hY3RpdmVcIixCVVRUT046XCIuYnRuXCJ9LHU9e0NMSUNLX0RBVEFfQVBJOlwiY2xpY2tcIitzK2EsRk9DVVNfQkxVUl9EQVRBX0FQSTpcImZvY3VzXCIrcythK1wiIFwiKyhcImJsdXJcIitzK2EpfSxkPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gZSh0KXtuKHRoaXMsZSksdGhpcy5fZWxlbWVudD10fXJldHVybiBlLnByb3RvdHlwZS50b2dnbGU9ZnVuY3Rpb24oKXt2YXIgZT0hMCxuPXQodGhpcy5fZWxlbWVudCkuY2xvc2VzdChjLkRBVEFfVE9HR0xFKVswXTtpZihuKXt2YXIgaT10KHRoaXMuX2VsZW1lbnQpLmZpbmQoYy5JTlBVVClbMF07aWYoaSl7aWYoXCJyYWRpb1wiPT09aS50eXBlKWlmKGkuY2hlY2tlZCYmdCh0aGlzLl9lbGVtZW50KS5oYXNDbGFzcyhoLkFDVElWRSkpZT0hMTtlbHNle3ZhciBvPXQobikuZmluZChjLkFDVElWRSlbMF07byYmdChvKS5yZW1vdmVDbGFzcyhoLkFDVElWRSl9ZSYmKGkuY2hlY2tlZD0hdCh0aGlzLl9lbGVtZW50KS5oYXNDbGFzcyhoLkFDVElWRSksdChpKS50cmlnZ2VyKFwiY2hhbmdlXCIpKSxpLmZvY3VzKCl9fXRoaXMuX2VsZW1lbnQuc2V0QXR0cmlidXRlKFwiYXJpYS1wcmVzc2VkXCIsIXQodGhpcy5fZWxlbWVudCkuaGFzQ2xhc3MoaC5BQ1RJVkUpKSxlJiZ0KHRoaXMuX2VsZW1lbnQpLnRvZ2dsZUNsYXNzKGguQUNUSVZFKX0sZS5wcm90b3R5cGUuZGlzcG9zZT1mdW5jdGlvbigpe3QucmVtb3ZlRGF0YSh0aGlzLl9lbGVtZW50LHIpLHRoaXMuX2VsZW1lbnQ9bnVsbH0sZS5falF1ZXJ5SW50ZXJmYWNlPWZ1bmN0aW9uKG4pe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXt2YXIgaT10KHRoaXMpLmRhdGEocik7aXx8KGk9bmV3IGUodGhpcyksdCh0aGlzKS5kYXRhKHIsaSkpLFwidG9nZ2xlXCI9PT1uJiZpW25dKCl9KX0sbyhlLG51bGwsW3trZXk6XCJWRVJTSU9OXCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIGl9fV0pLGV9KCk7cmV0dXJuIHQoZG9jdW1lbnQpLm9uKHUuQ0xJQ0tfREFUQV9BUEksYy5EQVRBX1RPR0dMRV9DQVJST1QsZnVuY3Rpb24oZSl7ZS5wcmV2ZW50RGVmYXVsdCgpO3ZhciBuPWUudGFyZ2V0O3QobikuaGFzQ2xhc3MoaC5CVVRUT04pfHwobj10KG4pLmNsb3Nlc3QoYy5CVVRUT04pKSxkLl9qUXVlcnlJbnRlcmZhY2UuY2FsbCh0KG4pLFwidG9nZ2xlXCIpfSkub24odS5GT0NVU19CTFVSX0RBVEFfQVBJLGMuREFUQV9UT0dHTEVfQ0FSUk9ULGZ1bmN0aW9uKGUpe3ZhciBuPXQoZS50YXJnZXQpLmNsb3Nlc3QoYy5CVVRUT04pWzBdO3QobikudG9nZ2xlQ2xhc3MoaC5GT0NVUywvXmZvY3VzKGluKT8kLy50ZXN0KGUudHlwZSkpfSksdC5mbltlXT1kLl9qUXVlcnlJbnRlcmZhY2UsdC5mbltlXS5Db25zdHJ1Y3Rvcj1kLHQuZm5bZV0ubm9Db25mbGljdD1mdW5jdGlvbigpe3JldHVybiB0LmZuW2VdPWwsZC5falF1ZXJ5SW50ZXJmYWNlfSxkfShqUXVlcnkpLGZ1bmN0aW9uKHQpe3ZhciBlPVwiY2Fyb3VzZWxcIixzPVwiNC4wLjAtYWxwaGEuNlwiLGE9XCJicy5jYXJvdXNlbFwiLGw9XCIuXCIrYSxoPVwiLmRhdGEtYXBpXCIsYz10LmZuW2VdLHU9NjAwLGQ9MzcsZj0zOSxfPXtpbnRlcnZhbDo1ZTMsa2V5Ym9hcmQ6ITAsc2xpZGU6ITEscGF1c2U6XCJob3ZlclwiLHdyYXA6ITB9LGc9e2ludGVydmFsOlwiKG51bWJlcnxib29sZWFuKVwiLGtleWJvYXJkOlwiYm9vbGVhblwiLHNsaWRlOlwiKGJvb2xlYW58c3RyaW5nKVwiLHBhdXNlOlwiKHN0cmluZ3xib29sZWFuKVwiLHdyYXA6XCJib29sZWFuXCJ9LHA9e05FWFQ6XCJuZXh0XCIsUFJFVjpcInByZXZcIixMRUZUOlwibGVmdFwiLFJJR0hUOlwicmlnaHRcIn0sbT17U0xJREU6XCJzbGlkZVwiK2wsU0xJRDpcInNsaWRcIitsLEtFWURPV046XCJrZXlkb3duXCIrbCxNT1VTRUVOVEVSOlwibW91c2VlbnRlclwiK2wsTU9VU0VMRUFWRTpcIm1vdXNlbGVhdmVcIitsLExPQURfREFUQV9BUEk6XCJsb2FkXCIrbCtoLENMSUNLX0RBVEFfQVBJOlwiY2xpY2tcIitsK2h9LEU9e0NBUk9VU0VMOlwiY2Fyb3VzZWxcIixBQ1RJVkU6XCJhY3RpdmVcIixTTElERTpcInNsaWRlXCIsUklHSFQ6XCJjYXJvdXNlbC1pdGVtLXJpZ2h0XCIsTEVGVDpcImNhcm91c2VsLWl0ZW0tbGVmdFwiLE5FWFQ6XCJjYXJvdXNlbC1pdGVtLW5leHRcIixQUkVWOlwiY2Fyb3VzZWwtaXRlbS1wcmV2XCIsSVRFTTpcImNhcm91c2VsLWl0ZW1cIn0sdj17QUNUSVZFOlwiLmFjdGl2ZVwiLEFDVElWRV9JVEVNOlwiLmFjdGl2ZS5jYXJvdXNlbC1pdGVtXCIsSVRFTTpcIi5jYXJvdXNlbC1pdGVtXCIsTkVYVF9QUkVWOlwiLmNhcm91c2VsLWl0ZW0tbmV4dCwgLmNhcm91c2VsLWl0ZW0tcHJldlwiLElORElDQVRPUlM6XCIuY2Fyb3VzZWwtaW5kaWNhdG9yc1wiLERBVEFfU0xJREU6XCJbZGF0YS1zbGlkZV0sIFtkYXRhLXNsaWRlLXRvXVwiLERBVEFfUklERTonW2RhdGEtcmlkZT1cImNhcm91c2VsXCJdJ30sVD1mdW5jdGlvbigpe2Z1bmN0aW9uIGgoZSxpKXtuKHRoaXMsaCksdGhpcy5faXRlbXM9bnVsbCx0aGlzLl9pbnRlcnZhbD1udWxsLHRoaXMuX2FjdGl2ZUVsZW1lbnQ9bnVsbCx0aGlzLl9pc1BhdXNlZD0hMSx0aGlzLl9pc1NsaWRpbmc9ITEsdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyhpKSx0aGlzLl9lbGVtZW50PXQoZSlbMF0sdGhpcy5faW5kaWNhdG9yc0VsZW1lbnQ9dCh0aGlzLl9lbGVtZW50KS5maW5kKHYuSU5ESUNBVE9SUylbMF0sdGhpcy5fYWRkRXZlbnRMaXN0ZW5lcnMoKX1yZXR1cm4gaC5wcm90b3R5cGUubmV4dD1mdW5jdGlvbigpe2lmKHRoaXMuX2lzU2xpZGluZyl0aHJvdyBuZXcgRXJyb3IoXCJDYXJvdXNlbCBpcyBzbGlkaW5nXCIpO3RoaXMuX3NsaWRlKHAuTkVYVCl9LGgucHJvdG90eXBlLm5leHRXaGVuVmlzaWJsZT1mdW5jdGlvbigpe2RvY3VtZW50LmhpZGRlbnx8dGhpcy5uZXh0KCl9LGgucHJvdG90eXBlLnByZXY9ZnVuY3Rpb24oKXtpZih0aGlzLl9pc1NsaWRpbmcpdGhyb3cgbmV3IEVycm9yKFwiQ2Fyb3VzZWwgaXMgc2xpZGluZ1wiKTt0aGlzLl9zbGlkZShwLlBSRVZJT1VTKX0saC5wcm90b3R5cGUucGF1c2U9ZnVuY3Rpb24oZSl7ZXx8KHRoaXMuX2lzUGF1c2VkPSEwKSx0KHRoaXMuX2VsZW1lbnQpLmZpbmQodi5ORVhUX1BSRVYpWzBdJiZyLnN1cHBvcnRzVHJhbnNpdGlvbkVuZCgpJiYoci50cmlnZ2VyVHJhbnNpdGlvbkVuZCh0aGlzLl9lbGVtZW50KSx0aGlzLmN5Y2xlKCEwKSksY2xlYXJJbnRlcnZhbCh0aGlzLl9pbnRlcnZhbCksdGhpcy5faW50ZXJ2YWw9bnVsbH0saC5wcm90b3R5cGUuY3ljbGU9ZnVuY3Rpb24odCl7dHx8KHRoaXMuX2lzUGF1c2VkPSExKSx0aGlzLl9pbnRlcnZhbCYmKGNsZWFySW50ZXJ2YWwodGhpcy5faW50ZXJ2YWwpLHRoaXMuX2ludGVydmFsPW51bGwpLHRoaXMuX2NvbmZpZy5pbnRlcnZhbCYmIXRoaXMuX2lzUGF1c2VkJiYodGhpcy5faW50ZXJ2YWw9c2V0SW50ZXJ2YWwoKGRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZT90aGlzLm5leHRXaGVuVmlzaWJsZTp0aGlzLm5leHQpLmJpbmQodGhpcyksdGhpcy5fY29uZmlnLmludGVydmFsKSl9LGgucHJvdG90eXBlLnRvPWZ1bmN0aW9uKGUpe3ZhciBuPXRoaXM7dGhpcy5fYWN0aXZlRWxlbWVudD10KHRoaXMuX2VsZW1lbnQpLmZpbmQodi5BQ1RJVkVfSVRFTSlbMF07dmFyIGk9dGhpcy5fZ2V0SXRlbUluZGV4KHRoaXMuX2FjdGl2ZUVsZW1lbnQpO2lmKCEoZT50aGlzLl9pdGVtcy5sZW5ndGgtMXx8ZTwwKSl7aWYodGhpcy5faXNTbGlkaW5nKXJldHVybiB2b2lkIHQodGhpcy5fZWxlbWVudCkub25lKG0uU0xJRCxmdW5jdGlvbigpe3JldHVybiBuLnRvKGUpfSk7aWYoaT09PWUpcmV0dXJuIHRoaXMucGF1c2UoKSx2b2lkIHRoaXMuY3ljbGUoKTt2YXIgbz1lPmk/cC5ORVhUOnAuUFJFVklPVVM7dGhpcy5fc2xpZGUobyx0aGlzLl9pdGVtc1tlXSl9fSxoLnByb3RvdHlwZS5kaXNwb3NlPWZ1bmN0aW9uKCl7dCh0aGlzLl9lbGVtZW50KS5vZmYobCksdC5yZW1vdmVEYXRhKHRoaXMuX2VsZW1lbnQsYSksdGhpcy5faXRlbXM9bnVsbCx0aGlzLl9jb25maWc9bnVsbCx0aGlzLl9lbGVtZW50PW51bGwsdGhpcy5faW50ZXJ2YWw9bnVsbCx0aGlzLl9pc1BhdXNlZD1udWxsLHRoaXMuX2lzU2xpZGluZz1udWxsLHRoaXMuX2FjdGl2ZUVsZW1lbnQ9bnVsbCx0aGlzLl9pbmRpY2F0b3JzRWxlbWVudD1udWxsfSxoLnByb3RvdHlwZS5fZ2V0Q29uZmlnPWZ1bmN0aW9uKG4pe3JldHVybiBuPXQuZXh0ZW5kKHt9LF8sbiksci50eXBlQ2hlY2tDb25maWcoZSxuLGcpLG59LGgucHJvdG90eXBlLl9hZGRFdmVudExpc3RlbmVycz1mdW5jdGlvbigpe3ZhciBlPXRoaXM7dGhpcy5fY29uZmlnLmtleWJvYXJkJiZ0KHRoaXMuX2VsZW1lbnQpLm9uKG0uS0VZRE9XTixmdW5jdGlvbih0KXtyZXR1cm4gZS5fa2V5ZG93bih0KX0pLFwiaG92ZXJcIiE9PXRoaXMuX2NvbmZpZy5wYXVzZXx8XCJvbnRvdWNoc3RhcnRcImluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudHx8dCh0aGlzLl9lbGVtZW50KS5vbihtLk1PVVNFRU5URVIsZnVuY3Rpb24odCl7cmV0dXJuIGUucGF1c2UodCl9KS5vbihtLk1PVVNFTEVBVkUsZnVuY3Rpb24odCl7cmV0dXJuIGUuY3ljbGUodCl9KX0saC5wcm90b3R5cGUuX2tleWRvd249ZnVuY3Rpb24odCl7aWYoIS9pbnB1dHx0ZXh0YXJlYS9pLnRlc3QodC50YXJnZXQudGFnTmFtZSkpc3dpdGNoKHQud2hpY2gpe2Nhc2UgZDp0LnByZXZlbnREZWZhdWx0KCksdGhpcy5wcmV2KCk7YnJlYWs7Y2FzZSBmOnQucHJldmVudERlZmF1bHQoKSx0aGlzLm5leHQoKTticmVhaztkZWZhdWx0OnJldHVybn19LGgucHJvdG90eXBlLl9nZXRJdGVtSW5kZXg9ZnVuY3Rpb24oZSl7cmV0dXJuIHRoaXMuX2l0ZW1zPXQubWFrZUFycmF5KHQoZSkucGFyZW50KCkuZmluZCh2LklURU0pKSx0aGlzLl9pdGVtcy5pbmRleE9mKGUpfSxoLnByb3RvdHlwZS5fZ2V0SXRlbUJ5RGlyZWN0aW9uPWZ1bmN0aW9uKHQsZSl7dmFyIG49dD09PXAuTkVYVCxpPXQ9PT1wLlBSRVZJT1VTLG89dGhpcy5fZ2V0SXRlbUluZGV4KGUpLHI9dGhpcy5faXRlbXMubGVuZ3RoLTEscz1pJiYwPT09b3x8biYmbz09PXI7aWYocyYmIXRoaXMuX2NvbmZpZy53cmFwKXJldHVybiBlO3ZhciBhPXQ9PT1wLlBSRVZJT1VTPy0xOjEsbD0obythKSV0aGlzLl9pdGVtcy5sZW5ndGg7cmV0dXJuIGw9PT0tMT90aGlzLl9pdGVtc1t0aGlzLl9pdGVtcy5sZW5ndGgtMV06dGhpcy5faXRlbXNbbF19LGgucHJvdG90eXBlLl90cmlnZ2VyU2xpZGVFdmVudD1mdW5jdGlvbihlLG4pe3ZhciBpPXQuRXZlbnQobS5TTElERSx7cmVsYXRlZFRhcmdldDplLGRpcmVjdGlvbjpufSk7cmV0dXJuIHQodGhpcy5fZWxlbWVudCkudHJpZ2dlcihpKSxpfSxoLnByb3RvdHlwZS5fc2V0QWN0aXZlSW5kaWNhdG9yRWxlbWVudD1mdW5jdGlvbihlKXtpZih0aGlzLl9pbmRpY2F0b3JzRWxlbWVudCl7dCh0aGlzLl9pbmRpY2F0b3JzRWxlbWVudCkuZmluZCh2LkFDVElWRSkucmVtb3ZlQ2xhc3MoRS5BQ1RJVkUpO3ZhciBuPXRoaXMuX2luZGljYXRvcnNFbGVtZW50LmNoaWxkcmVuW3RoaXMuX2dldEl0ZW1JbmRleChlKV07biYmdChuKS5hZGRDbGFzcyhFLkFDVElWRSl9fSxoLnByb3RvdHlwZS5fc2xpZGU9ZnVuY3Rpb24oZSxuKXt2YXIgaT10aGlzLG89dCh0aGlzLl9lbGVtZW50KS5maW5kKHYuQUNUSVZFX0lURU0pWzBdLHM9bnx8byYmdGhpcy5fZ2V0SXRlbUJ5RGlyZWN0aW9uKGUsbyksYT1Cb29sZWFuKHRoaXMuX2ludGVydmFsKSxsPXZvaWQgMCxoPXZvaWQgMCxjPXZvaWQgMDtpZihlPT09cC5ORVhUPyhsPUUuTEVGVCxoPUUuTkVYVCxjPXAuTEVGVCk6KGw9RS5SSUdIVCxoPUUuUFJFVixjPXAuUklHSFQpLHMmJnQocykuaGFzQ2xhc3MoRS5BQ1RJVkUpKXJldHVybiB2b2lkKHRoaXMuX2lzU2xpZGluZz0hMSk7dmFyIGQ9dGhpcy5fdHJpZ2dlclNsaWRlRXZlbnQocyxjKTtpZighZC5pc0RlZmF1bHRQcmV2ZW50ZWQoKSYmbyYmcyl7dGhpcy5faXNTbGlkaW5nPSEwLGEmJnRoaXMucGF1c2UoKSx0aGlzLl9zZXRBY3RpdmVJbmRpY2F0b3JFbGVtZW50KHMpO3ZhciBmPXQuRXZlbnQobS5TTElELHtyZWxhdGVkVGFyZ2V0OnMsZGlyZWN0aW9uOmN9KTtyLnN1cHBvcnRzVHJhbnNpdGlvbkVuZCgpJiZ0KHRoaXMuX2VsZW1lbnQpLmhhc0NsYXNzKEUuU0xJREUpPyh0KHMpLmFkZENsYXNzKGgpLHIucmVmbG93KHMpLHQobykuYWRkQ2xhc3MobCksdChzKS5hZGRDbGFzcyhsKSx0KG8pLm9uZShyLlRSQU5TSVRJT05fRU5ELGZ1bmN0aW9uKCl7dChzKS5yZW1vdmVDbGFzcyhsK1wiIFwiK2gpLmFkZENsYXNzKEUuQUNUSVZFKSx0KG8pLnJlbW92ZUNsYXNzKEUuQUNUSVZFK1wiIFwiK2grXCIgXCIrbCksaS5faXNTbGlkaW5nPSExLHNldFRpbWVvdXQoZnVuY3Rpb24oKXtyZXR1cm4gdChpLl9lbGVtZW50KS50cmlnZ2VyKGYpfSwwKX0pLmVtdWxhdGVUcmFuc2l0aW9uRW5kKHUpKToodChvKS5yZW1vdmVDbGFzcyhFLkFDVElWRSksdChzKS5hZGRDbGFzcyhFLkFDVElWRSksdGhpcy5faXNTbGlkaW5nPSExLHQodGhpcy5fZWxlbWVudCkudHJpZ2dlcihmKSksYSYmdGhpcy5jeWNsZSgpfX0saC5falF1ZXJ5SW50ZXJmYWNlPWZ1bmN0aW9uKGUpe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXt2YXIgbj10KHRoaXMpLmRhdGEoYSksbz10LmV4dGVuZCh7fSxfLHQodGhpcykuZGF0YSgpKTtcIm9iamVjdFwiPT09KFwidW5kZWZpbmVkXCI9PXR5cGVvZiBlP1widW5kZWZpbmVkXCI6aShlKSkmJnQuZXh0ZW5kKG8sZSk7dmFyIHI9XCJzdHJpbmdcIj09dHlwZW9mIGU/ZTpvLnNsaWRlO2lmKG58fChuPW5ldyBoKHRoaXMsbyksdCh0aGlzKS5kYXRhKGEsbikpLFwibnVtYmVyXCI9PXR5cGVvZiBlKW4udG8oZSk7ZWxzZSBpZihcInN0cmluZ1wiPT10eXBlb2Ygcil7aWYodm9pZCAwPT09bltyXSl0aHJvdyBuZXcgRXJyb3IoJ05vIG1ldGhvZCBuYW1lZCBcIicrcisnXCInKTtuW3JdKCl9ZWxzZSBvLmludGVydmFsJiYobi5wYXVzZSgpLG4uY3ljbGUoKSl9KX0saC5fZGF0YUFwaUNsaWNrSGFuZGxlcj1mdW5jdGlvbihlKXt2YXIgbj1yLmdldFNlbGVjdG9yRnJvbUVsZW1lbnQodGhpcyk7aWYobil7dmFyIGk9dChuKVswXTtpZihpJiZ0KGkpLmhhc0NsYXNzKEUuQ0FST1VTRUwpKXt2YXIgbz10LmV4dGVuZCh7fSx0KGkpLmRhdGEoKSx0KHRoaXMpLmRhdGEoKSkscz10aGlzLmdldEF0dHJpYnV0ZShcImRhdGEtc2xpZGUtdG9cIik7cyYmKG8uaW50ZXJ2YWw9ITEpLGguX2pRdWVyeUludGVyZmFjZS5jYWxsKHQoaSksbykscyYmdChpKS5kYXRhKGEpLnRvKHMpLGUucHJldmVudERlZmF1bHQoKX19fSxvKGgsbnVsbCxbe2tleTpcIlZFUlNJT05cIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gc319LHtrZXk6XCJEZWZhdWx0XCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIF99fV0pLGh9KCk7cmV0dXJuIHQoZG9jdW1lbnQpLm9uKG0uQ0xJQ0tfREFUQV9BUEksdi5EQVRBX1NMSURFLFQuX2RhdGFBcGlDbGlja0hhbmRsZXIpLHQod2luZG93KS5vbihtLkxPQURfREFUQV9BUEksZnVuY3Rpb24oKXt0KHYuREFUQV9SSURFKS5lYWNoKGZ1bmN0aW9uKCl7dmFyIGU9dCh0aGlzKTtULl9qUXVlcnlJbnRlcmZhY2UuY2FsbChlLGUuZGF0YSgpKX0pfSksdC5mbltlXT1ULl9qUXVlcnlJbnRlcmZhY2UsdC5mbltlXS5Db25zdHJ1Y3Rvcj1ULHQuZm5bZV0ubm9Db25mbGljdD1mdW5jdGlvbigpe3JldHVybiB0LmZuW2VdPWMsVC5falF1ZXJ5SW50ZXJmYWNlfSxUfShqUXVlcnkpLGZ1bmN0aW9uKHQpe3ZhciBlPVwiY29sbGFwc2VcIixzPVwiNC4wLjAtYWxwaGEuNlwiLGE9XCJicy5jb2xsYXBzZVwiLGw9XCIuXCIrYSxoPVwiLmRhdGEtYXBpXCIsYz10LmZuW2VdLHU9NjAwLGQ9e3RvZ2dsZTohMCxwYXJlbnQ6XCJcIn0sZj17dG9nZ2xlOlwiYm9vbGVhblwiLHBhcmVudDpcInN0cmluZ1wifSxfPXtTSE9XOlwic2hvd1wiK2wsU0hPV046XCJzaG93blwiK2wsSElERTpcImhpZGVcIitsLEhJRERFTjpcImhpZGRlblwiK2wsQ0xJQ0tfREFUQV9BUEk6XCJjbGlja1wiK2wraH0sZz17U0hPVzpcInNob3dcIixDT0xMQVBTRTpcImNvbGxhcHNlXCIsQ09MTEFQU0lORzpcImNvbGxhcHNpbmdcIixDT0xMQVBTRUQ6XCJjb2xsYXBzZWRcIn0scD17V0lEVEg6XCJ3aWR0aFwiLEhFSUdIVDpcImhlaWdodFwifSxtPXtBQ1RJVkVTOlwiLmNhcmQgPiAuc2hvdywgLmNhcmQgPiAuY29sbGFwc2luZ1wiLERBVEFfVE9HR0xFOidbZGF0YS10b2dnbGU9XCJjb2xsYXBzZVwiXSd9LEU9ZnVuY3Rpb24oKXtmdW5jdGlvbiBsKGUsaSl7bih0aGlzLGwpLHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMSx0aGlzLl9lbGVtZW50PWUsdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyhpKSx0aGlzLl90cmlnZ2VyQXJyYXk9dC5tYWtlQXJyYXkodCgnW2RhdGEtdG9nZ2xlPVwiY29sbGFwc2VcIl1baHJlZj1cIiMnK2UuaWQrJ1wiXSwnKygnW2RhdGEtdG9nZ2xlPVwiY29sbGFwc2VcIl1bZGF0YS10YXJnZXQ9XCIjJytlLmlkKydcIl0nKSkpLHRoaXMuX3BhcmVudD10aGlzLl9jb25maWcucGFyZW50P3RoaXMuX2dldFBhcmVudCgpOm51bGwsdGhpcy5fY29uZmlnLnBhcmVudHx8dGhpcy5fYWRkQXJpYUFuZENvbGxhcHNlZENsYXNzKHRoaXMuX2VsZW1lbnQsdGhpcy5fdHJpZ2dlckFycmF5KSx0aGlzLl9jb25maWcudG9nZ2xlJiZ0aGlzLnRvZ2dsZSgpfXJldHVybiBsLnByb3RvdHlwZS50b2dnbGU9ZnVuY3Rpb24oKXt0KHRoaXMuX2VsZW1lbnQpLmhhc0NsYXNzKGcuU0hPVyk/dGhpcy5oaWRlKCk6dGhpcy5zaG93KCl9LGwucHJvdG90eXBlLnNob3c9ZnVuY3Rpb24oKXt2YXIgZT10aGlzO2lmKHRoaXMuX2lzVHJhbnNpdGlvbmluZyl0aHJvdyBuZXcgRXJyb3IoXCJDb2xsYXBzZSBpcyB0cmFuc2l0aW9uaW5nXCIpO2lmKCF0KHRoaXMuX2VsZW1lbnQpLmhhc0NsYXNzKGcuU0hPVykpe3ZhciBuPXZvaWQgMCxpPXZvaWQgMDtpZih0aGlzLl9wYXJlbnQmJihuPXQubWFrZUFycmF5KHQodGhpcy5fcGFyZW50KS5maW5kKG0uQUNUSVZFUykpLG4ubGVuZ3RofHwobj1udWxsKSksIShuJiYoaT10KG4pLmRhdGEoYSksaSYmaS5faXNUcmFuc2l0aW9uaW5nKSkpe3ZhciBvPXQuRXZlbnQoXy5TSE9XKTtpZih0KHRoaXMuX2VsZW1lbnQpLnRyaWdnZXIobyksIW8uaXNEZWZhdWx0UHJldmVudGVkKCkpe24mJihsLl9qUXVlcnlJbnRlcmZhY2UuY2FsbCh0KG4pLFwiaGlkZVwiKSxpfHx0KG4pLmRhdGEoYSxudWxsKSk7dmFyIHM9dGhpcy5fZ2V0RGltZW5zaW9uKCk7dCh0aGlzLl9lbGVtZW50KS5yZW1vdmVDbGFzcyhnLkNPTExBUFNFKS5hZGRDbGFzcyhnLkNPTExBUFNJTkcpLHRoaXMuX2VsZW1lbnQuc3R5bGVbc109MCx0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIiwhMCksdGhpcy5fdHJpZ2dlckFycmF5Lmxlbmd0aCYmdCh0aGlzLl90cmlnZ2VyQXJyYXkpLnJlbW92ZUNsYXNzKGcuQ09MTEFQU0VEKS5hdHRyKFwiYXJpYS1leHBhbmRlZFwiLCEwKSx0aGlzLnNldFRyYW5zaXRpb25pbmcoITApO3ZhciBoPWZ1bmN0aW9uKCl7dChlLl9lbGVtZW50KS5yZW1vdmVDbGFzcyhnLkNPTExBUFNJTkcpLmFkZENsYXNzKGcuQ09MTEFQU0UpLmFkZENsYXNzKGcuU0hPVyksZS5fZWxlbWVudC5zdHlsZVtzXT1cIlwiLGUuc2V0VHJhbnNpdGlvbmluZyghMSksdChlLl9lbGVtZW50KS50cmlnZ2VyKF8uU0hPV04pfTtpZighci5zdXBwb3J0c1RyYW5zaXRpb25FbmQoKSlyZXR1cm4gdm9pZCBoKCk7dmFyIGM9c1swXS50b1VwcGVyQ2FzZSgpK3Muc2xpY2UoMSksZD1cInNjcm9sbFwiK2M7dCh0aGlzLl9lbGVtZW50KS5vbmUoci5UUkFOU0lUSU9OX0VORCxoKS5lbXVsYXRlVHJhbnNpdGlvbkVuZCh1KSx0aGlzLl9lbGVtZW50LnN0eWxlW3NdPXRoaXMuX2VsZW1lbnRbZF0rXCJweFwifX19fSxsLnByb3RvdHlwZS5oaWRlPWZ1bmN0aW9uKCl7dmFyIGU9dGhpcztpZih0aGlzLl9pc1RyYW5zaXRpb25pbmcpdGhyb3cgbmV3IEVycm9yKFwiQ29sbGFwc2UgaXMgdHJhbnNpdGlvbmluZ1wiKTtpZih0KHRoaXMuX2VsZW1lbnQpLmhhc0NsYXNzKGcuU0hPVykpe3ZhciBuPXQuRXZlbnQoXy5ISURFKTtpZih0KHRoaXMuX2VsZW1lbnQpLnRyaWdnZXIobiksIW4uaXNEZWZhdWx0UHJldmVudGVkKCkpe3ZhciBpPXRoaXMuX2dldERpbWVuc2lvbigpLG89aT09PXAuV0lEVEg/XCJvZmZzZXRXaWR0aFwiOlwib2Zmc2V0SGVpZ2h0XCI7dGhpcy5fZWxlbWVudC5zdHlsZVtpXT10aGlzLl9lbGVtZW50W29dK1wicHhcIixyLnJlZmxvdyh0aGlzLl9lbGVtZW50KSx0KHRoaXMuX2VsZW1lbnQpLmFkZENsYXNzKGcuQ09MTEFQU0lORykucmVtb3ZlQ2xhc3MoZy5DT0xMQVBTRSkucmVtb3ZlQ2xhc3MoZy5TSE9XKSx0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIiwhMSksdGhpcy5fdHJpZ2dlckFycmF5Lmxlbmd0aCYmdCh0aGlzLl90cmlnZ2VyQXJyYXkpLmFkZENsYXNzKGcuQ09MTEFQU0VEKS5hdHRyKFwiYXJpYS1leHBhbmRlZFwiLCExKSx0aGlzLnNldFRyYW5zaXRpb25pbmcoITApO3ZhciBzPWZ1bmN0aW9uKCl7ZS5zZXRUcmFuc2l0aW9uaW5nKCExKSx0KGUuX2VsZW1lbnQpLnJlbW92ZUNsYXNzKGcuQ09MTEFQU0lORykuYWRkQ2xhc3MoZy5DT0xMQVBTRSkudHJpZ2dlcihfLkhJRERFTil9O3JldHVybiB0aGlzLl9lbGVtZW50LnN0eWxlW2ldPVwiXCIsci5zdXBwb3J0c1RyYW5zaXRpb25FbmQoKT92b2lkIHQodGhpcy5fZWxlbWVudCkub25lKHIuVFJBTlNJVElPTl9FTkQscykuZW11bGF0ZVRyYW5zaXRpb25FbmQodSk6dm9pZCBzKCl9fX0sbC5wcm90b3R5cGUuc2V0VHJhbnNpdGlvbmluZz1mdW5jdGlvbih0KXt0aGlzLl9pc1RyYW5zaXRpb25pbmc9dH0sbC5wcm90b3R5cGUuZGlzcG9zZT1mdW5jdGlvbigpe3QucmVtb3ZlRGF0YSh0aGlzLl9lbGVtZW50LGEpLHRoaXMuX2NvbmZpZz1udWxsLHRoaXMuX3BhcmVudD1udWxsLHRoaXMuX2VsZW1lbnQ9bnVsbCx0aGlzLl90cmlnZ2VyQXJyYXk9bnVsbCx0aGlzLl9pc1RyYW5zaXRpb25pbmc9bnVsbH0sbC5wcm90b3R5cGUuX2dldENvbmZpZz1mdW5jdGlvbihuKXtyZXR1cm4gbj10LmV4dGVuZCh7fSxkLG4pLG4udG9nZ2xlPUJvb2xlYW4obi50b2dnbGUpLHIudHlwZUNoZWNrQ29uZmlnKGUsbixmKSxufSxsLnByb3RvdHlwZS5fZ2V0RGltZW5zaW9uPWZ1bmN0aW9uKCl7dmFyIGU9dCh0aGlzLl9lbGVtZW50KS5oYXNDbGFzcyhwLldJRFRIKTtyZXR1cm4gZT9wLldJRFRIOnAuSEVJR0hUfSxsLnByb3RvdHlwZS5fZ2V0UGFyZW50PWZ1bmN0aW9uKCl7dmFyIGU9dGhpcyxuPXQodGhpcy5fY29uZmlnLnBhcmVudClbMF0saT0nW2RhdGEtdG9nZ2xlPVwiY29sbGFwc2VcIl1bZGF0YS1wYXJlbnQ9XCInK3RoaXMuX2NvbmZpZy5wYXJlbnQrJ1wiXSc7cmV0dXJuIHQobikuZmluZChpKS5lYWNoKGZ1bmN0aW9uKHQsbil7ZS5fYWRkQXJpYUFuZENvbGxhcHNlZENsYXNzKGwuX2dldFRhcmdldEZyb21FbGVtZW50KG4pLFtuXSl9KSxufSxsLnByb3RvdHlwZS5fYWRkQXJpYUFuZENvbGxhcHNlZENsYXNzPWZ1bmN0aW9uKGUsbil7aWYoZSl7dmFyIGk9dChlKS5oYXNDbGFzcyhnLlNIT1cpO2Uuc2V0QXR0cmlidXRlKFwiYXJpYS1leHBhbmRlZFwiLGkpLG4ubGVuZ3RoJiZ0KG4pLnRvZ2dsZUNsYXNzKGcuQ09MTEFQU0VELCFpKS5hdHRyKFwiYXJpYS1leHBhbmRlZFwiLGkpfX0sbC5fZ2V0VGFyZ2V0RnJvbUVsZW1lbnQ9ZnVuY3Rpb24oZSl7dmFyIG49ci5nZXRTZWxlY3RvckZyb21FbGVtZW50KGUpO3JldHVybiBuP3QobilbMF06bnVsbH0sbC5falF1ZXJ5SW50ZXJmYWNlPWZ1bmN0aW9uKGUpe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXt2YXIgbj10KHRoaXMpLG89bi5kYXRhKGEpLHI9dC5leHRlbmQoe30sZCxuLmRhdGEoKSxcIm9iamVjdFwiPT09KFwidW5kZWZpbmVkXCI9PXR5cGVvZiBlP1widW5kZWZpbmVkXCI6aShlKSkmJmUpO2lmKCFvJiZyLnRvZ2dsZSYmL3Nob3d8aGlkZS8udGVzdChlKSYmKHIudG9nZ2xlPSExKSxvfHwobz1uZXcgbCh0aGlzLHIpLG4uZGF0YShhLG8pKSxcInN0cmluZ1wiPT10eXBlb2YgZSl7aWYodm9pZCAwPT09b1tlXSl0aHJvdyBuZXcgRXJyb3IoJ05vIG1ldGhvZCBuYW1lZCBcIicrZSsnXCInKTtvW2VdKCl9fSl9LG8obCxudWxsLFt7a2V5OlwiVkVSU0lPTlwiLGdldDpmdW5jdGlvbigpe3JldHVybiBzfX0se2tleTpcIkRlZmF1bHRcIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gZH19XSksbH0oKTtyZXR1cm4gdChkb2N1bWVudCkub24oXy5DTElDS19EQVRBX0FQSSxtLkRBVEFfVE9HR0xFLGZ1bmN0aW9uKGUpe2UucHJldmVudERlZmF1bHQoKTt2YXIgbj1FLl9nZXRUYXJnZXRGcm9tRWxlbWVudCh0aGlzKSxpPXQobikuZGF0YShhKSxvPWk/XCJ0b2dnbGVcIjp0KHRoaXMpLmRhdGEoKTtFLl9qUXVlcnlJbnRlcmZhY2UuY2FsbCh0KG4pLG8pfSksdC5mbltlXT1FLl9qUXVlcnlJbnRlcmZhY2UsdC5mbltlXS5Db25zdHJ1Y3Rvcj1FLHQuZm5bZV0ubm9Db25mbGljdD1mdW5jdGlvbigpe3JldHVybiB0LmZuW2VdPWMsRS5falF1ZXJ5SW50ZXJmYWNlfSxFfShqUXVlcnkpLGZ1bmN0aW9uKHQpe3ZhciBlPVwiZHJvcGRvd25cIixpPVwiNC4wLjAtYWxwaGEuNlwiLHM9XCJicy5kcm9wZG93blwiLGE9XCIuXCIrcyxsPVwiLmRhdGEtYXBpXCIsaD10LmZuW2VdLGM9MjcsdT0zOCxkPTQwLGY9MyxfPXtISURFOlwiaGlkZVwiK2EsSElEREVOOlwiaGlkZGVuXCIrYSxTSE9XOlwic2hvd1wiK2EsU0hPV046XCJzaG93blwiK2EsQ0xJQ0s6XCJjbGlja1wiK2EsQ0xJQ0tfREFUQV9BUEk6XCJjbGlja1wiK2ErbCxGT0NVU0lOX0RBVEFfQVBJOlwiZm9jdXNpblwiK2ErbCxLRVlET1dOX0RBVEFfQVBJOlwia2V5ZG93blwiK2ErbH0sZz17QkFDS0RST1A6XCJkcm9wZG93bi1iYWNrZHJvcFwiLERJU0FCTEVEOlwiZGlzYWJsZWRcIixTSE9XOlwic2hvd1wifSxwPXtCQUNLRFJPUDpcIi5kcm9wZG93bi1iYWNrZHJvcFwiLERBVEFfVE9HR0xFOidbZGF0YS10b2dnbGU9XCJkcm9wZG93blwiXScsRk9STV9DSElMRDpcIi5kcm9wZG93biBmb3JtXCIsUk9MRV9NRU5VOidbcm9sZT1cIm1lbnVcIl0nLFJPTEVfTElTVEJPWDonW3JvbGU9XCJsaXN0Ym94XCJdJyxOQVZCQVJfTkFWOlwiLm5hdmJhci1uYXZcIixWSVNJQkxFX0lURU1TOidbcm9sZT1cIm1lbnVcIl0gbGk6bm90KC5kaXNhYmxlZCkgYSwgW3JvbGU9XCJsaXN0Ym94XCJdIGxpOm5vdCguZGlzYWJsZWQpIGEnfSxtPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gZSh0KXtuKHRoaXMsZSksdGhpcy5fZWxlbWVudD10LHRoaXMuX2FkZEV2ZW50TGlzdGVuZXJzKCl9cmV0dXJuIGUucHJvdG90eXBlLnRvZ2dsZT1mdW5jdGlvbigpe2lmKHRoaXMuZGlzYWJsZWR8fHQodGhpcykuaGFzQ2xhc3MoZy5ESVNBQkxFRCkpcmV0dXJuITE7dmFyIG49ZS5fZ2V0UGFyZW50RnJvbUVsZW1lbnQodGhpcyksaT10KG4pLmhhc0NsYXNzKGcuU0hPVyk7aWYoZS5fY2xlYXJNZW51cygpLGkpcmV0dXJuITE7aWYoXCJvbnRvdWNoc3RhcnRcImluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCYmIXQobikuY2xvc2VzdChwLk5BVkJBUl9OQVYpLmxlbmd0aCl7dmFyIG89ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtvLmNsYXNzTmFtZT1nLkJBQ0tEUk9QLHQobykuaW5zZXJ0QmVmb3JlKHRoaXMpLHQobykub24oXCJjbGlja1wiLGUuX2NsZWFyTWVudXMpfXZhciByPXtyZWxhdGVkVGFyZ2V0OnRoaXN9LHM9dC5FdmVudChfLlNIT1cscik7cmV0dXJuIHQobikudHJpZ2dlcihzKSwhcy5pc0RlZmF1bHRQcmV2ZW50ZWQoKSYmKHRoaXMuZm9jdXMoKSx0aGlzLnNldEF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIiwhMCksdChuKS50b2dnbGVDbGFzcyhnLlNIT1cpLHQobikudHJpZ2dlcih0LkV2ZW50KF8uU0hPV04scikpLCExKX0sZS5wcm90b3R5cGUuZGlzcG9zZT1mdW5jdGlvbigpe3QucmVtb3ZlRGF0YSh0aGlzLl9lbGVtZW50LHMpLHQodGhpcy5fZWxlbWVudCkub2ZmKGEpLHRoaXMuX2VsZW1lbnQ9bnVsbH0sZS5wcm90b3R5cGUuX2FkZEV2ZW50TGlzdGVuZXJzPWZ1bmN0aW9uKCl7dCh0aGlzLl9lbGVtZW50KS5vbihfLkNMSUNLLHRoaXMudG9nZ2xlKX0sZS5falF1ZXJ5SW50ZXJmYWNlPWZ1bmN0aW9uKG4pe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXt2YXIgaT10KHRoaXMpLmRhdGEocyk7aWYoaXx8KGk9bmV3IGUodGhpcyksdCh0aGlzKS5kYXRhKHMsaSkpLFwic3RyaW5nXCI9PXR5cGVvZiBuKXtpZih2b2lkIDA9PT1pW25dKXRocm93IG5ldyBFcnJvcignTm8gbWV0aG9kIG5hbWVkIFwiJytuKydcIicpO2lbbl0uY2FsbCh0aGlzKX19KX0sZS5fY2xlYXJNZW51cz1mdW5jdGlvbihuKXtpZighbnx8bi53aGljaCE9PWYpe3ZhciBpPXQocC5CQUNLRFJPUClbMF07aSYmaS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGkpO2Zvcih2YXIgbz10Lm1ha2VBcnJheSh0KHAuREFUQV9UT0dHTEUpKSxyPTA7cjxvLmxlbmd0aDtyKyspe3ZhciBzPWUuX2dldFBhcmVudEZyb21FbGVtZW50KG9bcl0pLGE9e3JlbGF0ZWRUYXJnZXQ6b1tyXX07aWYodChzKS5oYXNDbGFzcyhnLlNIT1cpJiYhKG4mJihcImNsaWNrXCI9PT1uLnR5cGUmJi9pbnB1dHx0ZXh0YXJlYS9pLnRlc3Qobi50YXJnZXQudGFnTmFtZSl8fFwiZm9jdXNpblwiPT09bi50eXBlKSYmdC5jb250YWlucyhzLG4udGFyZ2V0KSkpe3ZhciBsPXQuRXZlbnQoXy5ISURFLGEpO3QocykudHJpZ2dlcihsKSxsLmlzRGVmYXVsdFByZXZlbnRlZCgpfHwob1tyXS5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsXCJmYWxzZVwiKSx0KHMpLnJlbW92ZUNsYXNzKGcuU0hPVykudHJpZ2dlcih0LkV2ZW50KF8uSElEREVOLGEpKSl9fX19LGUuX2dldFBhcmVudEZyb21FbGVtZW50PWZ1bmN0aW9uKGUpe3ZhciBuPXZvaWQgMCxpPXIuZ2V0U2VsZWN0b3JGcm9tRWxlbWVudChlKTtyZXR1cm4gaSYmKG49dChpKVswXSksbnx8ZS5wYXJlbnROb2RlfSxlLl9kYXRhQXBpS2V5ZG93bkhhbmRsZXI9ZnVuY3Rpb24obil7aWYoLygzOHw0MHwyN3wzMikvLnRlc3Qobi53aGljaCkmJiEvaW5wdXR8dGV4dGFyZWEvaS50ZXN0KG4udGFyZ2V0LnRhZ05hbWUpJiYobi5wcmV2ZW50RGVmYXVsdCgpLG4uc3RvcFByb3BhZ2F0aW9uKCksIXRoaXMuZGlzYWJsZWQmJiF0KHRoaXMpLmhhc0NsYXNzKGcuRElTQUJMRUQpKSl7dmFyIGk9ZS5fZ2V0UGFyZW50RnJvbUVsZW1lbnQodGhpcyksbz10KGkpLmhhc0NsYXNzKGcuU0hPVyk7aWYoIW8mJm4ud2hpY2ghPT1jfHxvJiZuLndoaWNoPT09Yyl7aWYobi53aGljaD09PWMpe3ZhciByPXQoaSkuZmluZChwLkRBVEFfVE9HR0xFKVswXTt0KHIpLnRyaWdnZXIoXCJmb2N1c1wiKX1yZXR1cm4gdm9pZCB0KHRoaXMpLnRyaWdnZXIoXCJjbGlja1wiKX12YXIgcz10KGkpLmZpbmQocC5WSVNJQkxFX0lURU1TKS5nZXQoKTtpZihzLmxlbmd0aCl7dmFyIGE9cy5pbmRleE9mKG4udGFyZ2V0KTtuLndoaWNoPT09dSYmYT4wJiZhLS0sbi53aGljaD09PWQmJmE8cy5sZW5ndGgtMSYmYSsrLGE8MCYmKGE9MCksc1thXS5mb2N1cygpfX19LG8oZSxudWxsLFt7a2V5OlwiVkVSU0lPTlwiLGdldDpmdW5jdGlvbigpe3JldHVybiBpfX1dKSxlfSgpO3JldHVybiB0KGRvY3VtZW50KS5vbihfLktFWURPV05fREFUQV9BUEkscC5EQVRBX1RPR0dMRSxtLl9kYXRhQXBpS2V5ZG93bkhhbmRsZXIpLm9uKF8uS0VZRE9XTl9EQVRBX0FQSSxwLlJPTEVfTUVOVSxtLl9kYXRhQXBpS2V5ZG93bkhhbmRsZXIpLm9uKF8uS0VZRE9XTl9EQVRBX0FQSSxwLlJPTEVfTElTVEJPWCxtLl9kYXRhQXBpS2V5ZG93bkhhbmRsZXIpLm9uKF8uQ0xJQ0tfREFUQV9BUEkrXCIgXCIrXy5GT0NVU0lOX0RBVEFfQVBJLG0uX2NsZWFyTWVudXMpLm9uKF8uQ0xJQ0tfREFUQV9BUEkscC5EQVRBX1RPR0dMRSxtLnByb3RvdHlwZS50b2dnbGUpLm9uKF8uQ0xJQ0tfREFUQV9BUEkscC5GT1JNX0NISUxELGZ1bmN0aW9uKHQpe3Quc3RvcFByb3BhZ2F0aW9uKCl9KSx0LmZuW2VdPW0uX2pRdWVyeUludGVyZmFjZSx0LmZuW2VdLkNvbnN0cnVjdG9yPW0sdC5mbltlXS5ub0NvbmZsaWN0PWZ1bmN0aW9uKCl7cmV0dXJuIHQuZm5bZV09aCxtLl9qUXVlcnlJbnRlcmZhY2V9LG19KGpRdWVyeSksZnVuY3Rpb24odCl7dmFyIGU9XCJtb2RhbFwiLHM9XCI0LjAuMC1hbHBoYS42XCIsYT1cImJzLm1vZGFsXCIsbD1cIi5cIithLGg9XCIuZGF0YS1hcGlcIixjPXQuZm5bZV0sdT0zMDAsZD0xNTAsZj0yNyxfPXtiYWNrZHJvcDohMCxrZXlib2FyZDohMCxmb2N1czohMCxzaG93OiEwfSxnPXtiYWNrZHJvcDpcIihib29sZWFufHN0cmluZylcIixrZXlib2FyZDpcImJvb2xlYW5cIixmb2N1czpcImJvb2xlYW5cIixzaG93OlwiYm9vbGVhblwifSxwPXtISURFOlwiaGlkZVwiK2wsSElEREVOOlwiaGlkZGVuXCIrbCxTSE9XOlwic2hvd1wiK2wsU0hPV046XCJzaG93blwiK2wsRk9DVVNJTjpcImZvY3VzaW5cIitsLFJFU0laRTpcInJlc2l6ZVwiK2wsQ0xJQ0tfRElTTUlTUzpcImNsaWNrLmRpc21pc3NcIitsLEtFWURPV05fRElTTUlTUzpcImtleWRvd24uZGlzbWlzc1wiK2wsTU9VU0VVUF9ESVNNSVNTOlwibW91c2V1cC5kaXNtaXNzXCIrbCxNT1VTRURPV05fRElTTUlTUzpcIm1vdXNlZG93bi5kaXNtaXNzXCIrbCxDTElDS19EQVRBX0FQSTpcImNsaWNrXCIrbCtofSxtPXtTQ1JPTExCQVJfTUVBU1VSRVI6XCJtb2RhbC1zY3JvbGxiYXItbWVhc3VyZVwiLEJBQ0tEUk9QOlwibW9kYWwtYmFja2Ryb3BcIixPUEVOOlwibW9kYWwtb3BlblwiLEZBREU6XCJmYWRlXCIsU0hPVzpcInNob3dcIn0sRT17RElBTE9HOlwiLm1vZGFsLWRpYWxvZ1wiLERBVEFfVE9HR0xFOidbZGF0YS10b2dnbGU9XCJtb2RhbFwiXScsREFUQV9ESVNNSVNTOidbZGF0YS1kaXNtaXNzPVwibW9kYWxcIl0nLEZJWEVEX0NPTlRFTlQ6XCIuZml4ZWQtdG9wLCAuZml4ZWQtYm90dG9tLCAuaXMtZml4ZWQsIC5zdGlja3ktdG9wXCJ9LHY9ZnVuY3Rpb24oKXtmdW5jdGlvbiBoKGUsaSl7bih0aGlzLGgpLHRoaXMuX2NvbmZpZz10aGlzLl9nZXRDb25maWcoaSksdGhpcy5fZWxlbWVudD1lLHRoaXMuX2RpYWxvZz10KGUpLmZpbmQoRS5ESUFMT0cpWzBdLHRoaXMuX2JhY2tkcm9wPW51bGwsdGhpcy5faXNTaG93bj0hMSx0aGlzLl9pc0JvZHlPdmVyZmxvd2luZz0hMSx0aGlzLl9pZ25vcmVCYWNrZHJvcENsaWNrPSExLHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMSx0aGlzLl9vcmlnaW5hbEJvZHlQYWRkaW5nPTAsdGhpcy5fc2Nyb2xsYmFyV2lkdGg9MH1yZXR1cm4gaC5wcm90b3R5cGUudG9nZ2xlPWZ1bmN0aW9uKHQpe3JldHVybiB0aGlzLl9pc1Nob3duP3RoaXMuaGlkZSgpOnRoaXMuc2hvdyh0KX0saC5wcm90b3R5cGUuc2hvdz1mdW5jdGlvbihlKXt2YXIgbj10aGlzO2lmKHRoaXMuX2lzVHJhbnNpdGlvbmluZyl0aHJvdyBuZXcgRXJyb3IoXCJNb2RhbCBpcyB0cmFuc2l0aW9uaW5nXCIpO3Iuc3VwcG9ydHNUcmFuc2l0aW9uRW5kKCkmJnQodGhpcy5fZWxlbWVudCkuaGFzQ2xhc3MobS5GQURFKSYmKHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMCk7dmFyIGk9dC5FdmVudChwLlNIT1cse3JlbGF0ZWRUYXJnZXQ6ZX0pO3QodGhpcy5fZWxlbWVudCkudHJpZ2dlcihpKSx0aGlzLl9pc1Nob3dufHxpLmlzRGVmYXVsdFByZXZlbnRlZCgpfHwodGhpcy5faXNTaG93bj0hMCx0aGlzLl9jaGVja1Njcm9sbGJhcigpLHRoaXMuX3NldFNjcm9sbGJhcigpLHQoZG9jdW1lbnQuYm9keSkuYWRkQ2xhc3MobS5PUEVOKSx0aGlzLl9zZXRFc2NhcGVFdmVudCgpLHRoaXMuX3NldFJlc2l6ZUV2ZW50KCksdCh0aGlzLl9lbGVtZW50KS5vbihwLkNMSUNLX0RJU01JU1MsRS5EQVRBX0RJU01JU1MsZnVuY3Rpb24odCl7cmV0dXJuIG4uaGlkZSh0KX0pLHQodGhpcy5fZGlhbG9nKS5vbihwLk1PVVNFRE9XTl9ESVNNSVNTLGZ1bmN0aW9uKCl7dChuLl9lbGVtZW50KS5vbmUocC5NT1VTRVVQX0RJU01JU1MsZnVuY3Rpb24oZSl7dChlLnRhcmdldCkuaXMobi5fZWxlbWVudCkmJihuLl9pZ25vcmVCYWNrZHJvcENsaWNrPSEwKX0pfSksdGhpcy5fc2hvd0JhY2tkcm9wKGZ1bmN0aW9uKCl7cmV0dXJuIG4uX3Nob3dFbGVtZW50KGUpfSkpfSxoLnByb3RvdHlwZS5oaWRlPWZ1bmN0aW9uKGUpe3ZhciBuPXRoaXM7aWYoZSYmZS5wcmV2ZW50RGVmYXVsdCgpLHRoaXMuX2lzVHJhbnNpdGlvbmluZyl0aHJvdyBuZXcgRXJyb3IoXCJNb2RhbCBpcyB0cmFuc2l0aW9uaW5nXCIpO3ZhciBpPXIuc3VwcG9ydHNUcmFuc2l0aW9uRW5kKCkmJnQodGhpcy5fZWxlbWVudCkuaGFzQ2xhc3MobS5GQURFKTtpJiYodGhpcy5faXNUcmFuc2l0aW9uaW5nPSEwKTt2YXIgbz10LkV2ZW50KHAuSElERSk7dCh0aGlzLl9lbGVtZW50KS50cmlnZ2VyKG8pLHRoaXMuX2lzU2hvd24mJiFvLmlzRGVmYXVsdFByZXZlbnRlZCgpJiYodGhpcy5faXNTaG93bj0hMSx0aGlzLl9zZXRFc2NhcGVFdmVudCgpLHRoaXMuX3NldFJlc2l6ZUV2ZW50KCksdChkb2N1bWVudCkub2ZmKHAuRk9DVVNJTiksdCh0aGlzLl9lbGVtZW50KS5yZW1vdmVDbGFzcyhtLlNIT1cpLHQodGhpcy5fZWxlbWVudCkub2ZmKHAuQ0xJQ0tfRElTTUlTUyksdCh0aGlzLl9kaWFsb2cpLm9mZihwLk1PVVNFRE9XTl9ESVNNSVNTKSxpP3QodGhpcy5fZWxlbWVudCkub25lKHIuVFJBTlNJVElPTl9FTkQsZnVuY3Rpb24odCl7cmV0dXJuIG4uX2hpZGVNb2RhbCh0KX0pLmVtdWxhdGVUcmFuc2l0aW9uRW5kKHUpOnRoaXMuX2hpZGVNb2RhbCgpKX0saC5wcm90b3R5cGUuZGlzcG9zZT1mdW5jdGlvbigpe3QucmVtb3ZlRGF0YSh0aGlzLl9lbGVtZW50LGEpLHQod2luZG93LGRvY3VtZW50LHRoaXMuX2VsZW1lbnQsdGhpcy5fYmFja2Ryb3ApLm9mZihsKSx0aGlzLl9jb25maWc9bnVsbCx0aGlzLl9lbGVtZW50PW51bGwsdGhpcy5fZGlhbG9nPW51bGwsdGhpcy5fYmFja2Ryb3A9bnVsbCx0aGlzLl9pc1Nob3duPW51bGwsdGhpcy5faXNCb2R5T3ZlcmZsb3dpbmc9bnVsbCx0aGlzLl9pZ25vcmVCYWNrZHJvcENsaWNrPW51bGwsdGhpcy5fb3JpZ2luYWxCb2R5UGFkZGluZz1udWxsLHRoaXMuX3Njcm9sbGJhcldpZHRoPW51bGx9LGgucHJvdG90eXBlLl9nZXRDb25maWc9ZnVuY3Rpb24obil7cmV0dXJuIG49dC5leHRlbmQoe30sXyxuKSxyLnR5cGVDaGVja0NvbmZpZyhlLG4sZyksbn0saC5wcm90b3R5cGUuX3Nob3dFbGVtZW50PWZ1bmN0aW9uKGUpe3ZhciBuPXRoaXMsaT1yLnN1cHBvcnRzVHJhbnNpdGlvbkVuZCgpJiZ0KHRoaXMuX2VsZW1lbnQpLmhhc0NsYXNzKG0uRkFERSk7dGhpcy5fZWxlbWVudC5wYXJlbnROb2RlJiZ0aGlzLl9lbGVtZW50LnBhcmVudE5vZGUubm9kZVR5cGU9PT1Ob2RlLkVMRU1FTlRfTk9ERXx8ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0aGlzLl9lbGVtZW50KSx0aGlzLl9lbGVtZW50LnN0eWxlLmRpc3BsYXk9XCJibG9ja1wiLHRoaXMuX2VsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiksdGhpcy5fZWxlbWVudC5zY3JvbGxUb3A9MCxpJiZyLnJlZmxvdyh0aGlzLl9lbGVtZW50KSx0KHRoaXMuX2VsZW1lbnQpLmFkZENsYXNzKG0uU0hPVyksdGhpcy5fY29uZmlnLmZvY3VzJiZ0aGlzLl9lbmZvcmNlRm9jdXMoKTt2YXIgbz10LkV2ZW50KHAuU0hPV04se3JlbGF0ZWRUYXJnZXQ6ZX0pLHM9ZnVuY3Rpb24oKXtuLl9jb25maWcuZm9jdXMmJm4uX2VsZW1lbnQuZm9jdXMoKSxuLl9pc1RyYW5zaXRpb25pbmc9ITEsdChuLl9lbGVtZW50KS50cmlnZ2VyKG8pfTtpP3QodGhpcy5fZGlhbG9nKS5vbmUoci5UUkFOU0lUSU9OX0VORCxzKS5lbXVsYXRlVHJhbnNpdGlvbkVuZCh1KTpzKCl9LGgucHJvdG90eXBlLl9lbmZvcmNlRm9jdXM9ZnVuY3Rpb24oKXt2YXIgZT10aGlzO3QoZG9jdW1lbnQpLm9mZihwLkZPQ1VTSU4pLm9uKHAuRk9DVVNJTixmdW5jdGlvbihuKXtkb2N1bWVudD09PW4udGFyZ2V0fHxlLl9lbGVtZW50PT09bi50YXJnZXR8fHQoZS5fZWxlbWVudCkuaGFzKG4udGFyZ2V0KS5sZW5ndGh8fGUuX2VsZW1lbnQuZm9jdXMoKX0pfSxoLnByb3RvdHlwZS5fc2V0RXNjYXBlRXZlbnQ9ZnVuY3Rpb24oKXt2YXIgZT10aGlzO3RoaXMuX2lzU2hvd24mJnRoaXMuX2NvbmZpZy5rZXlib2FyZD90KHRoaXMuX2VsZW1lbnQpLm9uKHAuS0VZRE9XTl9ESVNNSVNTLGZ1bmN0aW9uKHQpe3Qud2hpY2g9PT1mJiZlLmhpZGUoKX0pOnRoaXMuX2lzU2hvd258fHQodGhpcy5fZWxlbWVudCkub2ZmKHAuS0VZRE9XTl9ESVNNSVNTKX0saC5wcm90b3R5cGUuX3NldFJlc2l6ZUV2ZW50PWZ1bmN0aW9uKCl7dmFyIGU9dGhpczt0aGlzLl9pc1Nob3duP3Qod2luZG93KS5vbihwLlJFU0laRSxmdW5jdGlvbih0KXtyZXR1cm4gZS5faGFuZGxlVXBkYXRlKHQpfSk6dCh3aW5kb3cpLm9mZihwLlJFU0laRSl9LGgucHJvdG90eXBlLl9oaWRlTW9kYWw9ZnVuY3Rpb24oKXt2YXIgZT10aGlzO3RoaXMuX2VsZW1lbnQuc3R5bGUuZGlzcGxheT1cIm5vbmVcIix0aGlzLl9lbGVtZW50LnNldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIsXCJ0cnVlXCIpLHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMSx0aGlzLl9zaG93QmFja2Ryb3AoZnVuY3Rpb24oKXt0KGRvY3VtZW50LmJvZHkpLnJlbW92ZUNsYXNzKG0uT1BFTiksZS5fcmVzZXRBZGp1c3RtZW50cygpLGUuX3Jlc2V0U2Nyb2xsYmFyKCksdChlLl9lbGVtZW50KS50cmlnZ2VyKHAuSElEREVOKX0pfSxoLnByb3RvdHlwZS5fcmVtb3ZlQmFja2Ryb3A9ZnVuY3Rpb24oKXt0aGlzLl9iYWNrZHJvcCYmKHQodGhpcy5fYmFja2Ryb3ApLnJlbW92ZSgpLHRoaXMuX2JhY2tkcm9wPW51bGwpfSxoLnByb3RvdHlwZS5fc2hvd0JhY2tkcm9wPWZ1bmN0aW9uKGUpe3ZhciBuPXRoaXMsaT10KHRoaXMuX2VsZW1lbnQpLmhhc0NsYXNzKG0uRkFERSk/bS5GQURFOlwiXCI7aWYodGhpcy5faXNTaG93biYmdGhpcy5fY29uZmlnLmJhY2tkcm9wKXt2YXIgbz1yLnN1cHBvcnRzVHJhbnNpdGlvbkVuZCgpJiZpO2lmKHRoaXMuX2JhY2tkcm9wPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksdGhpcy5fYmFja2Ryb3AuY2xhc3NOYW1lPW0uQkFDS0RST1AsaSYmdCh0aGlzLl9iYWNrZHJvcCkuYWRkQ2xhc3MoaSksdCh0aGlzLl9iYWNrZHJvcCkuYXBwZW5kVG8oZG9jdW1lbnQuYm9keSksdCh0aGlzLl9lbGVtZW50KS5vbihwLkNMSUNLX0RJU01JU1MsZnVuY3Rpb24odCl7cmV0dXJuIG4uX2lnbm9yZUJhY2tkcm9wQ2xpY2s/dm9pZChuLl9pZ25vcmVCYWNrZHJvcENsaWNrPSExKTp2b2lkKHQudGFyZ2V0PT09dC5jdXJyZW50VGFyZ2V0JiYoXCJzdGF0aWNcIj09PW4uX2NvbmZpZy5iYWNrZHJvcD9uLl9lbGVtZW50LmZvY3VzKCk6bi5oaWRlKCkpKX0pLG8mJnIucmVmbG93KHRoaXMuX2JhY2tkcm9wKSx0KHRoaXMuX2JhY2tkcm9wKS5hZGRDbGFzcyhtLlNIT1cpLCFlKXJldHVybjtpZighbylyZXR1cm4gdm9pZCBlKCk7dCh0aGlzLl9iYWNrZHJvcCkub25lKHIuVFJBTlNJVElPTl9FTkQsZSkuZW11bGF0ZVRyYW5zaXRpb25FbmQoZCl9ZWxzZSBpZighdGhpcy5faXNTaG93biYmdGhpcy5fYmFja2Ryb3Ape3QodGhpcy5fYmFja2Ryb3ApLnJlbW92ZUNsYXNzKG0uU0hPVyk7dmFyIHM9ZnVuY3Rpb24oKXtuLl9yZW1vdmVCYWNrZHJvcCgpLGUmJmUoKX07ci5zdXBwb3J0c1RyYW5zaXRpb25FbmQoKSYmdCh0aGlzLl9lbGVtZW50KS5oYXNDbGFzcyhtLkZBREUpP3QodGhpcy5fYmFja2Ryb3ApLm9uZShyLlRSQU5TSVRJT05fRU5ELHMpLmVtdWxhdGVUcmFuc2l0aW9uRW5kKGQpOnMoKX1lbHNlIGUmJmUoKX0saC5wcm90b3R5cGUuX2hhbmRsZVVwZGF0ZT1mdW5jdGlvbigpe3RoaXMuX2FkanVzdERpYWxvZygpfSxoLnByb3RvdHlwZS5fYWRqdXN0RGlhbG9nPWZ1bmN0aW9uKCl7dmFyIHQ9dGhpcy5fZWxlbWVudC5zY3JvbGxIZWlnaHQ+ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsaWVudEhlaWdodDshdGhpcy5faXNCb2R5T3ZlcmZsb3dpbmcmJnQmJih0aGlzLl9lbGVtZW50LnN0eWxlLnBhZGRpbmdMZWZ0PXRoaXMuX3Njcm9sbGJhcldpZHRoK1wicHhcIiksdGhpcy5faXNCb2R5T3ZlcmZsb3dpbmcmJiF0JiYodGhpcy5fZWxlbWVudC5zdHlsZS5wYWRkaW5nUmlnaHQ9dGhpcy5fc2Nyb2xsYmFyV2lkdGgrXCJweFwiKX0saC5wcm90b3R5cGUuX3Jlc2V0QWRqdXN0bWVudHM9ZnVuY3Rpb24oKXt0aGlzLl9lbGVtZW50LnN0eWxlLnBhZGRpbmdMZWZ0PVwiXCIsdGhpcy5fZWxlbWVudC5zdHlsZS5wYWRkaW5nUmlnaHQ9XCJcIn0saC5wcm90b3R5cGUuX2NoZWNrU2Nyb2xsYmFyPWZ1bmN0aW9uKCl7dGhpcy5faXNCb2R5T3ZlcmZsb3dpbmc9ZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aDx3aW5kb3cuaW5uZXJXaWR0aCx0aGlzLl9zY3JvbGxiYXJXaWR0aD10aGlzLl9nZXRTY3JvbGxiYXJXaWR0aCgpfSxoLnByb3RvdHlwZS5fc2V0U2Nyb2xsYmFyPWZ1bmN0aW9uKCl7dmFyIGU9cGFyc2VJbnQodChFLkZJWEVEX0NPTlRFTlQpLmNzcyhcInBhZGRpbmctcmlnaHRcIil8fDAsMTApO3RoaXMuX29yaWdpbmFsQm9keVBhZGRpbmc9ZG9jdW1lbnQuYm9keS5zdHlsZS5wYWRkaW5nUmlnaHR8fFwiXCIsdGhpcy5faXNCb2R5T3ZlcmZsb3dpbmcmJihkb2N1bWVudC5ib2R5LnN0eWxlLnBhZGRpbmdSaWdodD1lK3RoaXMuX3Njcm9sbGJhcldpZHRoK1wicHhcIil9LGgucHJvdG90eXBlLl9yZXNldFNjcm9sbGJhcj1mdW5jdGlvbigpe2RvY3VtZW50LmJvZHkuc3R5bGUucGFkZGluZ1JpZ2h0PXRoaXMuX29yaWdpbmFsQm9keVBhZGRpbmd9LGgucHJvdG90eXBlLl9nZXRTY3JvbGxiYXJXaWR0aD1mdW5jdGlvbigpe3ZhciB0PWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7dC5jbGFzc05hbWU9bS5TQ1JPTExCQVJfTUVBU1VSRVIsZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0KTt2YXIgZT10Lm9mZnNldFdpZHRoLXQuY2xpZW50V2lkdGg7cmV0dXJuIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQodCksZX0saC5falF1ZXJ5SW50ZXJmYWNlPWZ1bmN0aW9uKGUsbil7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe3ZhciBvPXQodGhpcykuZGF0YShhKSxyPXQuZXh0ZW5kKHt9LGguRGVmYXVsdCx0KHRoaXMpLmRhdGEoKSxcIm9iamVjdFwiPT09KFwidW5kZWZpbmVkXCI9PXR5cGVvZiBlP1widW5kZWZpbmVkXCI6aShlKSkmJmUpO2lmKG98fChvPW5ldyBoKHRoaXMsciksdCh0aGlzKS5kYXRhKGEsbykpLFwic3RyaW5nXCI9PXR5cGVvZiBlKXtpZih2b2lkIDA9PT1vW2VdKXRocm93IG5ldyBFcnJvcignTm8gbWV0aG9kIG5hbWVkIFwiJytlKydcIicpO29bZV0obil9ZWxzZSByLnNob3cmJm8uc2hvdyhuKX0pfSxvKGgsbnVsbCxbe2tleTpcIlZFUlNJT05cIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gc319LHtrZXk6XCJEZWZhdWx0XCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIF99fV0pLGh9KCk7cmV0dXJuIHQoZG9jdW1lbnQpLm9uKHAuQ0xJQ0tfREFUQV9BUEksRS5EQVRBX1RPR0dMRSxmdW5jdGlvbihlKXt2YXIgbj10aGlzLGk9dm9pZCAwLG89ci5nZXRTZWxlY3RvckZyb21FbGVtZW50KHRoaXMpO28mJihpPXQobylbMF0pO3ZhciBzPXQoaSkuZGF0YShhKT9cInRvZ2dsZVwiOnQuZXh0ZW5kKHt9LHQoaSkuZGF0YSgpLHQodGhpcykuZGF0YSgpKTtcIkFcIiE9PXRoaXMudGFnTmFtZSYmXCJBUkVBXCIhPT10aGlzLnRhZ05hbWV8fGUucHJldmVudERlZmF1bHQoKTt2YXIgbD10KGkpLm9uZShwLlNIT1csZnVuY3Rpb24oZSl7ZS5pc0RlZmF1bHRQcmV2ZW50ZWQoKXx8bC5vbmUocC5ISURERU4sZnVuY3Rpb24oKXt0KG4pLmlzKFwiOnZpc2libGVcIikmJm4uZm9jdXMoKX0pfSk7di5falF1ZXJ5SW50ZXJmYWNlLmNhbGwodChpKSxzLHRoaXMpfSksdC5mbltlXT12Ll9qUXVlcnlJbnRlcmZhY2UsdC5mbltlXS5Db25zdHJ1Y3Rvcj12LHQuZm5bZV0ubm9Db25mbGljdD1mdW5jdGlvbigpe3JldHVybiB0LmZuW2VdPWMsdi5falF1ZXJ5SW50ZXJmYWNlfSx2fShqUXVlcnkpLGZ1bmN0aW9uKHQpe3ZhciBlPVwic2Nyb2xsc3B5XCIscz1cIjQuMC4wLWFscGhhLjZcIixhPVwiYnMuc2Nyb2xsc3B5XCIsbD1cIi5cIithLGg9XCIuZGF0YS1hcGlcIixjPXQuZm5bZV0sdT17b2Zmc2V0OjEwLG1ldGhvZDpcImF1dG9cIix0YXJnZXQ6XCJcIn0sZD17b2Zmc2V0OlwibnVtYmVyXCIsbWV0aG9kOlwic3RyaW5nXCIsdGFyZ2V0OlwiKHN0cmluZ3xlbGVtZW50KVwifSxmPXtBQ1RJVkFURTpcImFjdGl2YXRlXCIrbCxTQ1JPTEw6XCJzY3JvbGxcIitsLExPQURfREFUQV9BUEk6XCJsb2FkXCIrbCtofSxfPXtEUk9QRE9XTl9JVEVNOlwiZHJvcGRvd24taXRlbVwiLERST1BET1dOX01FTlU6XCJkcm9wZG93bi1tZW51XCIsTkFWX0xJTks6XCJuYXYtbGlua1wiLE5BVjpcIm5hdlwiLEFDVElWRTpcImFjdGl2ZVwifSxnPXtEQVRBX1NQWTonW2RhdGEtc3B5PVwic2Nyb2xsXCJdJyxBQ1RJVkU6XCIuYWN0aXZlXCIsTElTVF9JVEVNOlwiLmxpc3QtaXRlbVwiLExJOlwibGlcIixMSV9EUk9QRE9XTjpcImxpLmRyb3Bkb3duXCIsTkFWX0xJTktTOlwiLm5hdi1saW5rXCIsRFJPUERPV046XCIuZHJvcGRvd25cIixEUk9QRE9XTl9JVEVNUzpcIi5kcm9wZG93bi1pdGVtXCIsRFJPUERPV05fVE9HR0xFOlwiLmRyb3Bkb3duLXRvZ2dsZVwifSxwPXtPRkZTRVQ6XCJvZmZzZXRcIixQT1NJVElPTjpcInBvc2l0aW9uXCJ9LG09ZnVuY3Rpb24oKXtmdW5jdGlvbiBoKGUsaSl7dmFyIG89dGhpcztuKHRoaXMsaCksdGhpcy5fZWxlbWVudD1lLHRoaXMuX3Njcm9sbEVsZW1lbnQ9XCJCT0RZXCI9PT1lLnRhZ05hbWU/d2luZG93OmUsdGhpcy5fY29uZmlnPXRoaXMuX2dldENvbmZpZyhpKSx0aGlzLl9zZWxlY3Rvcj10aGlzLl9jb25maWcudGFyZ2V0K1wiIFwiK2cuTkFWX0xJTktTK1wiLFwiKyh0aGlzLl9jb25maWcudGFyZ2V0K1wiIFwiK2cuRFJPUERPV05fSVRFTVMpLHRoaXMuX29mZnNldHM9W10sdGhpcy5fdGFyZ2V0cz1bXSx0aGlzLl9hY3RpdmVUYXJnZXQ9bnVsbCx0aGlzLl9zY3JvbGxIZWlnaHQ9MCx0KHRoaXMuX3Njcm9sbEVsZW1lbnQpLm9uKGYuU0NST0xMLGZ1bmN0aW9uKHQpe3JldHVybiBvLl9wcm9jZXNzKHQpfSksdGhpcy5yZWZyZXNoKCksdGhpcy5fcHJvY2VzcygpfXJldHVybiBoLnByb3RvdHlwZS5yZWZyZXNoPWZ1bmN0aW9uKCl7dmFyIGU9dGhpcyxuPXRoaXMuX3Njcm9sbEVsZW1lbnQhPT10aGlzLl9zY3JvbGxFbGVtZW50LndpbmRvdz9wLlBPU0lUSU9OOnAuT0ZGU0VULGk9XCJhdXRvXCI9PT10aGlzLl9jb25maWcubWV0aG9kP246dGhpcy5fY29uZmlnLm1ldGhvZCxvPWk9PT1wLlBPU0lUSU9OP3RoaXMuX2dldFNjcm9sbFRvcCgpOjA7dGhpcy5fb2Zmc2V0cz1bXSx0aGlzLl90YXJnZXRzPVtdLHRoaXMuX3Njcm9sbEhlaWdodD10aGlzLl9nZXRTY3JvbGxIZWlnaHQoKTt2YXIgcz10Lm1ha2VBcnJheSh0KHRoaXMuX3NlbGVjdG9yKSk7cy5tYXAoZnVuY3Rpb24oZSl7dmFyIG49dm9pZCAwLHM9ci5nZXRTZWxlY3RvckZyb21FbGVtZW50KGUpO3JldHVybiBzJiYobj10KHMpWzBdKSxuJiYobi5vZmZzZXRXaWR0aHx8bi5vZmZzZXRIZWlnaHQpP1t0KG4pW2ldKCkudG9wK28sc106bnVsbH0pLmZpbHRlcihmdW5jdGlvbih0KXtyZXR1cm4gdH0pLnNvcnQoZnVuY3Rpb24odCxlKXtyZXR1cm4gdFswXS1lWzBdfSkuZm9yRWFjaChmdW5jdGlvbih0KXtlLl9vZmZzZXRzLnB1c2godFswXSksZS5fdGFyZ2V0cy5wdXNoKHRbMV0pfSl9LGgucHJvdG90eXBlLmRpc3Bvc2U9ZnVuY3Rpb24oKXt0LnJlbW92ZURhdGEodGhpcy5fZWxlbWVudCxhKSx0KHRoaXMuX3Njcm9sbEVsZW1lbnQpLm9mZihsKSx0aGlzLl9lbGVtZW50PW51bGwsdGhpcy5fc2Nyb2xsRWxlbWVudD1udWxsLHRoaXMuX2NvbmZpZz1udWxsLHRoaXMuX3NlbGVjdG9yPW51bGwsdGhpcy5fb2Zmc2V0cz1udWxsLHRoaXMuX3RhcmdldHM9bnVsbCx0aGlzLl9hY3RpdmVUYXJnZXQ9bnVsbCx0aGlzLl9zY3JvbGxIZWlnaHQ9bnVsbH0saC5wcm90b3R5cGUuX2dldENvbmZpZz1mdW5jdGlvbihuKXtpZihuPXQuZXh0ZW5kKHt9LHUsbiksXCJzdHJpbmdcIiE9dHlwZW9mIG4udGFyZ2V0KXt2YXIgaT10KG4udGFyZ2V0KS5hdHRyKFwiaWRcIik7aXx8KGk9ci5nZXRVSUQoZSksdChuLnRhcmdldCkuYXR0cihcImlkXCIsaSkpLG4udGFyZ2V0PVwiI1wiK2l9cmV0dXJuIHIudHlwZUNoZWNrQ29uZmlnKGUsbixkKSxufSxoLnByb3RvdHlwZS5fZ2V0U2Nyb2xsVG9wPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuX3Njcm9sbEVsZW1lbnQ9PT13aW5kb3c/dGhpcy5fc2Nyb2xsRWxlbWVudC5wYWdlWU9mZnNldDp0aGlzLl9zY3JvbGxFbGVtZW50LnNjcm9sbFRvcH0saC5wcm90b3R5cGUuX2dldFNjcm9sbEhlaWdodD1mdW5jdGlvbigpe3JldHVybiB0aGlzLl9zY3JvbGxFbGVtZW50LnNjcm9sbEhlaWdodHx8TWF0aC5tYXgoZG9jdW1lbnQuYm9keS5zY3JvbGxIZWlnaHQsZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbEhlaWdodCl9LGgucHJvdG90eXBlLl9nZXRPZmZzZXRIZWlnaHQ9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5fc2Nyb2xsRWxlbWVudD09PXdpbmRvdz93aW5kb3cuaW5uZXJIZWlnaHQ6dGhpcy5fc2Nyb2xsRWxlbWVudC5vZmZzZXRIZWlnaHR9LGgucHJvdG90eXBlLl9wcm9jZXNzPWZ1bmN0aW9uKCl7dmFyIHQ9dGhpcy5fZ2V0U2Nyb2xsVG9wKCkrdGhpcy5fY29uZmlnLm9mZnNldCxlPXRoaXMuX2dldFNjcm9sbEhlaWdodCgpLG49dGhpcy5fY29uZmlnLm9mZnNldCtlLXRoaXMuX2dldE9mZnNldEhlaWdodCgpO2lmKHRoaXMuX3Njcm9sbEhlaWdodCE9PWUmJnRoaXMucmVmcmVzaCgpLHQ+PW4pe3ZhciBpPXRoaXMuX3RhcmdldHNbdGhpcy5fdGFyZ2V0cy5sZW5ndGgtMV07cmV0dXJuIHZvaWQodGhpcy5fYWN0aXZlVGFyZ2V0IT09aSYmdGhpcy5fYWN0aXZhdGUoaSkpfWlmKHRoaXMuX2FjdGl2ZVRhcmdldCYmdDx0aGlzLl9vZmZzZXRzWzBdJiZ0aGlzLl9vZmZzZXRzWzBdPjApcmV0dXJuIHRoaXMuX2FjdGl2ZVRhcmdldD1udWxsLHZvaWQgdGhpcy5fY2xlYXIoKTtmb3IodmFyIG89dGhpcy5fb2Zmc2V0cy5sZW5ndGg7by0tOyl7dmFyIHI9dGhpcy5fYWN0aXZlVGFyZ2V0IT09dGhpcy5fdGFyZ2V0c1tvXSYmdD49dGhpcy5fb2Zmc2V0c1tvXSYmKHZvaWQgMD09PXRoaXMuX29mZnNldHNbbysxXXx8dDx0aGlzLl9vZmZzZXRzW28rMV0pO3ImJnRoaXMuX2FjdGl2YXRlKHRoaXMuX3RhcmdldHNbb10pfX0saC5wcm90b3R5cGUuX2FjdGl2YXRlPWZ1bmN0aW9uKGUpe3RoaXMuX2FjdGl2ZVRhcmdldD1lLHRoaXMuX2NsZWFyKCk7dmFyIG49dGhpcy5fc2VsZWN0b3Iuc3BsaXQoXCIsXCIpO249bi5tYXAoZnVuY3Rpb24odCl7cmV0dXJuIHQrJ1tkYXRhLXRhcmdldD1cIicrZSsnXCJdLCcrKHQrJ1tocmVmPVwiJytlKydcIl0nKX0pO3ZhciBpPXQobi5qb2luKFwiLFwiKSk7aS5oYXNDbGFzcyhfLkRST1BET1dOX0lURU0pPyhpLmNsb3Nlc3QoZy5EUk9QRE9XTikuZmluZChnLkRST1BET1dOX1RPR0dMRSkuYWRkQ2xhc3MoXy5BQ1RJVkUpLGkuYWRkQ2xhc3MoXy5BQ1RJVkUpKTppLnBhcmVudHMoZy5MSSkuZmluZChcIj4gXCIrZy5OQVZfTElOS1MpLmFkZENsYXNzKF8uQUNUSVZFKSx0KHRoaXMuX3Njcm9sbEVsZW1lbnQpLnRyaWdnZXIoZi5BQ1RJVkFURSx7cmVsYXRlZFRhcmdldDplfSl9LGgucHJvdG90eXBlLl9jbGVhcj1mdW5jdGlvbigpe3QodGhpcy5fc2VsZWN0b3IpLmZpbHRlcihnLkFDVElWRSkucmVtb3ZlQ2xhc3MoXy5BQ1RJVkUpfSxoLl9qUXVlcnlJbnRlcmZhY2U9ZnVuY3Rpb24oZSl7cmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpe3ZhciBuPXQodGhpcykuZGF0YShhKSxvPVwib2JqZWN0XCI9PT0oXCJ1bmRlZmluZWRcIj09dHlwZW9mIGU/XCJ1bmRlZmluZWRcIjppKGUpKSYmZTtcbmlmKG58fChuPW5ldyBoKHRoaXMsbyksdCh0aGlzKS5kYXRhKGEsbikpLFwic3RyaW5nXCI9PXR5cGVvZiBlKXtpZih2b2lkIDA9PT1uW2VdKXRocm93IG5ldyBFcnJvcignTm8gbWV0aG9kIG5hbWVkIFwiJytlKydcIicpO25bZV0oKX19KX0sbyhoLG51bGwsW3trZXk6XCJWRVJTSU9OXCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIHN9fSx7a2V5OlwiRGVmYXVsdFwiLGdldDpmdW5jdGlvbigpe3JldHVybiB1fX1dKSxofSgpO3JldHVybiB0KHdpbmRvdykub24oZi5MT0FEX0RBVEFfQVBJLGZ1bmN0aW9uKCl7Zm9yKHZhciBlPXQubWFrZUFycmF5KHQoZy5EQVRBX1NQWSkpLG49ZS5sZW5ndGg7bi0tOyl7dmFyIGk9dChlW25dKTttLl9qUXVlcnlJbnRlcmZhY2UuY2FsbChpLGkuZGF0YSgpKX19KSx0LmZuW2VdPW0uX2pRdWVyeUludGVyZmFjZSx0LmZuW2VdLkNvbnN0cnVjdG9yPW0sdC5mbltlXS5ub0NvbmZsaWN0PWZ1bmN0aW9uKCl7cmV0dXJuIHQuZm5bZV09YyxtLl9qUXVlcnlJbnRlcmZhY2V9LG19KGpRdWVyeSksZnVuY3Rpb24odCl7dmFyIGU9XCJ0YWJcIixpPVwiNC4wLjAtYWxwaGEuNlwiLHM9XCJicy50YWJcIixhPVwiLlwiK3MsbD1cIi5kYXRhLWFwaVwiLGg9dC5mbltlXSxjPTE1MCx1PXtISURFOlwiaGlkZVwiK2EsSElEREVOOlwiaGlkZGVuXCIrYSxTSE9XOlwic2hvd1wiK2EsU0hPV046XCJzaG93blwiK2EsQ0xJQ0tfREFUQV9BUEk6XCJjbGlja1wiK2ErbH0sZD17RFJPUERPV05fTUVOVTpcImRyb3Bkb3duLW1lbnVcIixBQ1RJVkU6XCJhY3RpdmVcIixESVNBQkxFRDpcImRpc2FibGVkXCIsRkFERTpcImZhZGVcIixTSE9XOlwic2hvd1wifSxmPXtBOlwiYVwiLExJOlwibGlcIixEUk9QRE9XTjpcIi5kcm9wZG93blwiLExJU1Q6XCJ1bDpub3QoLmRyb3Bkb3duLW1lbnUpLCBvbDpub3QoLmRyb3Bkb3duLW1lbnUpLCBuYXY6bm90KC5kcm9wZG93bi1tZW51KVwiLEZBREVfQ0hJTEQ6XCI+IC5uYXYtaXRlbSAuZmFkZSwgPiAuZmFkZVwiLEFDVElWRTpcIi5hY3RpdmVcIixBQ1RJVkVfQ0hJTEQ6XCI+IC5uYXYtaXRlbSA+IC5hY3RpdmUsID4gLmFjdGl2ZVwiLERBVEFfVE9HR0xFOidbZGF0YS10b2dnbGU9XCJ0YWJcIl0sIFtkYXRhLXRvZ2dsZT1cInBpbGxcIl0nLERST1BET1dOX1RPR0dMRTpcIi5kcm9wZG93bi10b2dnbGVcIixEUk9QRE9XTl9BQ1RJVkVfQ0hJTEQ6XCI+IC5kcm9wZG93bi1tZW51IC5hY3RpdmVcIn0sXz1mdW5jdGlvbigpe2Z1bmN0aW9uIGUodCl7bih0aGlzLGUpLHRoaXMuX2VsZW1lbnQ9dH1yZXR1cm4gZS5wcm90b3R5cGUuc2hvdz1mdW5jdGlvbigpe3ZhciBlPXRoaXM7aWYoISh0aGlzLl9lbGVtZW50LnBhcmVudE5vZGUmJnRoaXMuX2VsZW1lbnQucGFyZW50Tm9kZS5ub2RlVHlwZT09PU5vZGUuRUxFTUVOVF9OT0RFJiZ0KHRoaXMuX2VsZW1lbnQpLmhhc0NsYXNzKGQuQUNUSVZFKXx8dCh0aGlzLl9lbGVtZW50KS5oYXNDbGFzcyhkLkRJU0FCTEVEKSkpe3ZhciBuPXZvaWQgMCxpPXZvaWQgMCxvPXQodGhpcy5fZWxlbWVudCkuY2xvc2VzdChmLkxJU1QpWzBdLHM9ci5nZXRTZWxlY3RvckZyb21FbGVtZW50KHRoaXMuX2VsZW1lbnQpO28mJihpPXQubWFrZUFycmF5KHQobykuZmluZChmLkFDVElWRSkpLGk9aVtpLmxlbmd0aC0xXSk7dmFyIGE9dC5FdmVudCh1LkhJREUse3JlbGF0ZWRUYXJnZXQ6dGhpcy5fZWxlbWVudH0pLGw9dC5FdmVudCh1LlNIT1cse3JlbGF0ZWRUYXJnZXQ6aX0pO2lmKGkmJnQoaSkudHJpZ2dlcihhKSx0KHRoaXMuX2VsZW1lbnQpLnRyaWdnZXIobCksIWwuaXNEZWZhdWx0UHJldmVudGVkKCkmJiFhLmlzRGVmYXVsdFByZXZlbnRlZCgpKXtzJiYobj10KHMpWzBdKSx0aGlzLl9hY3RpdmF0ZSh0aGlzLl9lbGVtZW50LG8pO3ZhciBoPWZ1bmN0aW9uKCl7dmFyIG49dC5FdmVudCh1LkhJRERFTix7cmVsYXRlZFRhcmdldDplLl9lbGVtZW50fSksbz10LkV2ZW50KHUuU0hPV04se3JlbGF0ZWRUYXJnZXQ6aX0pO3QoaSkudHJpZ2dlcihuKSx0KGUuX2VsZW1lbnQpLnRyaWdnZXIobyl9O24/dGhpcy5fYWN0aXZhdGUobixuLnBhcmVudE5vZGUsaCk6aCgpfX19LGUucHJvdG90eXBlLmRpc3Bvc2U9ZnVuY3Rpb24oKXt0LnJlbW92ZUNsYXNzKHRoaXMuX2VsZW1lbnQscyksdGhpcy5fZWxlbWVudD1udWxsfSxlLnByb3RvdHlwZS5fYWN0aXZhdGU9ZnVuY3Rpb24oZSxuLGkpe3ZhciBvPXRoaXMscz10KG4pLmZpbmQoZi5BQ1RJVkVfQ0hJTEQpWzBdLGE9aSYmci5zdXBwb3J0c1RyYW5zaXRpb25FbmQoKSYmKHMmJnQocykuaGFzQ2xhc3MoZC5GQURFKXx8Qm9vbGVhbih0KG4pLmZpbmQoZi5GQURFX0NISUxEKVswXSkpLGw9ZnVuY3Rpb24oKXtyZXR1cm4gby5fdHJhbnNpdGlvbkNvbXBsZXRlKGUscyxhLGkpfTtzJiZhP3Qocykub25lKHIuVFJBTlNJVElPTl9FTkQsbCkuZW11bGF0ZVRyYW5zaXRpb25FbmQoYyk6bCgpLHMmJnQocykucmVtb3ZlQ2xhc3MoZC5TSE9XKX0sZS5wcm90b3R5cGUuX3RyYW5zaXRpb25Db21wbGV0ZT1mdW5jdGlvbihlLG4saSxvKXtpZihuKXt0KG4pLnJlbW92ZUNsYXNzKGQuQUNUSVZFKTt2YXIgcz10KG4ucGFyZW50Tm9kZSkuZmluZChmLkRST1BET1dOX0FDVElWRV9DSElMRClbMF07cyYmdChzKS5yZW1vdmVDbGFzcyhkLkFDVElWRSksbi5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsITEpfWlmKHQoZSkuYWRkQ2xhc3MoZC5BQ1RJVkUpLGUuc2V0QXR0cmlidXRlKFwiYXJpYS1leHBhbmRlZFwiLCEwKSxpPyhyLnJlZmxvdyhlKSx0KGUpLmFkZENsYXNzKGQuU0hPVykpOnQoZSkucmVtb3ZlQ2xhc3MoZC5GQURFKSxlLnBhcmVudE5vZGUmJnQoZS5wYXJlbnROb2RlKS5oYXNDbGFzcyhkLkRST1BET1dOX01FTlUpKXt2YXIgYT10KGUpLmNsb3Nlc3QoZi5EUk9QRE9XTilbMF07YSYmdChhKS5maW5kKGYuRFJPUERPV05fVE9HR0xFKS5hZGRDbGFzcyhkLkFDVElWRSksZS5zZXRBdHRyaWJ1dGUoXCJhcmlhLWV4cGFuZGVkXCIsITApfW8mJm8oKX0sZS5falF1ZXJ5SW50ZXJmYWNlPWZ1bmN0aW9uKG4pe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXt2YXIgaT10KHRoaXMpLG89aS5kYXRhKHMpO2lmKG98fChvPW5ldyBlKHRoaXMpLGkuZGF0YShzLG8pKSxcInN0cmluZ1wiPT10eXBlb2Ygbil7aWYodm9pZCAwPT09b1tuXSl0aHJvdyBuZXcgRXJyb3IoJ05vIG1ldGhvZCBuYW1lZCBcIicrbisnXCInKTtvW25dKCl9fSl9LG8oZSxudWxsLFt7a2V5OlwiVkVSU0lPTlwiLGdldDpmdW5jdGlvbigpe3JldHVybiBpfX1dKSxlfSgpO3JldHVybiB0KGRvY3VtZW50KS5vbih1LkNMSUNLX0RBVEFfQVBJLGYuREFUQV9UT0dHTEUsZnVuY3Rpb24oZSl7ZS5wcmV2ZW50RGVmYXVsdCgpLF8uX2pRdWVyeUludGVyZmFjZS5jYWxsKHQodGhpcyksXCJzaG93XCIpfSksdC5mbltlXT1fLl9qUXVlcnlJbnRlcmZhY2UsdC5mbltlXS5Db25zdHJ1Y3Rvcj1fLHQuZm5bZV0ubm9Db25mbGljdD1mdW5jdGlvbigpe3JldHVybiB0LmZuW2VdPWgsXy5falF1ZXJ5SW50ZXJmYWNlfSxffShqUXVlcnkpLGZ1bmN0aW9uKHQpe2lmKFwidW5kZWZpbmVkXCI9PXR5cGVvZiBUZXRoZXIpdGhyb3cgbmV3IEVycm9yKFwiQm9vdHN0cmFwIHRvb2x0aXBzIHJlcXVpcmUgVGV0aGVyIChodHRwOi8vdGV0aGVyLmlvLylcIik7dmFyIGU9XCJ0b29sdGlwXCIscz1cIjQuMC4wLWFscGhhLjZcIixhPVwiYnMudG9vbHRpcFwiLGw9XCIuXCIrYSxoPXQuZm5bZV0sYz0xNTAsdT1cImJzLXRldGhlclwiLGQ9e2FuaW1hdGlvbjohMCx0ZW1wbGF0ZTonPGRpdiBjbGFzcz1cInRvb2x0aXBcIiByb2xlPVwidG9vbHRpcFwiPjxkaXYgY2xhc3M9XCJ0b29sdGlwLWlubmVyXCI+PC9kaXY+PC9kaXY+Jyx0cmlnZ2VyOlwiaG92ZXIgZm9jdXNcIix0aXRsZTpcIlwiLGRlbGF5OjAsaHRtbDohMSxzZWxlY3RvcjohMSxwbGFjZW1lbnQ6XCJ0b3BcIixvZmZzZXQ6XCIwIDBcIixjb25zdHJhaW50czpbXSxjb250YWluZXI6ITF9LGY9e2FuaW1hdGlvbjpcImJvb2xlYW5cIix0ZW1wbGF0ZTpcInN0cmluZ1wiLHRpdGxlOlwiKHN0cmluZ3xlbGVtZW50fGZ1bmN0aW9uKVwiLHRyaWdnZXI6XCJzdHJpbmdcIixkZWxheTpcIihudW1iZXJ8b2JqZWN0KVwiLGh0bWw6XCJib29sZWFuXCIsc2VsZWN0b3I6XCIoc3RyaW5nfGJvb2xlYW4pXCIscGxhY2VtZW50OlwiKHN0cmluZ3xmdW5jdGlvbilcIixvZmZzZXQ6XCJzdHJpbmdcIixjb25zdHJhaW50czpcImFycmF5XCIsY29udGFpbmVyOlwiKHN0cmluZ3xlbGVtZW50fGJvb2xlYW4pXCJ9LF89e1RPUDpcImJvdHRvbSBjZW50ZXJcIixSSUdIVDpcIm1pZGRsZSBsZWZ0XCIsQk9UVE9NOlwidG9wIGNlbnRlclwiLExFRlQ6XCJtaWRkbGUgcmlnaHRcIn0sZz17U0hPVzpcInNob3dcIixPVVQ6XCJvdXRcIn0scD17SElERTpcImhpZGVcIitsLEhJRERFTjpcImhpZGRlblwiK2wsU0hPVzpcInNob3dcIitsLFNIT1dOOlwic2hvd25cIitsLElOU0VSVEVEOlwiaW5zZXJ0ZWRcIitsLENMSUNLOlwiY2xpY2tcIitsLEZPQ1VTSU46XCJmb2N1c2luXCIrbCxGT0NVU09VVDpcImZvY3Vzb3V0XCIrbCxNT1VTRUVOVEVSOlwibW91c2VlbnRlclwiK2wsTU9VU0VMRUFWRTpcIm1vdXNlbGVhdmVcIitsfSxtPXtGQURFOlwiZmFkZVwiLFNIT1c6XCJzaG93XCJ9LEU9e1RPT0xUSVA6XCIudG9vbHRpcFwiLFRPT0xUSVBfSU5ORVI6XCIudG9vbHRpcC1pbm5lclwifSx2PXtlbGVtZW50OiExLGVuYWJsZWQ6ITF9LFQ9e0hPVkVSOlwiaG92ZXJcIixGT0NVUzpcImZvY3VzXCIsQ0xJQ0s6XCJjbGlja1wiLE1BTlVBTDpcIm1hbnVhbFwifSxJPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gaCh0LGUpe24odGhpcyxoKSx0aGlzLl9pc0VuYWJsZWQ9ITAsdGhpcy5fdGltZW91dD0wLHRoaXMuX2hvdmVyU3RhdGU9XCJcIix0aGlzLl9hY3RpdmVUcmlnZ2VyPXt9LHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMSx0aGlzLl90ZXRoZXI9bnVsbCx0aGlzLmVsZW1lbnQ9dCx0aGlzLmNvbmZpZz10aGlzLl9nZXRDb25maWcoZSksdGhpcy50aXA9bnVsbCx0aGlzLl9zZXRMaXN0ZW5lcnMoKX1yZXR1cm4gaC5wcm90b3R5cGUuZW5hYmxlPWZ1bmN0aW9uKCl7dGhpcy5faXNFbmFibGVkPSEwfSxoLnByb3RvdHlwZS5kaXNhYmxlPWZ1bmN0aW9uKCl7dGhpcy5faXNFbmFibGVkPSExfSxoLnByb3RvdHlwZS50b2dnbGVFbmFibGVkPWZ1bmN0aW9uKCl7dGhpcy5faXNFbmFibGVkPSF0aGlzLl9pc0VuYWJsZWR9LGgucHJvdG90eXBlLnRvZ2dsZT1mdW5jdGlvbihlKXtpZihlKXt2YXIgbj10aGlzLmNvbnN0cnVjdG9yLkRBVEFfS0VZLGk9dChlLmN1cnJlbnRUYXJnZXQpLmRhdGEobik7aXx8KGk9bmV3IHRoaXMuY29uc3RydWN0b3IoZS5jdXJyZW50VGFyZ2V0LHRoaXMuX2dldERlbGVnYXRlQ29uZmlnKCkpLHQoZS5jdXJyZW50VGFyZ2V0KS5kYXRhKG4saSkpLGkuX2FjdGl2ZVRyaWdnZXIuY2xpY2s9IWkuX2FjdGl2ZVRyaWdnZXIuY2xpY2ssaS5faXNXaXRoQWN0aXZlVHJpZ2dlcigpP2kuX2VudGVyKG51bGwsaSk6aS5fbGVhdmUobnVsbCxpKX1lbHNle2lmKHQodGhpcy5nZXRUaXBFbGVtZW50KCkpLmhhc0NsYXNzKG0uU0hPVykpcmV0dXJuIHZvaWQgdGhpcy5fbGVhdmUobnVsbCx0aGlzKTt0aGlzLl9lbnRlcihudWxsLHRoaXMpfX0saC5wcm90b3R5cGUuZGlzcG9zZT1mdW5jdGlvbigpe2NsZWFyVGltZW91dCh0aGlzLl90aW1lb3V0KSx0aGlzLmNsZWFudXBUZXRoZXIoKSx0LnJlbW92ZURhdGEodGhpcy5lbGVtZW50LHRoaXMuY29uc3RydWN0b3IuREFUQV9LRVkpLHQodGhpcy5lbGVtZW50KS5vZmYodGhpcy5jb25zdHJ1Y3Rvci5FVkVOVF9LRVkpLHQodGhpcy5lbGVtZW50KS5jbG9zZXN0KFwiLm1vZGFsXCIpLm9mZihcImhpZGUuYnMubW9kYWxcIiksdGhpcy50aXAmJnQodGhpcy50aXApLnJlbW92ZSgpLHRoaXMuX2lzRW5hYmxlZD1udWxsLHRoaXMuX3RpbWVvdXQ9bnVsbCx0aGlzLl9ob3ZlclN0YXRlPW51bGwsdGhpcy5fYWN0aXZlVHJpZ2dlcj1udWxsLHRoaXMuX3RldGhlcj1udWxsLHRoaXMuZWxlbWVudD1udWxsLHRoaXMuY29uZmlnPW51bGwsdGhpcy50aXA9bnVsbH0saC5wcm90b3R5cGUuc2hvdz1mdW5jdGlvbigpe3ZhciBlPXRoaXM7aWYoXCJub25lXCI9PT10KHRoaXMuZWxlbWVudCkuY3NzKFwiZGlzcGxheVwiKSl0aHJvdyBuZXcgRXJyb3IoXCJQbGVhc2UgdXNlIHNob3cgb24gdmlzaWJsZSBlbGVtZW50c1wiKTt2YXIgbj10LkV2ZW50KHRoaXMuY29uc3RydWN0b3IuRXZlbnQuU0hPVyk7aWYodGhpcy5pc1dpdGhDb250ZW50KCkmJnRoaXMuX2lzRW5hYmxlZCl7aWYodGhpcy5faXNUcmFuc2l0aW9uaW5nKXRocm93IG5ldyBFcnJvcihcIlRvb2x0aXAgaXMgdHJhbnNpdGlvbmluZ1wiKTt0KHRoaXMuZWxlbWVudCkudHJpZ2dlcihuKTt2YXIgaT10LmNvbnRhaW5zKHRoaXMuZWxlbWVudC5vd25lckRvY3VtZW50LmRvY3VtZW50RWxlbWVudCx0aGlzLmVsZW1lbnQpO2lmKG4uaXNEZWZhdWx0UHJldmVudGVkKCl8fCFpKXJldHVybjt2YXIgbz10aGlzLmdldFRpcEVsZW1lbnQoKSxzPXIuZ2V0VUlEKHRoaXMuY29uc3RydWN0b3IuTkFNRSk7by5zZXRBdHRyaWJ1dGUoXCJpZFwiLHMpLHRoaXMuZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJhcmlhLWRlc2NyaWJlZGJ5XCIscyksdGhpcy5zZXRDb250ZW50KCksdGhpcy5jb25maWcuYW5pbWF0aW9uJiZ0KG8pLmFkZENsYXNzKG0uRkFERSk7dmFyIGE9XCJmdW5jdGlvblwiPT10eXBlb2YgdGhpcy5jb25maWcucGxhY2VtZW50P3RoaXMuY29uZmlnLnBsYWNlbWVudC5jYWxsKHRoaXMsbyx0aGlzLmVsZW1lbnQpOnRoaXMuY29uZmlnLnBsYWNlbWVudCxsPXRoaXMuX2dldEF0dGFjaG1lbnQoYSksYz10aGlzLmNvbmZpZy5jb250YWluZXI9PT0hMT9kb2N1bWVudC5ib2R5OnQodGhpcy5jb25maWcuY29udGFpbmVyKTt0KG8pLmRhdGEodGhpcy5jb25zdHJ1Y3Rvci5EQVRBX0tFWSx0aGlzKS5hcHBlbmRUbyhjKSx0KHRoaXMuZWxlbWVudCkudHJpZ2dlcih0aGlzLmNvbnN0cnVjdG9yLkV2ZW50LklOU0VSVEVEKSx0aGlzLl90ZXRoZXI9bmV3IFRldGhlcih7YXR0YWNobWVudDpsLGVsZW1lbnQ6byx0YXJnZXQ6dGhpcy5lbGVtZW50LGNsYXNzZXM6dixjbGFzc1ByZWZpeDp1LG9mZnNldDp0aGlzLmNvbmZpZy5vZmZzZXQsY29uc3RyYWludHM6dGhpcy5jb25maWcuY29uc3RyYWludHMsYWRkVGFyZ2V0Q2xhc3NlczohMX0pLHIucmVmbG93KG8pLHRoaXMuX3RldGhlci5wb3NpdGlvbigpLHQobykuYWRkQ2xhc3MobS5TSE9XKTt2YXIgZD1mdW5jdGlvbigpe3ZhciBuPWUuX2hvdmVyU3RhdGU7ZS5faG92ZXJTdGF0ZT1udWxsLGUuX2lzVHJhbnNpdGlvbmluZz0hMSx0KGUuZWxlbWVudCkudHJpZ2dlcihlLmNvbnN0cnVjdG9yLkV2ZW50LlNIT1dOKSxuPT09Zy5PVVQmJmUuX2xlYXZlKG51bGwsZSl9O2lmKHIuc3VwcG9ydHNUcmFuc2l0aW9uRW5kKCkmJnQodGhpcy50aXApLmhhc0NsYXNzKG0uRkFERSkpcmV0dXJuIHRoaXMuX2lzVHJhbnNpdGlvbmluZz0hMCx2b2lkIHQodGhpcy50aXApLm9uZShyLlRSQU5TSVRJT05fRU5ELGQpLmVtdWxhdGVUcmFuc2l0aW9uRW5kKGguX1RSQU5TSVRJT05fRFVSQVRJT04pO2QoKX19LGgucHJvdG90eXBlLmhpZGU9ZnVuY3Rpb24oZSl7dmFyIG49dGhpcyxpPXRoaXMuZ2V0VGlwRWxlbWVudCgpLG89dC5FdmVudCh0aGlzLmNvbnN0cnVjdG9yLkV2ZW50LkhJREUpO2lmKHRoaXMuX2lzVHJhbnNpdGlvbmluZyl0aHJvdyBuZXcgRXJyb3IoXCJUb29sdGlwIGlzIHRyYW5zaXRpb25pbmdcIik7dmFyIHM9ZnVuY3Rpb24oKXtuLl9ob3ZlclN0YXRlIT09Zy5TSE9XJiZpLnBhcmVudE5vZGUmJmkucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChpKSxuLmVsZW1lbnQucmVtb3ZlQXR0cmlidXRlKFwiYXJpYS1kZXNjcmliZWRieVwiKSx0KG4uZWxlbWVudCkudHJpZ2dlcihuLmNvbnN0cnVjdG9yLkV2ZW50LkhJRERFTiksbi5faXNUcmFuc2l0aW9uaW5nPSExLG4uY2xlYW51cFRldGhlcigpLGUmJmUoKX07dCh0aGlzLmVsZW1lbnQpLnRyaWdnZXIobyksby5pc0RlZmF1bHRQcmV2ZW50ZWQoKXx8KHQoaSkucmVtb3ZlQ2xhc3MobS5TSE9XKSx0aGlzLl9hY3RpdmVUcmlnZ2VyW1QuQ0xJQ0tdPSExLHRoaXMuX2FjdGl2ZVRyaWdnZXJbVC5GT0NVU109ITEsdGhpcy5fYWN0aXZlVHJpZ2dlcltULkhPVkVSXT0hMSxyLnN1cHBvcnRzVHJhbnNpdGlvbkVuZCgpJiZ0KHRoaXMudGlwKS5oYXNDbGFzcyhtLkZBREUpPyh0aGlzLl9pc1RyYW5zaXRpb25pbmc9ITAsdChpKS5vbmUoci5UUkFOU0lUSU9OX0VORCxzKS5lbXVsYXRlVHJhbnNpdGlvbkVuZChjKSk6cygpLHRoaXMuX2hvdmVyU3RhdGU9XCJcIil9LGgucHJvdG90eXBlLmlzV2l0aENvbnRlbnQ9ZnVuY3Rpb24oKXtyZXR1cm4gQm9vbGVhbih0aGlzLmdldFRpdGxlKCkpfSxoLnByb3RvdHlwZS5nZXRUaXBFbGVtZW50PWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMudGlwPXRoaXMudGlwfHx0KHRoaXMuY29uZmlnLnRlbXBsYXRlKVswXX0saC5wcm90b3R5cGUuc2V0Q29udGVudD1mdW5jdGlvbigpe3ZhciBlPXQodGhpcy5nZXRUaXBFbGVtZW50KCkpO3RoaXMuc2V0RWxlbWVudENvbnRlbnQoZS5maW5kKEUuVE9PTFRJUF9JTk5FUiksdGhpcy5nZXRUaXRsZSgpKSxlLnJlbW92ZUNsYXNzKG0uRkFERStcIiBcIittLlNIT1cpLHRoaXMuY2xlYW51cFRldGhlcigpfSxoLnByb3RvdHlwZS5zZXRFbGVtZW50Q29udGVudD1mdW5jdGlvbihlLG4pe3ZhciBvPXRoaXMuY29uZmlnLmh0bWw7XCJvYmplY3RcIj09PShcInVuZGVmaW5lZFwiPT10eXBlb2Ygbj9cInVuZGVmaW5lZFwiOmkobikpJiYobi5ub2RlVHlwZXx8bi5qcXVlcnkpP28/dChuKS5wYXJlbnQoKS5pcyhlKXx8ZS5lbXB0eSgpLmFwcGVuZChuKTplLnRleHQodChuKS50ZXh0KCkpOmVbbz9cImh0bWxcIjpcInRleHRcIl0obil9LGgucHJvdG90eXBlLmdldFRpdGxlPWZ1bmN0aW9uKCl7dmFyIHQ9dGhpcy5lbGVtZW50LmdldEF0dHJpYnV0ZShcImRhdGEtb3JpZ2luYWwtdGl0bGVcIik7cmV0dXJuIHR8fCh0PVwiZnVuY3Rpb25cIj09dHlwZW9mIHRoaXMuY29uZmlnLnRpdGxlP3RoaXMuY29uZmlnLnRpdGxlLmNhbGwodGhpcy5lbGVtZW50KTp0aGlzLmNvbmZpZy50aXRsZSksdH0saC5wcm90b3R5cGUuY2xlYW51cFRldGhlcj1mdW5jdGlvbigpe3RoaXMuX3RldGhlciYmdGhpcy5fdGV0aGVyLmRlc3Ryb3koKX0saC5wcm90b3R5cGUuX2dldEF0dGFjaG1lbnQ9ZnVuY3Rpb24odCl7cmV0dXJuIF9bdC50b1VwcGVyQ2FzZSgpXX0saC5wcm90b3R5cGUuX3NldExpc3RlbmVycz1mdW5jdGlvbigpe3ZhciBlPXRoaXMsbj10aGlzLmNvbmZpZy50cmlnZ2VyLnNwbGl0KFwiIFwiKTtuLmZvckVhY2goZnVuY3Rpb24obil7aWYoXCJjbGlja1wiPT09bil0KGUuZWxlbWVudCkub24oZS5jb25zdHJ1Y3Rvci5FdmVudC5DTElDSyxlLmNvbmZpZy5zZWxlY3RvcixmdW5jdGlvbih0KXtyZXR1cm4gZS50b2dnbGUodCl9KTtlbHNlIGlmKG4hPT1ULk1BTlVBTCl7dmFyIGk9bj09PVQuSE9WRVI/ZS5jb25zdHJ1Y3Rvci5FdmVudC5NT1VTRUVOVEVSOmUuY29uc3RydWN0b3IuRXZlbnQuRk9DVVNJTixvPW49PT1ULkhPVkVSP2UuY29uc3RydWN0b3IuRXZlbnQuTU9VU0VMRUFWRTplLmNvbnN0cnVjdG9yLkV2ZW50LkZPQ1VTT1VUO3QoZS5lbGVtZW50KS5vbihpLGUuY29uZmlnLnNlbGVjdG9yLGZ1bmN0aW9uKHQpe3JldHVybiBlLl9lbnRlcih0KX0pLm9uKG8sZS5jb25maWcuc2VsZWN0b3IsZnVuY3Rpb24odCl7cmV0dXJuIGUuX2xlYXZlKHQpfSl9dChlLmVsZW1lbnQpLmNsb3Nlc3QoXCIubW9kYWxcIikub24oXCJoaWRlLmJzLm1vZGFsXCIsZnVuY3Rpb24oKXtyZXR1cm4gZS5oaWRlKCl9KX0pLHRoaXMuY29uZmlnLnNlbGVjdG9yP3RoaXMuY29uZmlnPXQuZXh0ZW5kKHt9LHRoaXMuY29uZmlnLHt0cmlnZ2VyOlwibWFudWFsXCIsc2VsZWN0b3I6XCJcIn0pOnRoaXMuX2ZpeFRpdGxlKCl9LGgucHJvdG90eXBlLl9maXhUaXRsZT1mdW5jdGlvbigpe3ZhciB0PWkodGhpcy5lbGVtZW50LmdldEF0dHJpYnV0ZShcImRhdGEtb3JpZ2luYWwtdGl0bGVcIikpOyh0aGlzLmVsZW1lbnQuZ2V0QXR0cmlidXRlKFwidGl0bGVcIil8fFwic3RyaW5nXCIhPT10KSYmKHRoaXMuZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJkYXRhLW9yaWdpbmFsLXRpdGxlXCIsdGhpcy5lbGVtZW50LmdldEF0dHJpYnV0ZShcInRpdGxlXCIpfHxcIlwiKSx0aGlzLmVsZW1lbnQuc2V0QXR0cmlidXRlKFwidGl0bGVcIixcIlwiKSl9LGgucHJvdG90eXBlLl9lbnRlcj1mdW5jdGlvbihlLG4pe3ZhciBpPXRoaXMuY29uc3RydWN0b3IuREFUQV9LRVk7cmV0dXJuIG49bnx8dChlLmN1cnJlbnRUYXJnZXQpLmRhdGEoaSksbnx8KG49bmV3IHRoaXMuY29uc3RydWN0b3IoZS5jdXJyZW50VGFyZ2V0LHRoaXMuX2dldERlbGVnYXRlQ29uZmlnKCkpLHQoZS5jdXJyZW50VGFyZ2V0KS5kYXRhKGksbikpLGUmJihuLl9hY3RpdmVUcmlnZ2VyW1wiZm9jdXNpblwiPT09ZS50eXBlP1QuRk9DVVM6VC5IT1ZFUl09ITApLHQobi5nZXRUaXBFbGVtZW50KCkpLmhhc0NsYXNzKG0uU0hPVyl8fG4uX2hvdmVyU3RhdGU9PT1nLlNIT1c/dm9pZChuLl9ob3ZlclN0YXRlPWcuU0hPVyk6KGNsZWFyVGltZW91dChuLl90aW1lb3V0KSxuLl9ob3ZlclN0YXRlPWcuU0hPVyxuLmNvbmZpZy5kZWxheSYmbi5jb25maWcuZGVsYXkuc2hvdz92b2lkKG4uX3RpbWVvdXQ9c2V0VGltZW91dChmdW5jdGlvbigpe24uX2hvdmVyU3RhdGU9PT1nLlNIT1cmJm4uc2hvdygpfSxuLmNvbmZpZy5kZWxheS5zaG93KSk6dm9pZCBuLnNob3coKSl9LGgucHJvdG90eXBlLl9sZWF2ZT1mdW5jdGlvbihlLG4pe3ZhciBpPXRoaXMuY29uc3RydWN0b3IuREFUQV9LRVk7aWYobj1ufHx0KGUuY3VycmVudFRhcmdldCkuZGF0YShpKSxufHwobj1uZXcgdGhpcy5jb25zdHJ1Y3RvcihlLmN1cnJlbnRUYXJnZXQsdGhpcy5fZ2V0RGVsZWdhdGVDb25maWcoKSksdChlLmN1cnJlbnRUYXJnZXQpLmRhdGEoaSxuKSksZSYmKG4uX2FjdGl2ZVRyaWdnZXJbXCJmb2N1c291dFwiPT09ZS50eXBlP1QuRk9DVVM6VC5IT1ZFUl09ITEpLCFuLl9pc1dpdGhBY3RpdmVUcmlnZ2VyKCkpcmV0dXJuIGNsZWFyVGltZW91dChuLl90aW1lb3V0KSxuLl9ob3ZlclN0YXRlPWcuT1VULG4uY29uZmlnLmRlbGF5JiZuLmNvbmZpZy5kZWxheS5oaWRlP3ZvaWQobi5fdGltZW91dD1zZXRUaW1lb3V0KGZ1bmN0aW9uKCl7bi5faG92ZXJTdGF0ZT09PWcuT1VUJiZuLmhpZGUoKX0sbi5jb25maWcuZGVsYXkuaGlkZSkpOnZvaWQgbi5oaWRlKCl9LGgucHJvdG90eXBlLl9pc1dpdGhBY3RpdmVUcmlnZ2VyPWZ1bmN0aW9uKCl7Zm9yKHZhciB0IGluIHRoaXMuX2FjdGl2ZVRyaWdnZXIpaWYodGhpcy5fYWN0aXZlVHJpZ2dlclt0XSlyZXR1cm4hMDtyZXR1cm4hMX0saC5wcm90b3R5cGUuX2dldENvbmZpZz1mdW5jdGlvbihuKXtyZXR1cm4gbj10LmV4dGVuZCh7fSx0aGlzLmNvbnN0cnVjdG9yLkRlZmF1bHQsdCh0aGlzLmVsZW1lbnQpLmRhdGEoKSxuKSxuLmRlbGF5JiZcIm51bWJlclwiPT10eXBlb2Ygbi5kZWxheSYmKG4uZGVsYXk9e3Nob3c6bi5kZWxheSxoaWRlOm4uZGVsYXl9KSxyLnR5cGVDaGVja0NvbmZpZyhlLG4sdGhpcy5jb25zdHJ1Y3Rvci5EZWZhdWx0VHlwZSksbn0saC5wcm90b3R5cGUuX2dldERlbGVnYXRlQ29uZmlnPWZ1bmN0aW9uKCl7dmFyIHQ9e307aWYodGhpcy5jb25maWcpZm9yKHZhciBlIGluIHRoaXMuY29uZmlnKXRoaXMuY29uc3RydWN0b3IuRGVmYXVsdFtlXSE9PXRoaXMuY29uZmlnW2VdJiYodFtlXT10aGlzLmNvbmZpZ1tlXSk7cmV0dXJuIHR9LGguX2pRdWVyeUludGVyZmFjZT1mdW5jdGlvbihlKXtyZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uKCl7dmFyIG49dCh0aGlzKS5kYXRhKGEpLG89XCJvYmplY3RcIj09PShcInVuZGVmaW5lZFwiPT10eXBlb2YgZT9cInVuZGVmaW5lZFwiOmkoZSkpJiZlO2lmKChufHwhL2Rpc3Bvc2V8aGlkZS8udGVzdChlKSkmJihufHwobj1uZXcgaCh0aGlzLG8pLHQodGhpcykuZGF0YShhLG4pKSxcInN0cmluZ1wiPT10eXBlb2YgZSkpe2lmKHZvaWQgMD09PW5bZV0pdGhyb3cgbmV3IEVycm9yKCdObyBtZXRob2QgbmFtZWQgXCInK2UrJ1wiJyk7bltlXSgpfX0pfSxvKGgsbnVsbCxbe2tleTpcIlZFUlNJT05cIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gc319LHtrZXk6XCJEZWZhdWx0XCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIGR9fSx7a2V5OlwiTkFNRVwiLGdldDpmdW5jdGlvbigpe3JldHVybiBlfX0se2tleTpcIkRBVEFfS0VZXCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIGF9fSx7a2V5OlwiRXZlbnRcIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gcH19LHtrZXk6XCJFVkVOVF9LRVlcIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gbH19LHtrZXk6XCJEZWZhdWx0VHlwZVwiLGdldDpmdW5jdGlvbigpe3JldHVybiBmfX1dKSxofSgpO3JldHVybiB0LmZuW2VdPUkuX2pRdWVyeUludGVyZmFjZSx0LmZuW2VdLkNvbnN0cnVjdG9yPUksdC5mbltlXS5ub0NvbmZsaWN0PWZ1bmN0aW9uKCl7cmV0dXJuIHQuZm5bZV09aCxJLl9qUXVlcnlJbnRlcmZhY2V9LEl9KGpRdWVyeSkpOyhmdW5jdGlvbihyKXt2YXIgYT1cInBvcG92ZXJcIixsPVwiNC4wLjAtYWxwaGEuNlwiLGg9XCJicy5wb3BvdmVyXCIsYz1cIi5cIitoLHU9ci5mblthXSxkPXIuZXh0ZW5kKHt9LHMuRGVmYXVsdCx7cGxhY2VtZW50OlwicmlnaHRcIix0cmlnZ2VyOlwiY2xpY2tcIixjb250ZW50OlwiXCIsdGVtcGxhdGU6JzxkaXYgY2xhc3M9XCJwb3BvdmVyXCIgcm9sZT1cInRvb2x0aXBcIj48aDMgY2xhc3M9XCJwb3BvdmVyLXRpdGxlXCI+PC9oMz48ZGl2IGNsYXNzPVwicG9wb3Zlci1jb250ZW50XCI+PC9kaXY+PC9kaXY+J30pLGY9ci5leHRlbmQoe30scy5EZWZhdWx0VHlwZSx7Y29udGVudDpcIihzdHJpbmd8ZWxlbWVudHxmdW5jdGlvbilcIn0pLF89e0ZBREU6XCJmYWRlXCIsU0hPVzpcInNob3dcIn0sZz17VElUTEU6XCIucG9wb3Zlci10aXRsZVwiLENPTlRFTlQ6XCIucG9wb3Zlci1jb250ZW50XCJ9LHA9e0hJREU6XCJoaWRlXCIrYyxISURERU46XCJoaWRkZW5cIitjLFNIT1c6XCJzaG93XCIrYyxTSE9XTjpcInNob3duXCIrYyxJTlNFUlRFRDpcImluc2VydGVkXCIrYyxDTElDSzpcImNsaWNrXCIrYyxGT0NVU0lOOlwiZm9jdXNpblwiK2MsRk9DVVNPVVQ6XCJmb2N1c291dFwiK2MsTU9VU0VFTlRFUjpcIm1vdXNlZW50ZXJcIitjLE1PVVNFTEVBVkU6XCJtb3VzZWxlYXZlXCIrY30sbT1mdW5jdGlvbihzKXtmdW5jdGlvbiB1KCl7cmV0dXJuIG4odGhpcyx1KSx0KHRoaXMscy5hcHBseSh0aGlzLGFyZ3VtZW50cykpfXJldHVybiBlKHUscyksdS5wcm90b3R5cGUuaXNXaXRoQ29udGVudD1mdW5jdGlvbigpe3JldHVybiB0aGlzLmdldFRpdGxlKCl8fHRoaXMuX2dldENvbnRlbnQoKX0sdS5wcm90b3R5cGUuZ2V0VGlwRWxlbWVudD1mdW5jdGlvbigpe3JldHVybiB0aGlzLnRpcD10aGlzLnRpcHx8cih0aGlzLmNvbmZpZy50ZW1wbGF0ZSlbMF19LHUucHJvdG90eXBlLnNldENvbnRlbnQ9ZnVuY3Rpb24oKXt2YXIgdD1yKHRoaXMuZ2V0VGlwRWxlbWVudCgpKTt0aGlzLnNldEVsZW1lbnRDb250ZW50KHQuZmluZChnLlRJVExFKSx0aGlzLmdldFRpdGxlKCkpLHRoaXMuc2V0RWxlbWVudENvbnRlbnQodC5maW5kKGcuQ09OVEVOVCksdGhpcy5fZ2V0Q29udGVudCgpKSx0LnJlbW92ZUNsYXNzKF8uRkFERStcIiBcIitfLlNIT1cpLHRoaXMuY2xlYW51cFRldGhlcigpfSx1LnByb3RvdHlwZS5fZ2V0Q29udGVudD1mdW5jdGlvbigpe3JldHVybiB0aGlzLmVsZW1lbnQuZ2V0QXR0cmlidXRlKFwiZGF0YS1jb250ZW50XCIpfHwoXCJmdW5jdGlvblwiPT10eXBlb2YgdGhpcy5jb25maWcuY29udGVudD90aGlzLmNvbmZpZy5jb250ZW50LmNhbGwodGhpcy5lbGVtZW50KTp0aGlzLmNvbmZpZy5jb250ZW50KX0sdS5falF1ZXJ5SW50ZXJmYWNlPWZ1bmN0aW9uKHQpe3JldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKXt2YXIgZT1yKHRoaXMpLmRhdGEoaCksbj1cIm9iamVjdFwiPT09KFwidW5kZWZpbmVkXCI9PXR5cGVvZiB0P1widW5kZWZpbmVkXCI6aSh0KSk/dDpudWxsO2lmKChlfHwhL2Rlc3Ryb3l8aGlkZS8udGVzdCh0KSkmJihlfHwoZT1uZXcgdSh0aGlzLG4pLHIodGhpcykuZGF0YShoLGUpKSxcInN0cmluZ1wiPT10eXBlb2YgdCkpe2lmKHZvaWQgMD09PWVbdF0pdGhyb3cgbmV3IEVycm9yKCdObyBtZXRob2QgbmFtZWQgXCInK3QrJ1wiJyk7ZVt0XSgpfX0pfSxvKHUsbnVsbCxbe2tleTpcIlZFUlNJT05cIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gbH19LHtrZXk6XCJEZWZhdWx0XCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIGR9fSx7a2V5OlwiTkFNRVwiLGdldDpmdW5jdGlvbigpe3JldHVybiBhfX0se2tleTpcIkRBVEFfS0VZXCIsZ2V0OmZ1bmN0aW9uKCl7cmV0dXJuIGh9fSx7a2V5OlwiRXZlbnRcIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gcH19LHtrZXk6XCJFVkVOVF9LRVlcIixnZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gY319LHtrZXk6XCJEZWZhdWx0VHlwZVwiLGdldDpmdW5jdGlvbigpe3JldHVybiBmfX1dKSx1fShzKTtyZXR1cm4gci5mblthXT1tLl9qUXVlcnlJbnRlcmZhY2Usci5mblthXS5Db25zdHJ1Y3Rvcj1tLHIuZm5bYV0ubm9Db25mbGljdD1mdW5jdGlvbigpe3JldHVybiByLmZuW2FdPXUsbS5falF1ZXJ5SW50ZXJmYWNlfSxtfSkoalF1ZXJ5KX0oKTsiLCIvKipcbiAqIFNob3dzIHRoZSBuZXh0IGNhbGVuZGFyIHNjcmVlblxuICogXG4gKiBAcGFyYW0ge2FueX0gZWxlbWVudCBcbiAqL1xuZnVuY3Rpb24gbmV4dENhbGVuZGFyU2NyZWVuKGVsZW1lbnQpe1xuICAgIHZhciBjdXJyZW50U2NyZWVuID0gJChlbGVtZW50KS5wYXJlbnQoKS5wYXJlbnQoKS5jaGlsZHJlbignLkNhbGVuZGFyX19TY3JlZW4nKTtcbiAgICBjdXJyZW50U2NyZWVuLnJlbW92ZUNsYXNzKCdBY3RpdmUnKTtcbiAgICBcbiAgICB2YXIgbmV4dFNjcmVlbiA9ICQoY3VycmVudFNjcmVlbikubmV4dCgnLkNhbGVuZGFyX19TY3JlZW4nKTtcbiAgICBuZXh0U2NyZWVuLmFkZENsYXNzKCdBY3RpdmUnKTtcbn1cblxuLyoqXG4gKiBTaG93cyB0aGUgcHJldmlvdXMgY2FsZW5kYXIgc2NyZWVuXG4gKiBcbiAqIEBwYXJhbSB7YW55fSBlbGVtZW50IFxuICovXG5mdW5jdGlvbiBwcmV2aW91c0NhbGVuZGFyU2NyZWVuKGVsZW1lbnQpe1xuICAgIHZhciBjdXJyZW50U2NyZWVuID0gJChlbGVtZW50KS5wYXJlbnQoKS5wYXJlbnQoKS5jaGlsZHJlbignLkNhbGVuZGFyX19TY3JlZW4nKTtcbiAgICBjdXJyZW50U2NyZWVuLnJlbW92ZUNsYXNzKCdBY3RpdmUnKTtcbiAgICBcbiAgICB2YXIgcHJldlNjcmVlbiA9ICQoY3VycmVudFNjcmVlbikucHJldignLkNhbGVuZGFyX19TY3JlZW4nKTtcbiAgICBwcmV2U2NyZWVuLmFkZENsYXNzKCdBY3RpdmUnKTtcbn1cbiIsIi8vIFRoaXMgaXMgdXNlZCB3aXRoaW4gZGFzaGJvYXJkX19jYWxlbmRhci0tbW9udGguaHRtbCB0byBhZGQgY2xhc3MgYWN0aXZlIHRvIGNvbG9yIHBhbGV0dGVcblxuJChcIi5Db2xvcl9fc3dhdGNoXCIpLmNsaWNrKGZ1bmN0aW9uKCl7XG4gICQoXCIuQ29sb3JfX3N3YXRjaFwiKS5yZW1vdmVDbGFzcyhcIkFjdGl2ZVwiKTtcbiAgJCh0aGlzKS5hZGRDbGFzcyhcIkFjdGl2ZVwiKTtcbn0pXG4iLCIvKlxuKiBTZXQgdmFsdWUgb24gYSBmaWVsZCBvbmZvY3VzIGV2ZW50IGlmIGZpZWxkIHZhbHVlIGlzIGVtcHR5XG4qXG4qIEBwYXJhbSBPYmplY3QgZWxlbWVudCBUaGUgZmllbGRcbiogQHBhcmFtIHN0cmluZyB2YWx1ZSAgIFRoZSB2YWx1ZSBcbiovXG5mdW5jdGlvbiBzZXRGb2N1c1ZhbHVlKGVsZW1lbnQsIHZhbHVlKXtcbiAgICBpZighJChlbGVtZW50KS52YWwoKSlcbiAgICB7XG4gICAgICAgICQoZWxlbWVudCkudmFsKHZhbHVlKTtcbiAgICB9XG59XG5cbi8qXG4qIENvbGxhcHNlcyBhY2NvcmRpb24ocykgXG4qXG4qIEBwYXJhbSBlbGVtZW50ICAgIGFjY29yZGlvbiAgIFRoZSBhY2NvcmRpb24gZWxlbWVudFxuKiBAcGFyYW0gc3RyaW5nICAgICBhY3Rpb24gICAgICBUaGUgYWN0aW9uXG4qL1xuZnVuY3Rpb24gY29sbGFwc2VBbGwoYWNjb3JkaW9uLCBhY3Rpb24pXG57XG4gICAgJChhY2NvcmRpb24pLmNvbGxhcHNlKGFjdGlvbik7XG59XG5cbi8vIENoZWNrcyBhbGwgdGhlIGNoZWNrYm94ZXMgY2hpbGRyZW4gd2hvIGhhdmUgdGhlIC5jaGVja0FsbCBlbGVtZW50IGlkXG4kKCcuY2hlY2tBbGwnKS5jbGljayhmdW5jdGlvbigpe1xuICAgIC8vIGdldCB0aGUgaWRcbiAgICB2YXIgaWQgPSAkKHRoaXMpLmF0dHIoJ2lkJyk7XG5cbiAgICAvLyBjaGVjayBhbGwgdGhlIGNoZWNrYm94ZXMgd2hvIGhhdmUgdGhlIHBhcmVudCBpZCBhcyBjbGFzc1xuICAgICQoJy4nICsgaWQpLnByb3AoJ2NoZWNrZWQnLCB0aGlzLmNoZWNrZWQpO1xufSlcblxuLypcbiogICBFbmFibGVzL2Rpc2FibGVzIGlubGluZSBlZGl0aW5nXG4qL1xuZnVuY3Rpb24gZWRpdElubGluZUVkaXRhYmxlKCl7XG4gICAgLy8gaGlkZS9zaG93IHRoZSBhZGQgYW5kIGVkaXQgYnV0dG9ucyBhbmQgc2hvdy9oaWRlIGVkaXQgYWN0aW9uIGJ1dHRvbnNcbiAgICAkKCcuSW5saW5lLWVkaXRhYmxlLS1lbmFibGUnKS50b2dnbGUoKTtcbiAgICAkKCcuQWRkLW5ldy1pbmxpbmUtZWRpdGFibGUnKS50b2dnbGUoKTtcbiAgICAkKCcuRWRpdC1pbmxpbmUtYWN0aW9uJykudG9nZ2xlKCk7XG5cbiAgICAvLyBzaG93L2hpZGUgdGhlIGVkaXRhYmxlIGlucHV0c1xuICAgICQoJy5FZGl0YWJsZS1jaGVjay10ZXh0IGlucHV0JykucHJvcCgnZGlzYWJsZWQnLCBmdW5jdGlvbihpLCB2KSB7IHJldHVybiAhdjsgfSk7O1xufVxuXG4vKlxuKiBTZXRzIHRoZSBTZWxlY3RlZCBjbGFzcyBvbiB0aGUgc2VsZWN0ZWQgZWxlbWVudFxuKi9cbmZ1bmN0aW9uIHNldFNlbGVjdGVkSWNvbihlbGVtZW50KXtcbiAgICAkKGVsZW1lbnQpLnBhcmVudCgpLmNoaWxkcmVuKCkucmVtb3ZlQ2xhc3MoJ1NlbGVjdGVkJyk7XG4gICAgJChlbGVtZW50KS5hZGRDbGFzcygnU2VsZWN0ZWQnKTtcbn0iLCIkKCdzZWxlY3QnKS5jaGFuZ2UoZnVuY3Rpb24gKCkge1xuICAgIGlmICgkKHRoaXMpLnZhbCgpID09IFwibW9kYWwtdHJpZ2dlclwiKSB7XG4gICAgICAgICQoJyNteU1vZGFsJykubW9kYWwoJ3Nob3cnKTtcbiAgICB9XG59KTsiLCIkKCcuSGFtYnVyZ2VyJykuY2xpY2soZnVuY3Rpb24gKCkge1xuICAgICQodGhpcykudG9nZ2xlQ2xhc3MoJ09wZW4nKTtcbiAgICAkKCcuU3ViLWhlYWRlcl9iYXInKS50b2dnbGVDbGFzcygnSGFtYnVyZ2VyLW9wZW4nKTtcbiAgICBjb25zb2xlLmxvZygndG9nZ2xlZCcpXG59KTsiLCIkKHdpbmRvdykuc2Nyb2xsKGZ1bmN0aW9uKCkgeyAgICBcbiAgICB2YXIgc2Nyb2xsID0gJCh3aW5kb3cpLnNjcm9sbFRvcCgpO1xuXG4gICAgaWYgKHNjcm9sbCA+PSA1MCkge1xuICAgICAgICAkKFwiLlN1Yi1oZWFkZXJfYmFyXCIpLmFkZENsYXNzKFwiU3RpY2t5LWhlYWRlclwiKTtcbiAgICAgICAgJChcIi5IZWFkZXJfYmFyXCIpLmFkZENsYXNzKFwiT25seVwiKTtcbiAgICAgICAgJChcImh0bWxcIikuYWRkQ2xhc3MoXCJXLVN0aWNreS1uYXYtLWVuXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgICQoXCIuU3ViLWhlYWRlcl9iYXJcIikucmVtb3ZlQ2xhc3MoXCJTdGlja3ktaGVhZGVyXCIpO1xuICAgICAgICAkKFwiLkhlYWRlcl9iYXJcIikucmVtb3ZlQ2xhc3MoXCJPbmx5XCIpO1xuICAgICAgICAkKFwiaHRtbFwiKS5yZW1vdmVDbGFzcyhcIlctU3RpY2t5LW5hdi0tZW5cIik7XG4gICAgfVxufSk7XG5cbiQoJy5IZWFkZXJfYmFyX19hbGVydCcpLmNsaWNrKGZ1bmN0aW9uKCl7XG4gICAgJCgnLkhlYWRlcl9iYXJfX2FsZXJ0LS1ub3RpZmljYXRpb24nKS5oaWRlKCk7XG59KSIsIi8qXG4qIEFkZHMgYSBtYXJrZXIgb24gdGhlIG1hcFxuKlxuKiBAcGFyYW0gTWFwXHRtYXBcdFx0XHRcdFRoZSBtYXAgd2hlcmUgdG8gYWRkIHRoZSBtYXJrZXJcbiogQHBhcmFtIGZsb2F0ICBsYXQgICAgIFx0XHRUaGUgcGxhY2UgbGF0aXR1ZGUgXG4qIEBwYXJhbSBmbG9hdCAgbG9uZyAgICBcdFx0VGhlIHBsYWNlIGxvbmdpdHVkZVxuKiBAcGFyYW0gc3RyaW5nIGNvbnRlbnRTdHJpbmdcdFRoZSB3aW5kb3cgaW5mbyBjb250ZW50XG4qIEBwYXJhbSBzdHJpbmcgdHlwZSAgICBcdFx0VGhlIHBpbiB0eXBlLiBBdmFpbGFibGUgcGluczogW3JlZCxhbWJlcixncmVlbl1cbiogQHBhcmFtIHN0cmluZyBsYWJlbCAgIFx0XHRUaGUgcGluIGxhYmVsLiBBdmFpbGFibGUgbGFiZWw6IFtjeWNsb25lLGNvbmZsaWN0LGVhcnRocXVha2UsdHN1bmFtaSxzdG9ybSx2b2xjYW5vLHRvcm5hZG8saW5zZWN0LWluZmVzdGF0aW9uLGRhbmdlcm91cy1hcmVhXVxuKiBAcmV0dXJuIHtOdW1iZXJ9IHN1bVxuKi9cbmZ1bmN0aW9uIGFkZE1hcmtlcihtYXAsIGxhdCwgbG9uZywgY29udGVudFN0cmluZywgdHlwZSAsIGxhYmVsID0gbnVsbClcbntcblx0dmFyIG1hcmtlciA9IG5ldyBNYXJrZXIoe1xuXHRcdHBvc2l0aW9uOiBuZXcgZ29vZ2xlLm1hcHMuTGF0TG5nKGxhdCwgbG9uZyksXG5cdFx0bWFwOiBtYXAsXG5cdFx0aWNvbjogJ2ltZy9tYXJrZXJzLycgKyB0eXBlICsgJy5zdmcnLFxuXHRcdG1hcF9pY29uX2xhYmVsOiAobGFiZWwgIT09IG51bGwpID8gJzxpIGNsYXNzPVwibWFwLWljb24gSWNvbi0tJyArIGxhYmVsICsgJyBJY29uLS1zbVwiPjwvaT4nIDogJydcblx0fSk7XG4gXHRcblx0dmFyIGluZm93aW5kb3cgPSBuZXcgZ29vZ2xlLm1hcHMuSW5mb1dpbmRvdyh7XG4gICAgICAgICAgICBjb250ZW50OiBjb250ZW50U3RyaW5nLFxuXHRcdFx0bWF4V2lkdGg6IDQ4MFxuXHR9KTtcblxuXHRtYXJrZXIuYWRkTGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24oKSB7XG5cdFx0aW5mb3dpbmRvdy5vcGVuKG1hcCwgbWFya2VyKTtcblx0fSk7XG59IiwiLy8gWW91IGNhbiBzZWUgdGhlc2UgaW4gdXNlIG9uIGNvdW50cnktYWRtaW5fX2NvdW50cnktb2ZmaWNlLS1tb2R1bGUtc2V0dGluZ3MuaHRtbCB0byByZXBsaWNhdGUgcmFkaW8gYnV0dG9ucywgd2l0aCBib290c3RyYXAgYnV0dG9uc1xuXG4kKCcuUmFkaW9fX2J1dHRvbi0tanMgLmJ0bicpLmNsaWNrKGZ1bmN0aW9uKCkge1xuXHQkKHRoaXMpLnBhcmVudCgpLmNoaWxkcmVuKCcuYnRuJykucmVtb3ZlQ2xhc3MoJ2J0bi1wcmltYXJ5IEFjdGl2ZScpLmFkZENsYXNzKCdidG4tb3V0bGluZS1wcmltYXJ5Jyk7XG5cdCQodGhpcykucmVtb3ZlQ2xhc3MoJ2J0bi1vdXRsaW5lLXByaW1hcnknKS5hZGRDbGFzcygnYnRuLXByaW1hcnkgQWN0aXZlJyk7XG59KTtcblxuLy8gUmFkaW8gYnV0dG9ucyBjaGVja2VkIGJ5IGJ1dHRvbnMgLSBpbml0aWFsbHkgaW1wbGVtZW50ZWQgaW4gdGhlIFJpc2sgTW9uaXRvcmluZyBzZWN0aW9uIChUQkMpLlxuXG4kKCcuVXBkYXRlX19idXR0b24tLWpzIC5idG4nKS5jbGljayhmdW5jdGlvbigpIHtcbiAgICAkKHRoaXMpLnBhcmVudCgpLmNoaWxkcmVuKCcuYnRuJykuaHRtbCgnU2F2ZScpLnJlbW92ZUNsYXNzKCdidG4gYnRuLXVwZGF0ZScpLmFkZENsYXNzKCdidG4gYnRuLXNhdmUnKS50b2dnbGVDbGFzcygnaGlkZGVuJyk7XG4gICAgJCh0aGlzKS5yZW1vdmVDbGFzcygnYnRuIGJ0bi1zYXZlJykuaHRtbCgnVXBkYXRlJykuYWRkQ2xhc3MoJ2J0biBidG4tdXBkYXRlJykudG9nZ2xlQ2xhc3MoJ3Nob3cnKTtcbn0pO1xuIiwiLyoqXG4gKiBBZGRzIHRoZSBzZWxlY3RlZCBjbGFzcyB0byB0aGUgY2xpY2tlZCByYWRpbyBidXR0b25cbiAqIFxuICogQHBhcmFtIEVsZW1lbnQgaW5wdXQgXG4gKi9cbmZ1bmN0aW9uIG11bHRpX3NlbGVjdF9yYWRpb1NlbGVjdGVkKGlucHV0KXtcbiAgICAkKGlucHV0KS5wYXJlbnQoKS5wYXJlbnQoKS5maW5kKCcuU2VsZWN0ZWQnKS5yZW1vdmVDbGFzcygnU2VsZWN0ZWQnKTtcbiAgICAkKGlucHV0KS5wYXJlbnQoKS50b2dnbGVDbGFzcygnU2VsZWN0ZWQnKTtcbn0iLCJmdW5jdGlvbiByaWJib25DbGljayhlbGVtZW50KXtcbiAgICAvL1Jlc2V0IGFsbCBhY3RpdmUgY2xhc3Nlc1xuICAgIGlmICggJCggZWxlbWVudCApLmhhc0NsYXNzKCBcIkFjdGl2ZVwiICkgKSB7XG4gICAgICAgICQoXCIuUmliYm9uX19oZWFkZXJfX3dyYXAsIC5SaWJib25fX3Jlc3BvbnNlLCAuUmliYm9uX19oZWFkZXJfX2NoZXZyb25cIikucmVtb3ZlQ2xhc3MoJ0FjdGl2ZScpO1xuICAgICAgICAkKFwiLlJlc3BvbnNlX19jb250ZW50XCIpLnNsaWRlVXAoKTtcbiAgICB9XG4gICAgZWxzZVxuICAgIHtcbiAgICAgICAgJChcIi5SaWJib25fX2hlYWRlcl9fd3JhcCwgLlJpYmJvbl9fcmVzcG9uc2UsIC5SaWJib25fX2hlYWRlcl9fY2hldnJvblwiKS5yZW1vdmVDbGFzcygnQWN0aXZlJyk7XG4gICAgICAgICQoXCIuUmVzcG9uc2VfX2NvbnRlbnRcIikuc2xpZGVVcCgpO1xuXG4gICAgICAgIC8vQWRkIEFjdGl2ZSB0byBSaWJib24gSGVhZGVyIFdyYXBcbiAgICAgICAgJChlbGVtZW50KS5wYXJlbnQoKS5hZGRDbGFzcygnQWN0aXZlJyk7XG4gICAgICAgICQoZWxlbWVudCkudG9nZ2xlQ2xhc3MoJ0FjdGl2ZScpO1xuICAgICAgICAkKGVsZW1lbnQpLnBhcmVudCgpLnBhcmVudCgpLm5leHQoXCIuUmVzcG9uc2VfX2NvbnRlbnRcIikuc2xpZGVUb2dnbGUoKTtcbiAgICAgICAgJChlbGVtZW50KS5wYXJlbnQoKS5wYXJlbnQoKS50b2dnbGVDbGFzcygnQWN0aXZlJyk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBjb250aW51ZVRvTmV4dFJpYmJvbihlbGVtZW50KXtcbiAgICAgICAgJChcIi5SaWJib25fX2hlYWRlcl9fd3JhcCwgLlJpYmJvbl9fcmVzcG9uc2UsIC5SaWJib25fX2hlYWRlcl9fY2hldnJvblwiKS5yZW1vdmVDbGFzcygnQWN0aXZlJyk7XG4gICAgICAgICQoXCIuUmVzcG9uc2VfX2NvbnRlbnRcIikuc2xpZGVVcCgpO1xuXG4gICAgICAgIC8vQWRkIEFjdGl2ZSB0byBuZXh0IHJpYmJvblxuICAgICAgICAkKGVsZW1lbnQpLnBhcmVudCgpLnBhcmVudCgpLm5leHQoKS5uZXh0KFwiLlJlc3BvbnNlX19jb250ZW50XCIpLnNsaWRlRG93bigpO1xuICAgICAgICAkKGVsZW1lbnQpLnBhcmVudCgpLnBhcmVudCgpLm5leHQoXCIuUmliYm9uX19yZXNwb25zZVwiKS5hZGRDbGFzcygnQWN0aXZlJyk7XG4gICAgICAgICQoZWxlbWVudCkucGFyZW50KCkucGFyZW50KCkubmV4dCgpLmZpbmQoXCIuUmliYm9uX19oZWFkZXJfX3dyYXAsIC5SaWJib25fX2hlYWRlcl9fY2hldnJvblwiKS5hZGRDbGFzcygnQWN0aXZlJyk7XG59XG5cbi8vIEludmVyc2VzIGFycm93IG9uIGFjY29yZGlvbiBleHBhbnNpb25cbiQoJy5jb2xsYXBzZScpLm9uKCdzaG93bi5icy5jb2xsYXBzZScsIGZ1bmN0aW9uKGUpe1xuICAgICAgICBpZighJChlLnRhcmdldCkuaGFzQ2xhc3MoJ3ByZXZlbnRfcGFyZW50X2NvbGxhcHNlJykpeyAvLyBwcmV2ZW50cyB0aGUgdHJpZ2VycmluZyB0aGUgY29sbGFwc2UgZXZlbnQgZm9yIHBhcmVudFxuICAgICAgICAgICAgJCh0aGlzKS5wcmV2KCkuZmluZChcIi5mYS1jYXJldC1kb3duXCIpLnJlbW92ZUNsYXNzKFwiZmEtY2FyZXQtZG93blwiKS5hZGRDbGFzcyhcImZhLWNhcmV0LXVwXCIpO1xuICAgICAgICAgICAgJCh0aGlzKS5wcmV2KCkuZmluZCgnLkhpZGUtYWxsJykuc2hvdygpO1xuICAgICAgICAgICAgJCh0aGlzKS5wcmV2KCkuZmluZCgnLlNob3ctYWxsJykuaGlkZSgpO1xuICAgICAgICB9XG4gICAgfSkub24oJ2hpZGRlbi5icy5jb2xsYXBzZScsIGZ1bmN0aW9uKGUpe1xuICAgICAgICBpZighJChlLnRhcmdldCkuaGFzQ2xhc3MoJ3ByZXZlbnRfcGFyZW50X2NvbGxhcHNlJykpeyAvLyBwcmV2ZW50cyB0aGUgdHJpZ2VycmluZyB0aGUgY29sbGFwc2UgZXZlbnQgZm9yIHBhcmVudFxuICAgICAgICAgICAgJCh0aGlzKS5wcmV2KCkuZmluZChcIi5mYS1jYXJldC11cFwiKS5yZW1vdmVDbGFzcyhcImZhLWNhcmV0LXVwXCIpLmFkZENsYXNzKFwiZmEtY2FyZXQtZG93blwiKTtcbiAgICAgICAgICAgICQodGhpcykucHJldigpLmZpbmQoJy5IaWRlLWFsbCcpLmhpZGUoKTtcbiAgICAgICAgICAgICQodGhpcykucHJldigpLmZpbmQoJy5TaG93LWFsbCcpLnNob3coKTtcbiAgICAgICAgfVxufSk7XG5cbiIsIi8vIHNlbGVjdCBpbmRpY2F0b3IgZGl2XG5jb25zdCByaXNrSW5kaWNhdG9yID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJSaXNrX19pbmRpY2F0b3JcIik7XG4vLyBzZWxlY3QgdXBkYXRlIGJ1dHRvblxuY29uc3QgdXBkYXRlQnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJVcGRhdGVfYnV0dG9uXCIpO1xuLy8gSW5kaWNhdG9yIGJ1dHRvbnNcbmNvbnN0IGluZGljYXRvckJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJSaXNrX2luZGljYXRvcl9idXR0b25cIik7XG4vLyBJbmRpY2F0b3IgJ2NoZWNrIGV2ZXJ5Li4nIHRleHRcbmNvbnN0IGNoZWNrSW5kaWNhdG9yVGV4dCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJyaXNrLXRleHRcIik7XG5cblxuICAgIC8vIHNlbGVjdCB1cGRhdGUgYnV0dG9uXG4gICAgICAgIHVwZGF0ZUNoYW5nZTogdXBkYXRlQnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIlVwZGF0ZSBCdXR0b24gQ2xpY2tlZCFcIik7XG4gICAgICAgICAgICByaXNrSW5kaWNhdG9yLmNsYXNzTGlzdC50b2dnbGUoXCJhY3RpdmVcIik7XG4gICAgICAgIH0pO1xuXG4gICAgLy8gSWYgc3RhdGVtZW50IHRvIGNoZWNrIHdoZXRoZXIgdGhlIFJpc2sgSW5kaWNhdG9yIGlzIGFjdGl2ZSB0byBhcHBseSBiYWNrZ3JvdW5kIGNoYW5nZXNcbiAgICAgICAgZWRpdFN0YXRlOiB1cGRhdGVCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uKCkge1xuXG5cbiAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBjaGVja0luZGljYXRvclRleHQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhjaGVja0luZGljYXRvclRleHRbaV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgIC8vIGNoYW5nZSB0aGUgYnV0dG9uIHRleHQgdG8gc2F2ZSBvbiBjbGljayB0aGVuIGJhY2sgdG8gdXBkYXRlIG9uIHNlY29uZCBjbGlja1xuICAgICAgICBzYXZlQnV0dG9uQ2hhbmdlOiB1cGRhdGVCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICh1cGRhdGVCdXR0b24udGV4dENvbnRlbnQgPT09IFwiVXBkYXRlXCIpIHtcbiAgICAgICAgICAgICAgICB1cGRhdGVCdXR0b24udGV4dENvbnRlbnQgPSBcIlNhdmVcIjtcbiAgICAgICAgICAgICAgICAvL2NoYW5nZSBidXR0b24gY2xhc3MgYXMgd2VsbFxuICAgICAgICAgICAgICAgIC8vIGV4YW1wbGUgY29kZSBnb2VzIGhlcmUuLi5cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdXBkYXRlQnV0dG9uLnRleHRDb250ZW50ID0gXCJVcGRhdGVcIjtcbiAgICAgICAgICAgICAgICAvL2NoYW5nZSBidXR0b24gY2xhc3MgYXMgd2VsbFxuICAgICAgICAgICAgICAgIC8vIGV4YW1wbGUgY29kZSBnb2VzIGhlcmUuLi5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cblxuXG5cblxuICAgIC8vIFNlbGVjdCBhbiBvcHRpb24gaW4gdGhlIGVkaXRpbmcgc3RhdGUgYW5kIGhhdmUgaXQgZm9jdXMgd2l0aCBhbiBvdXRsaW5lIGJvcmRlciBhbmQgdHJhbnNwYXJlbnQgYmFja2dyb3VuZFxuICAgIC8vIGluZGljYXRvckJ1dHRvbi5mb2N1cygpO1xuICAgIC8vIFVzZSBhIGNsaWNrIGV2ZW50IGxpc3RlbmVyIHRvIGlkZW50aWZ5IHdoZXJlIGluIHRoZSBlZGl0aW5nIHN0YXRlIHRoZSB1c2VyIGhhcyBjbGlja2VkXG4gICAgLy8gRm9jdXMgdGhhdCBlbGVtZW50XG4iXX0=
